// Versión para Android de las rutas /api del servidor: las peticiones salen por el puente nativo (sin CORS).
(function () {
  const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  /* ---------- puente nativo ---------- */
  const pending = {};
  let counter = 0;
  window.__nativeDone = (id, status, body) => {
    const p = pending[id];
    if (!p) return;
    delete pending[id];
    p(status, body);
  };
  function getJSON(url, { method = 'GET', headers = {}, body = '' } = {}) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => {
        if (status <= 0) return reject(new Error(text || 'Sin conexión'));
        if (status >= 400) return reject(new Error(new URL(url).host + ' respondió ' + status));
        try { resolve(JSON.parse(text)); } catch { reject(new Error('Respuesta no válida de ' + new URL(url).host)); }
      };
      Native.request(id, method, url, JSON.stringify({ 'User-Agent': UA, ...headers }), body);
    });
  }

  function getText(url, headers = {}) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => (status <= 0 || status >= 400 ? reject(new Error(new URL(url).host + ' respondió ' + status)) : resolve(text));
      Native.request(id, 'GET', url, JSON.stringify({ 'User-Agent': UA, ...headers }), '');
    });
  }
  // Descarga una imagen como data: URL (sin CORS) para usarla en WebGL.
  function getImageData(url) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => {
        if (status <= 0 || status >= 400) return reject(new Error('Imagen no disponible'));
        const i = text.indexOf('|');
        resolve('data:' + text.slice(0, i) + ';base64,' + text.slice(i + 1));
      };
      Native.requestBytes(id, url);
    });
  }
  // Portada en movimiento: video animado que Apple Music publica en la página pública del álbum.
  async function appleMotion(albumId) {
    if (!/^\d+$/.test(albumId)) throw new Error('Álbum no válido');
    const html = await getText(`https://music.apple.com/us/album/${albumId}`, { 'Accept-Language': 'en-US,en;q=0.9' });
    const m = html.match(/"(?:motionDetailSquare|motionSquareVideo1x1)"\s*:\s*\{\s*"video"\s*:\s*"([^"]+)"/);
    return { video: m ? m[1].replace(/\\\//g, '/').replace(/\\u0026/g, '&') : '' };
  }

  /* ---------- utilidades ---------- */
  const decodeEntities = (s) =>
    s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'");
  function parseTime(s) {
    if (!s) return 0;
    s = String(s).trim();
    if (s.endsWith('s')) return parseFloat(s);
    return s.split(':').map(parseFloat).reduce((a, v) => a * 60 + v, 0);
  }
  const parseDuration = (s) => (s ? String(s).split(':').map(Number).reduce((a, v) => a * 60 + v, 0) : 0);
  const enc = encodeURIComponent;

  /* ---------- YouTube Music ---------- */
  const YTM_CONTEXT = { client: { clientName: 'WEB_REMIX', clientVersion: '1.20250210.03.00', hl: 'es', gl: 'US' } };
  const SONGS_FILTER = 'EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D';
  const VIDEOS_FILTER = 'EgWKAQIQAWoKEAkQBRAKEAMQBA%3D%3D';
  function bestThumb(thumbs = []) {
    const t = thumbs[thumbs.length - 1];
    return t ? t.url.replace(/=w\d+-h\d+[^"]*$/, '=w800-h800-l90-rj').replace(/=s\d+/, '=s800') : '';
  }
  async function ytmSearch(q, type) {
    const videos = type === 'videos';
    const data = await getJSON('https://music.youtube.com/youtubei/v1/search?prettyPrint=false', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://music.youtube.com', Referer: 'https://music.youtube.com/' },
      body: JSON.stringify({ context: YTM_CONTEXT, query: q, params: videos ? VIDEOS_FILTER : SONGS_FILTER }),
    });
    const shelves = [];
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      if (n.musicShelfRenderer) shelves.push(n.musicShelfRenderer);
      for (const k in n) walk(n[k]);
    };
    walk(data.contents);
    const out = [];
    for (const shelf of shelves) {
      for (const item of shelf.contents || []) {
        const r = item.musicResponsiveListItemRenderer;
        if (!r) continue;
        const videoId =
          r.playlistItemData?.videoId ||
          r.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
        if (!videoId) continue;
        const cols = r.flexColumns || [];
        const title = cols[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.[0]?.text || '';
        const runs = (cols[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || []).map((x) => x.text);
        const parts = runs.join('').split(' • ').map((s) => s.trim()).filter(Boolean);
        const clean = parts[0] && /^(canción|song|video)$/i.test(parts[0]) ? parts.slice(1) : parts;
        const durStr = clean.find((s) => /^\d+:\d{2}(:\d{2})?$/.test(s)) || '';
        out.push({
          videoId, title,
          artist: clean[0] || '',
          album: !videos && clean[1] && clean[1] !== durStr ? clean[1] : '',
          duration: parseDuration(durStr),
          cover: bestThumb(r.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails),
        });
      }
    }
    return out;
  }

  async function hiresCover(title, artist) {
    const d = await getJSON(`https://itunes.apple.com/search?media=music&entity=song&limit=1&term=${enc(artist + ' ' + title)}`);
    const hit = d.results?.[0];
    if (!hit) return { cover: '' };
    return { cover: hit.artworkUrl100.replace('100x100bb', '1400x1400bb'), appleId: String(hit.trackId), albumId: hit.collectionId ? String(hit.collectionId) : '' };
  }

  /* ---------- letras ---------- */
  function parseLRC(text) {
    const lines = [];
    for (const raw of text.split(/\r?\n/)) {
      const m = raw.match(/^((?:\[\d+:\d+(?:[.:]\d+)?\])+)(.*)$/);
      if (!m) continue;
      const txt = m[2].replace(/<\d+:\d+(?:\.\d+)?>/g, '').trim();
      for (const t of m[1].matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)) {
        lines.push({ time: parseInt(t[1], 10) * 60 + parseFloat(t[2].replace(':', '.')), text: txt });
      }
    }
    return lines.sort((a, b) => a.time - b.time);
  }
  function parseTTML(ttml) {
    const lines = [];
    for (const p of ttml.matchAll(/<p\b([^>]*)>([\s\S]*?)<\/p>/g)) {
      const begin = /begin="([^"]+)"/.exec(p[1]);
      const end = /end="([^"]+)"/.exec(p[1]);
      if (!begin) continue;
      const words = [];
      for (const s of p[2].matchAll(/<span\b([^>]*)>([\s\S]*?)<\/span>/g)) {
        const sb = /begin="([^"]+)"/.exec(s[1]);
        if (!sb) continue;
        const txt = decodeEntities(s[2].replace(/<[^>]+>/g, ''));
        if (txt.trim() === '') continue;
        words.push({ t: parseTime(sb[1]), text: txt });
      }
      const text = decodeEntities(p[2].replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
      lines.push({ time: parseTime(begin[1]), end: end ? parseTime(end[1]) : undefined, text, words: words.length > 1 ? words : undefined });
    }
    return lines;
  }

  const providers = {
    async betterlyrics({ title, artist, duration }) {
      const d = await getJSON(`https://lyrics-api.boidu.dev/getLyrics?s=${enc(title)}&a=${enc(artist)}${duration ? '&d=' + duration : ''}`);
      const ttml = d.ttml || d.lyrics || '';
      if (!ttml) throw new Error('Sin letra en Better Lyrics');
      const lines = parseTTML(ttml);
      if (!lines.length) throw new Error('Respuesta de Better Lyrics sin líneas');
      return { provider: 'betterlyrics', synced: true, lines };
    },
    async kugou({ title, artist, duration }) {
      const q = `${artist} ${title}`;
      const s = await getJSON(`https://mobilecdn.kugou.com/api/v3/search/song?format=json&page=1&pagesize=5&keyword=${enc(q)}`);
      const song = s.data?.info?.[0];
      if (!song) throw new Error('KuGou no encontró la canción');
      const c = await getJSON(`https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=${enc(q)}&duration=${(duration || song.duration || 0) * 1000}&hash=${song.hash}`);
      const cand = c.candidates?.[0];
      if (!cand) throw new Error('KuGou no tiene letra');
      const d = await getJSON(`https://lyrics.kugou.com/download?ver=1&client=pc&id=${cand.id}&accesskey=${cand.accesskey}&fmt=lrc&charset=utf8`);
      const bytes = Uint8Array.from(atob(d.content || ''), (ch) => ch.charCodeAt(0));
      const lrc = new TextDecoder('utf-8').decode(bytes);
      const lines = parseLRC(lrc).filter((l) => !/^\s*(ti|ar|al|by|offset)\s*:/i.test(l.text));
      if (!lines.length) throw new Error('KuGou devolvió letra vacía');
      return { provider: 'kugou', synced: true, lines };
    },
    // Apple Music: pega tus tokens en Ajustes de la app (se guardan solo en este teléfono).
    async apple({ title, artist, appleId }) {
      let cfg = {};
      try { cfg = JSON.parse(localStorage.getItem('ondas_apple') || '{}'); } catch {}
      if (!cfg.dev || !cfg.user) throw new Error('Faltan los tokens de Apple Music');
      const sf = cfg.storefront || 'us';
      const headers = { Authorization: 'Bearer ' + cfg.dev, 'Music-User-Token': cfg.user, Origin: 'https://music.apple.com' };
      let id = appleId;
      if (!id) {
        const s = await getJSON(`https://amp-api.music.apple.com/v1/catalog/${sf}/search?types=songs&limit=1&term=${enc(artist + ' ' + title)}`, { headers });
        id = s.results?.songs?.data?.[0]?.id;
      }
      if (!id) throw new Error('Apple Music no encontró la canción');
      const d = await getJSON(`https://amp-api.music.apple.com/v1/catalog/${sf}/songs/${id}/syllable-lyrics`, { headers });
      const ttml = d.data?.[0]?.attributes?.ttml;
      if (!ttml) throw new Error('Apple Music sin letra para esta canción');
      return { provider: 'apple', synced: true, lines: parseTTML(ttml) };
    },
    async lrclib({ title, artist, duration }) {
      let d;
      try {
        d = await getJSON(`https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}${duration ? '&duration=' + duration : ''}`);
      } catch {
        d = (await getJSON(`https://lrclib.net/api/search?q=${enc(artist + ' ' + title)}`))[0];
      }
      if (!d) throw new Error('LRCLIB no encontró la canción');
      if (d.syncedLyrics) return { provider: 'lrclib', synced: true, lines: parseLRC(d.syncedLyrics) };
      if (d.plainLyrics) return { provider: 'lrclib', synced: false, lines: d.plainLyrics.split('\n').map((text) => ({ time: 0, text })) };
      throw new Error('LRCLIB sin letra');
    },
  };

  /* ---------- enrutador (mismos nombres que /api/* del servidor) ---------- */
  window.ClientAPI = {
    async handle(name, p) {
      if (name === 'search') return { results: await ytmSearch(p.q, p.type) };
      if (name === 'motion') return appleMotion(p.albumId || '');
      if (name === 'img') return { data: await getImageData(p.u) };
      if (name === 'cover') return hiresCover(p.title || '', p.artist || '');
      if (name === 'lyrics') {
        const fn = providers[p.provider];
        if (!fn) throw new Error('Proveedor desconocido');
        return fn({ title: p.title || '', artist: p.artist || '', duration: parseInt(p.duration || '0', 10), appleId: p.appleId || '' });
      }
      throw new Error('Ruta desconocida');
    },
  };
})();
