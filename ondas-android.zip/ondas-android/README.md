# Spotifree para Android

Reproductor con YouTube Music, interfaz estilo Apple Music con vidrio líquido, letras sincronizadas
(Better Lyrics, KuGou, Apple Music, LRCLIB), música local, modo video y portadas en movimiento.
Todo corre dentro de la app, sin servidor. Creada por Claude para Steven Pantoja.

## Cómo generar el APK (GitHub, sin Android Studio)

1. Entra a tu repositorio y sube este zip con el mismo nombre (`ondas-android.zip`). Reemplaza al anterior.
2. Abre la pestaña Actions y espera la palomita verde (unos 5 minutos).
3. En Releases baja el nuevo `app-debug.apk` e instálalo.

Spotifree se instala como una app nueva (no reemplaza a Ondas). Después de comprobar que funciona
puedes desinstalar Ondas.

## Qué trae

- **Barra inferior**: Inicio, Novedades, Radio, Biblioteca y Buscar. Inicio y Novedades salen de YouTube Music;
  Radio crea estaciones sin fin por género, artista o canción.
- **Cristal líquido ajustable**: Ajustes > Apariencia. De 0 % (paneles mate) a 100 % (translúcidos con desenfoque).
- **Animaciones**: transiciones con resorte entre secciones, portada que vuela al mini reproductor, arrastrar hacia
  abajo para cerrar el reproductor y vibración suave opcional.
- **Cuenta**: Ajustes > Añadir cuenta. Elige Spotify o YouTube, pon tu nombre, importa listas de YouTube con su enlace
  o conecta Spotify con tu propio Client ID (gratis, developer.spotify.com; dirección de retorno `spotifree://callback`).
  La música siempre suena desde YouTube Music.
- **Descargas**: botón Descargar en el reproductor y en Ajustes. Baja música con licencia libre de Internet Archive
  y de Jamendo (necesita tu Client ID gratuito de devportal.jamendo.com). Se guarda en la app y suena sin internet.
- **Biblioteca**: Me gusta, descargas, tu música del teléfono y listas propias.
- **Canvas estilo Spotify**: botón Canvas en el reproductor. Pon un video corto o GIF a una canción y se ve a pantalla completa detrás del reproductor. Ya no hay portada con distorsión.
- **Reproductor**: aleatorio, repetir (lista o una canción), temporizador de sueño, velocidad (0,75× a 2×),
  fundido suave al pausar, doble toque en la portada para dar me gusta y deslizar el mini reproductor para cambiar de canción.
- **Ecualizador de audio**: 5 bandas y presets (Graves, Vocal, Rock...). Solo actúa en música del teléfono y descargas.
- **Tu resumen**: tiempo escuchado, canciones y artistas favoritos, y la fila "Lo más escuchado" en Inicio.
- **Color de acento** a elegir, o automático según la portada.
- **Tirar hacia abajo** en Inicio y Novedades para actualizar.
- **Mi música**, **modo video**, **letras**, **ecualizador**, **modo ahorro**
  y **controles de Android** (notificación, pantalla de bloqueo, auriculares) siguen como antes.

## Notas

- El ecualizador de archivos locales usa el espectro real del audio. En canciones de YouTube es una animación
  que sigue el ritmo, porque YouTube no deja leer su audio.
- Las letras de Apple Music necesitan tus tokens (Ajustes > Apple Music).
- Las APIs de YouTube Music, Better Lyrics, KuGou, Apple y Spotify no son oficiales o pueden cambiar.
- Spotifree no descarga música de YouTube ni de Spotify.

## Fotos de artistas y tipografías
- Foto del artista (Deezer, necesita internet) junto a su nombre en el reproductor, en la búsqueda, en Inicio/Radio y en su página. Se apaga en Ajustes > Fotos de artistas.
- Cada artista conocido tiene su propia tipografía (Bebas Neue, Bungee, Pacifico, etc.); el resto recibe una de forma estable según su nombre.
- Toda la app usa Inter en negrita (estilo iOS). Las fuentes van dentro del APK (carpeta `www/fonts`).

## Arreglos de reproducción
- Portadas/álbum: solo se usa el resultado que coincide en título, artista y duración; si no hay coincidencia segura se queda la portada de YouTube Music.
- Si la música se pausa sola, se traba o se queda cargando, la app la reanuda o recarga en el mismo segundo. Pausar a mano se respeta.
- La app mantiene el reproductor vivo en segundo plano (servicio con notificación).

## Inicio estilo Apple Music
Título grande «Escuchar ahora», Recientes en tarjetas grandes con el nombre sobre la portada, barra inferior flotante en píldora con la búsqueda aparte y mini reproductor en píldora.

## Cristal líquido adaptable
Burbuja de cristal en la barra: se estira al cambiar de pestaña y se puede arrastrar. Si el teléfono va justo, baja solo de nivel (alto, medio, ahorro). Al apagar Modo ahorro en Ajustes vuelve a alto.

## Reproductor estilo Apple Music
Agarrador arriba, portada grande, título con estrella y más, tiempo restante (-3:29), rebobinar/pausa/adelantar grandes y fila de iconos abajo (letra, cola, aleatorio, repetir, video, canvas, descargar). La letra tiene cabecera con portada y texto grande a la izquierda.

## Más fuentes de letra
NetEase, QQ Música y Lyrics.ovh (solo texto) además de Better Lyrics, KuGou, Apple Music y LRCLIB. Auto las prueba en orden.

## Todo en cristal
Filas, fichas, hojas, menús y todo el reproductor en cristal líquido, con animaciones de entrada, brillo que recorre la barra y respiración del botón de play. Los efectos pesados se apagan solos en teléfonos justos o con Modo ahorro.

## Volumen
El deslizador controla el volumen real del teléfono (sonido multimedia) y sigue a los botones físicos.

## Rosado y más ajustes
Color por defecto rosado (como Apple Music). Nuevos ajustes: animaciones (completas/suaves/ninguna), fondo negro puro, pantalla encendida, tiempo restante, y sección Letra (tamaño, alineación, difuminado).

## Dúos
Si la letra trae varios cantantes (Better Lyrics / Apple Music), cada uno va en su lado: el primero a la izquierda, el segundo a la derecha, los coros al centro.

## Cristal extremo y portada en el reproductor de Android
- Ajustes > Cristal extremo: refracción tipo lente con aberración cromática (solo en nivel alto).
- La portada aparece en la notificación y la pantalla de bloqueo.

## Rendimiento del cristal
Calidad automática/extrema/alta/media/ahorro, lente de una sola pasada, desenfoque simple mientras se desliza, barras ocultas con el reproductor abierto, resplandor sin repintado, ahorro con batería baja. Ajustes: desenfoque y brillo de bordes.

## Música del teléfono
Ajustes > Escanear música del teléfono (o Biblioteca > Teléfono): lee la música con MediaStore, con portadas, filtro, reproducir todo y aleatorio. Aparece también en los resultados de búsqueda. Pide el permiso de audio.

## Cambios: modo plano, portada 3D, todas las fuentes juntas
- **Sin cristal líquido** por defecto (Ajustes > Cristal líquido para volver a activarlo).
- **Portada 3D**: sombras en capas, brillo del color de la portada e inclinación suave con el giroscopio o el dedo.
- **Búsqueda unificada**: YouTube Music + Spotify (si conectas la cuenta) + Apple Music (iTunes) + Deezer + SoundCloud (necesita Client ID en Ajustes). Chips para elegir una sola fuente. Las canciones de Apple/Deezer suenan emparejadas con YouTube Music.
- **Segundo plano**: servicio en primer plano, MediaSession, WebView siempre "visible" y aviso para quitar la optimización de batería (Ajustes > Sonar con la pantalla apagada).
- **Barra de estado**: toma el color de la canción (y la de navegación también), con transición suave.
- **Gama baja** (Ajustes > Optimizar para gama baja, Automático por defecto): se activa con poca RAM (<7 GB), Android 10 o menor, o procesadores Snapdragon 4xx/6xx, Helio, Unisoc y similares. Quita sombras y filtros, fondo estático con el color de la canción, portada animada y fondo móvil apagados la primera vez, 20 cuadros por segundo en el visualizador, listas que solo pintan lo visible y sin inclinación 3D. Gama alta queda igual.
- **Sin retraso al salir**: si el sistema pausa el audio al salir de la app, se reanuda al instante (antes esperaba 0.4 s o más) y también desde onPause de Android.
- **Mezcla entre canciones**: botón en cada lista y en la cola (y duración en Ajustes, 3 a 12 s). La canción se apaga y la siguiente sube, sin silencio; es un fundido encadenado, no un solape real.
- **Hoja de mezcla**: al tocar el botón de mezcla (listas, cola o Ajustes) se abre un editor con gráfico de la transición, ajustes predefinidos (Automática, Fundido, Corte rápido, Club, Vinilo, Personalizada), duración, curva de volumen y efecto; botón Probar la mezcla.
- **Página de lista estilo Apple Music**: portada grande con 3D, fondo con el color/portada, título centrado, botones aleatorio · Reproducir · añadir; mezcla y más arriba a la derecha.
- **Añadir música a una lista**: botón + en la lista (y en la lista vacía): buscador con tus Me gusta/recientes y resultados de YouTube Music, con +/✓ por canción.
- **Sugerencias al escribir** en el buscador: sugerencias de búsqueda (con lo que falta en negrita) y 4 canciones en vivo, en cada letra.
- **Mezcla editable**: arrastra los bordes del gráfico para la duración y el punto de la curva para darle forma; texto "Mezclando…" que brilla (también en el reproductor mientras se mezcla), línea verde de progreso y final fundido editable (3 a 15 s, 5 s por defecto).
- **Vista previa de la mezcla**: al abrir el editor suena el fragmento del punto de mezcla en bucle (se apaga y vuelve a subir con tus ajustes), con barra para moverte por toda la canción y pausa; al cerrar vuelve a donde estabas. "Probar con la siguiente canción" hace la transición real.

## Actualización definitiva (resumen)
- **Modo gráfico** (Ajustes > Apariencia): Automático, Light Glass (gama baja), Smooth Glass (media), Full Glass (alta) y Sólido. Respeta el movimiento reducido del sistema.
- **Buscador unificado** con YouTube Music, YouTube Data API (con tu clave), Spotify, Apple Music (API o iTunes), Deezer, Jamendo, Internet Archive y SoundCloud; los resultados aparecen según llega cada proveedor, con caché de 6 minutos y búsqueda automática en los demás si el elegido no la tiene.
- **Disponibilidad**: menú de cada canción > Disponibilidad (búsqueda / reproducción / descarga por separado).
- **Descargas**: botón en cada canción y en el reproductor, progreso y porcentaje, cancelar, duplicados, espacio usado y libre, chip flotante; solo con licencia libre (Jamendo, Internet Archive).
- **Audio de fuentes libres** servido por la app (visualizador y ecualizador funcionan).
- **Calidad de audio** en el reproductor (formato y origen reales; nada inventado).
- **Copia de seguridad** y copia automática previa a la migración; ver INSTRUCCIONES_APIS.md.
- Aviso de **sin conexión**.

## Letras sincronizadas: más fuentes + nuevo reproductor

- Nuevas fuentes de letra (Ajustes › Letra, o el menú ⋯ de la vista de letra): **LRCLIB (amplia)** (búsqueda con título limpio, solo versiones sincronizadas), **SimpMusic** (por videoId de YouTube) y **Subtítulos YouTube** (si el video trae subtítulos). El modo Auto las prueba en este orden: Better Lyrics, Apple, LRCLIB, SimpMusic, LRCLIB amplia, KuGou, NetEase, QQ, subtítulos, texto plano.
- Si una fuente falla, se reintenta con el título limpio (sin "feat.", "(Remastered)", "- Remix"…).
- ⚠ Estas fuentes no se pudieron probar contra sus servidores reales desde el entorno de desarrollo; si alguna cambia su API simplemente falla y el modo Auto pasa a la siguiente.
- Reproductor: portada a pantalla completa tras la barra de estado, título/artista sobre la portada, una línea de letra con flecha, controles planos, fila inferior (letra, aleatorio+repetir, cola) y botones Video/Canvas/Descargar. La vista de letra comparte los mismos controles (el botón de letra se resalta) y muestra «Letra de <fuente>».
- Los botones de globo/traducir de la referencia no se agregaron porque no hay traducción real implementada.

## Letra: puntos de espera, brillo por palabra, modo limpio y pantalla completa

- Puntos de espera (●●●) al inicio, en silencios largos entre estrofas y en las líneas vacías de la letra; se llenan mientras pasa el silencio y desaparecen cuando vuelve a cantar.
- La palabra que se canta se ilumina progresivamente. Si la fuente trae tiempos por palabra (Better Lyrics/Apple) se usan; si no, el tiempo de la línea se reparte según el largo de cada palabra (es una estimación).
- Con la letra abierta solo se ven el título y la letra. Los controles aparecen al tocar la zona de abajo o la portada pequeña, y se ocultan solos a los 4,5 s. Para cerrar la letra: botón de letra (con los controles visibles) o el gesto de atrás.
- Pantalla completa real: barras de estado y navegación transparentes; la portada y el fondo se dibujan detrás. Los márgenes se leen en Android (`Native.insets`) y se aplican a `--sat`/`--sab`. Con el teclado abierto la página se encoge.

- Letra alineada a la izquierda por defecto (los dúos siguen cada uno en su lado; se cambia en Ajustes › Alineación).
- Video, Canvas y Descargar ya no están en la pantalla del reproductor: están en el menú ⋯ de la canción.

## Géneros con foto, Biblioteca estilo Apple Music
- Radio (estaciones) y Explorar todo: cada género lleva la foto de un cantante representativo (ver `GENRE_ARTIST` en `js/views.js`), en gris y teñida con el color del botón; en Radio va como portada inclinada. Hay más géneros (Cumbia, Vallenato, Bachata, Corridos tumbados, Trap, Country, Reggae, Punk, Soul, Blues, House). La foto se busca con el mismo servicio de fotos de artistas de la app; si no llega, el botón queda solo con su color.
- Biblioteca: lista Playlists / Artistas / Álbumes / Canciones / Me gusta / Descargas / Mi música / Del teléfono / Tu resumen / Ecualizador, y «Agregadas recientemente». Artistas y Álbumes se arman con tus canciones guardadas (me gusta, descargas, tu música, teléfono).
- Degradado bajo la barra de estado para que el contenido no choque con la hora y los iconos.

## Última reproducción y cierre
- La app guarda cada pocos segundos la cola y el segundo en que ibas (`js/resume.js`). Al abrirla de nuevo aparece en el mini reproductor, en pausa; al tocar reproducir carga la canción y salta a ese segundo (es aproximado). Los archivos locales sueltos no se restauran.
- Al salir con el botón de inicio la música sigue; al quitar la app de recientes se detiene la notificación, la reproducción y el proceso (`PlayerService.onTaskRemoved`).

## Inicio, Novedades y Radio estilo Apple Music; letra con puntos y barrido suave
- Títulos grandes con línea debajo y menú ⋮ rojo (Ajustes, Cuenta y acciones de cada pantalla). Inicio: «Top selecciones para ti» (la primera fila de YouTube Music en tarjetas grandes), «Reproducciones recientes ›» y el resto. Novedades: «NUEVO ÁLBUM» con tarjeta grande en carrusel y «Canciones nuevas destacadas ›» en columnas de 4. Radio: cuadrícula de 3 columnas y «Al aire ahora» con tarjetas grandes con la foto del cantante. No se usan logos ni marcas de Apple.
- Letra: puntos del tamaño de la letra que se llenan, brillan y se encogen al terminar el silencio; el barrido de cada palabra tiene borde suave.

- Barra inferior estilo Apple Music: mini reproductor plano de borde a borde y pestañas (Inicio, Novedades, Radio, Biblioteca, Buscar) pegadas al borde de la pantalla, con el color del fondo del sistema debajo del gesto de inicio.

- Ilustración animada (Ajustes): cuando el álbum tiene portada animada en Apple Music, la portada se mueve (solo con la pantalla de reproducción abierta y sonando). No todos los álbumes la tienen, la búsqueda se hace por título/artista y no pude probarla con el servidor real. Se quitaron las barras del ecualizador que bailaban sobre la portada.

- Canvas automático (Ajustes): ilustración animada de Apple → video oficial de YouTube (modo Video del reproductor) → fondo animado por género (Pixabay, licencia libre, con tu clave gratis; el género sale de iTunes). Tu canvas propio siempre tiene prioridad. La clave de Pixabay no entra en las copias de seguridad. No se usa el Canvas de Spotify (no tiene API oficial).

## Reproductor plano (estilo Apple Music)
Portada a pantalla completa que se funde con el color de la portada, título/artista grandes con ★ y ⋮, tiempo restante, controles planos, solo letra y cola abajo. Aleatorio y Repetir pasaron al menú ⋮; Video/Canvas/Descargar siguen en ⋮. Volumen y filas extra ocultos.

## Vista de letra plana
Cabecera de la letra sin cápsula: miniatura, título/artista, ★ y ⋮ en círculos translúcidos. El botón de letra activo se ve como cuadro relleno.

## Menú ⋮ estilo Apple Music
Hoja plana oscura con portada grande, título, artista en rojo, álbum en gris e iconos rojos. "Iniciar radio" ahora se llama "Crear estación" y "Temporizador de sueño" → "Temporizador de reposo". La pantalla de la fila ya tenía ese diseño.

## Botón de la fila (cola) como el ejemplo
El botón de la cola usa el ícono de lista con viñetas y, al abrirse la fila dentro del reproductor, queda como cuadro relleno (igual que el de letra). Iconos inferiores más grandes y en tono de la portada.

## Animaciones + audio sin retraso al salir/entrar
- Animaciones suaves (solo transform/opacity): cabeceras y tarjetas al entrar, filas, menú ⋮, entrada escalonada del reproductor, pulsación con muelle, latido de la estrella. No se aplican en modo ligero/rendimiento.
- Audio: tras salir o volver a la app hay 5 s de gracia en los que el vigilante ya no recarga ni reinicia el video (esas recargas causaban los cortes y retrasos); también se ignora el vigilante mientras la app está en segundo plano.

## "Reproduciendo" con brillo y botones animados
Entre los controles y la fila de iconos aparece "Reproduciendo" con un brillo que lo recorre (muestra "En pausa" cuando está pausado). Play/pausa con rebote al cambiar, anillo suave mientras suena y anterior/siguiente se desplazan al tocarlos.

## Puntos de la letra animados
Los 3 puntos (intro o silencio) entran uno a uno con rebote, respiran con brillo mientras esperan y al terminar se encogen uno tras otro y el espacio se cierra suave. Se desactivan en modo ligero/rendimiento.

## Ilustración animada activada por defecto + portada cuadrada sin animación
- "Ilustración animada" y "Canvas automático" quedan activados (también para quien ya tenía la app: se activan una sola vez; puedes apagarlos en Ajustes).
- Canciones sin ilustración/video animado se ven con la portada cuadrada de esquinas redondeadas y fondo oscuro del color de la portada. Con ilustración animada se mantiene la pantalla completa.

## Ajustes por páginas (estilo lista oscura)
Ajustes ahora tiene título grande, flecha atrás, buscador (filtra opciones reales) y una lista de categorías que abren cada una su página: Apariencia, Reproducción, Letra, Música y descargas, Copia de seguridad, Acerca de (y Apple Music si hay tokens). Todas las opciones anteriores se conservan. Opciones nuevas reales: "Portada a pantalla completa", "Mostrar barra de volumen" y "Mostrar «Reproduciendo»".

## Destellos en «Reproduciendo» + letra en ese lugar
- «Reproduciendo» y «En pausa» tienen rayitos de luz que cruzan el texto (más rápidos al sonar).
- Doble toque en ese texto: aparece la línea actual de la letra en el mismo sitio, letra por letra con brillo, y se renueva con cada línea. Otro doble toque vuelve al texto. Se apagan los efectos en modo ligero/rendimiento.

## Letra palabra por palabra en «Reproduciendo»
Con doble toque, la línea que aparece abajo ahora se ilumina palabra por palabra siguiendo al cantante (cuando la letra trae tiempos por palabra); si no, aparece letra por letra.

## Voces de fondo en la letra + difuminado al abrir controles
- Las voces dobles/coros (texto entre paréntesis en la fuente de la letra) se muestran con letra pequeña debajo de la línea principal y brillan palabra por palabra igual que la normal. Una línea entera de coros va más pequeña.
- Al abrir los controles sobre la letra (o la fila), la zona de atrás se difumina con una transición suave; en modo ligero queda un degradado oscuro.

## Perfil de artista (estilo Apple/Spotify) y sin Internet Archive
- Todos los artistas: foto a pantalla completa, nombre grande centrado con su tipografía, seguidores, botón aleatorio + "Reproducir" blanco y lista "Popular" numerada.
- Se quitó Internet Archive de las descargas, la búsqueda por fuentes y los textos. Quedan las demás fuentes (YouTube Music, Spotify, Apple Music, Deezer, YouTube API, Jamendo, SoundCloud).

## "Logos" de artista animados
El nombre en el perfil de artista lleva un acabado propio (oro, hielo, neón rosa, fuego, perla, esmeralda, naranja suave) según el artista, con su tipografía, resplandor, un destello que cruza y un filete que se dibuja debajo. Algunos artistas tienen estilo elegido a mano; el resto recibe uno fijo según su nombre. No son los logos oficiales (no se pueden descargar): son diseños propios.

Los logos de artista quedan en blanco y negro (plata/blanco con destello), sin colores.

## Modo horizontal
En horizontal el reproductor se divide: a la izquierda portada, título, barra y controles; a la derecha la letra siempre visible, con el brillo palabra por palabra. Se activa solo al girar el teléfono (si el giro automático está encendido). Sin anotaciones de Genius.

## Horizontal: botón para dejar solo la portada
En horizontal hay un botón arriba a la derecha (ícono de letra): deja solo la portada y los controles centrados, o vuelve a mostrar la letra. Recuerda tu elección.

## Modo karaoke
Botón (micrófono con destellos) en la vista de letra y en horizontal: letra grande y deslizador "Voz del cantante". Con música local/descargada se quita la voz restando izquierdo−derecho (la voz suele ir al centro) y se devuelven los graves; en una prueba con un tono central y otro lateral el central bajó unos 20 dB. En YouTube Music no hay acceso al audio, así que el deslizador sale bloqueado con un aviso. La voz nunca queda 100 % limpia.

## Buscador estilo Apple Music + ajuste «Fuentes»
- Buscador plano con flecha roja a la izquierda, ✕ a la derecha, "Artistas, canciones, letras y…", y el texto buscado seguido de "en Spotifree" en gris. Pestañas en mayúsculas con subrayado rojo, resultados con "Canción · Artista", artista destacado sin tarjeta y búsquedas recientes en filas.
- Ajustes > Fuentes: "Todas las fuentes" o elegir cuáles usar al buscar (YouTube Music, Spotify, Apple Music, Deezer, YouTube API, Jamendo, SoundCloud). Siempre queda al menos una. Inicio sigue viniendo de YouTube Music.

## Horizontal en pantalla completa
Al girar el teléfono se ocultan la hora, la batería y la barra de navegación (se ven un momento al deslizar desde el borde) y el contenido cubre también la zona de la cámara. En vertical todo vuelve a mostrarse. Cambio en MainActivity.kt (sin compilar aquí).

## Mezcla rediseñada + etiqueta «Mezclando»
- La etiqueta bajo la carátula pasa a **Mezclando** (con destello del color de acento) unos 3 s antes de la mezcla y mientras ocurre; después vuelve a «Reproduciendo».
- Hoja de mezcla: deslizador de duración (1–12 s) con valor en vivo, **Entrada suave al seguir** (el volumen sube poco a poco al quitar la pausa, solo con la mezcla activada). Se conservan presets, curva, efectos, vista previa, final fundido y prueba.
- Límite: un solo reproductor (sin EQ ni beatmatching). Probado con Playwright, no en un teléfono real.

## Reverberación progresiva en la mezcla
- Interruptor «Reverberación progresiva» en la hoja de mezcla: la reverb (sala sintética estéreo, alimentada del centro) crece mientras sale la canción y se disipa en la siguiente, con subida/bajada suave (~0,7 s). Solo en música local/directa; con YouTube no hay acceso al audio.
- La etiqueta «Mezclando»/«Reproduciendo» ahora entra con desvanecimiento (difuminado → nítido).
- Probado solo en el navegador de pruebas, no en teléfono.

## Motor de audio estable
- Web Audio con `latencyHint: "playback"` (búfer grande, frecuencia nativa del teléfono): menos cortes.
- Vigilante de fluidez: si la pantalla va a tirones mientras suena, se activa sola la versión ligera (sin efectos pesados) y vuelve tras ~30 s fluidos.
- Al volver a la app se reanuda el contexto de audio y el audio local si se había pausado solo.
- No probado en un teléfono real; el reproductor de YouTube no se puede controlar más a fondo desde la app.

## Tarjetas «Top selecciones» con texto sobre la portada
- Título y artista van sobre la portada con degradado y desenfoque progresivo (se apaga en modo ligero).
- No se incluyó el logo de la manzana de Apple (marca registrada).

## Búsqueda y reproductor como en las capturas
- Resultados de búsqueda planos: sin tarjetas, carátula de 72 px, separadores finos, ⋮ vertical, sin duración ni descarga en la fila; pestañas a todo el ancho; el título «Buscar» se oculta al ver resultados.
- Reproductor: carátula grande con reflejo debajo (se apaga en modo ligero); artista en la misma tipografía que el resto.
- No se añadió el icono de transmitir (cast) ni la pestaña «Tu biblioteca» en la búsqueda: no funcionarían y no se simulan.

## Carátula en movimiento: solo si existe
- El canvas automático ya no pone el video de YouTube ni un fondo por género cuando la canción no tiene ilustración animada de Apple: esas canciones se quedan con su carátula normal.
- Sin probar con datos reales (no hay red en el entorno de pruebas).

## Mezcla: más opciones
- Nuevos ajustes: «Sin pausa» (1 s, entra antes), «Cola de eco» (9 s con reverb) y la opción «Saltar el final» (0–12 s): la siguiente canción entra antes de que termine la actual, útil cuando acaba en silencio. La mezcla/final fundido de la última canción no se ve afectada.
- Efecto visual: la carátula respira con el color de acento mientras se mezcla (se apaga en modo ligero).
- Probado solo en el navegador de pruebas; la reverb solo suena con audio local/directo.

## Portada que se quema
- Al cambiar de canción (con el reproductor abierto) la carátula anterior se quema desde un punto al azar, con borde de brasas, y deja ver la nueva. Ajuste «Portada que se quema» en Ajustes (activo por defecto); se apaga solo en modo ligero.
- Probado en el navegador de pruebas, no en un teléfono real.

## Portada que se quema: color de la portada
- El borde de la quemadura usa los colores de la carátula (en vez de naranja).

## Audio Pipeline (Ajustes)
- Hoja con la ruta de la señal: Pista → DSP → Salida, con datos reales (fuente, motor, ecualizador, voz, mezcla/reverb, frecuencia y latencias del motor Web Audio). Lo que la app no puede leer (formato, bits, bitrate, dispositivo de salida) no se inventa: aparece como «—» o con una nota.
- No hay acceso al decodificador ni al dispositivo de salida de Android desde el WebView.

## Motor de audio (Ajustes)
- Selector «Motor de audio»: Automático (según el teléfono: ligero → Ahorro, si no → Estable), Estable (búfer grande), Ahorro (no monta la cadena Web Audio si no hay ecualizador, voz ni reverb activos: menos CPU y el visualizador usa la simulación) y Baja latencia.
- Solo afecta a música local y directa; el audio de YouTube lo maneja su propio reproductor y no se puede cambiar.
- Se muestra en «Audio Pipeline». Sin probar en un teléfono real.

## Calidad de audio + Ajustes en grupos
- Ajustes › Calidad de audio: nivel para Wi-Fi y otro para datos móviles (Alta, Media, Baja, Ultra patata), con hoja inferior como en la referencia. Efecto real: baja la resolución del video oculto de YouTube, desactiva portadas HD y la ilustración animada, y «Ultra patata» además pone el modo ligero. El bitrate del audio lo decide cada fuente; la app no puede forzarlo, y no se muestran MB/h inventados.
- Raíz de Ajustes agrupada en tarjetas con título (Audio / Ajustes / Datos) y difuminado a negro en la parte superior del contenido.
- No se añadió JioSaavn: no es una fuente autorizada. Las fuentes se eligen en «Fuentes».
- Detección de datos móviles con navigator.connection (si el WebView no la expone, se usa el nivel de Wi-Fi). Sin probar en teléfono real.

## Página de artista completa (todos los artistas)
- Al abrir cualquier artista se busca su canal en YouTube Music (nueva ruta `artistid`) y se carga su página: Top canciones, Álbumes, Sencillos y EP, Videos, Aparece en, «Fans también escuchan» (artistas similares en círculos) y un bloque «Información» con la biografía (MÁS para desplegar). Si no se encuentra el canal, se usa la página anterior.
- Las secciones que existan dependen de lo que YouTube Music devuelva para cada artista.
- No incluye «Agregar»/último lanzamiento, ciudad natal ni fecha de nacimiento: YouTube Music no los entrega.
- Probado con datos de mentira en el navegador; la lectura real de YouTube Music no se pudo probar sin red.

## Álbumes con ilustración animada a pantalla completa
- La página de un álbum usa la versión vertical (alta) de la ilustración animada de Apple cuando existe (si no, la cuadrada), a todo el ancho arriba, con degradado a negro y título centrado encima. Solo para álbumes que la tengan; se desactiva en Calidad baja/ultra patata y en modo ligero.
- No se muestra en las tarjetas pequeñas de las listas (sería cargar muchos videos a la vez).
- Probado con un video de prueba en el navegador; los videos reales de Apple no se pudieron comprobar sin red.

## Imágenes de golpe
- Las portadas ya no usan carga perezosa: se piden todas juntas apenas llegan los datos (inicio, listas, siguiente canción) y aparecen sin el fundido lento. El caché del WebView las guarda.
- La grabación de pantalla usada para probar la animación del álbum no forma parte de la app.

## Movimiento para álbumes sin ilustración de Apple + barra de progreso
- Álbumes sin ilustración animada: la portada llena la parte de arriba con un movimiento hecho por la app (zoom lento, deriva y destello de luz). No es la animación de Apple; se apaga en modo ligero. No se encontró otra fuente legítima de ilustraciones animadas.
- Reproductor: barra de progreso gruesa y redondeada como en Apple Music. El resto de los controles ya eran planos en esta versión; la captura con botones negros corresponde a un APK anterior.

## Animación de inicio y nuevos ajustes
- Al abrir la app se muestra el GIF del logo (`splash.gif`, el que mandó el usuario) una vuelta completa (mín. ~2,3 s, máx. 5 s) y se desvanece. Ajuste «Animación de inicio» para quitarla.
- Nuevos ajustes en Reproducción: Saltar el inicio, Saltar el final, Normalizar volumen (solo audio local/directo), Descargar solo con Wi-Fi, Canciones en caché (límite 30/60/150) y Borrar caché.
- La caché guarda letras de lo escuchado en el teléfono. El audio de YouTube no se puede guardar en caché (lo maneja su propio reproductor).
- No incluido de la lista propuesta: pausa al desconectar auriculares, tema negro puro, tamaño de letra de la app, estéreo ampliado, velocidad por canción, volumen al conectar auriculares.

## Más animaciones
- Ajustes (categorías y páginas), hojas inferiores (calidad, Audio Pipeline, mezcla…), menús, sugerencias de búsqueda, portada de álbum (título/botones), información de artista, rieles de las páginas y secciones que aparecen al hacer scroll; rebote en la pestaña activa, interruptores y botones con efecto al tocar.
- Se respetan Animaciones «Suaves/Ninguna» y el modo ligero.

## Reproductor como Apple Music (controles)
- Barra de progreso más fina y redondeada, controles más grandes y separados, botones de estrella y ⋮ más pequeños.
- Etiqueta «E» (explícito) junto al título en el reproductor y en las filas, solo cuando YouTube Music marca la canción como explícita (se lee del dato real).
- No se añadió el icono de transmitir (cast): no funcionaría.

## Animaciones en todos los modos y sin cristal líquido
- Las animaciones (entradas, deslizamientos, destellos, portada que se quema, etc.) ya no se apagan en modo ligero ni en calidad baja/ultra patata; los ajustes de animación se restablecen a «Completas» una vez. Siguen apagándose con «Ninguna».
- Cristal líquido retirado: superficies sólidas, sin desenfoque de fondo ni refracción; se ocultan sus ajustes.
- Riesgo: en teléfonos muy lentos las animaciones pueden ir a tirones; el vigilante de fluidez ya no las quita, así que «Animaciones › Ninguna» sigue siendo la salida.

## Sección «Animaciones» en Ajustes
- Reúne: nivel de animaciones, animaciones en modo ligero (nuevo), fondo animado, canvas, ilustración animada, portada que se quema, animación de inicio y canvas automático.
- Corregido: el interruptor «Ilustración animada» compartía id con el selector de animaciones y nunca funcionaba; ahora tiene el suyo.
- La clave de Pixabay queda oculta: el fondo por género se retiró.

## Carátula en movimiento en el reproductor
- La carátula del reproductor se mueve mientras suena: zoom lento, deriva ligera y un destello de luz que la cruza (se pausa al pausar la música). Se detiene si la canción ya tiene canvas/ilustración animada de Apple, y con Animaciones › Ninguna.

## Canvas retirado
- Se quitó la función de Canvas (video corto por canción: ajustes, botón y borrado). Quedan la ilustración animada de Apple (en el reproductor y en los álbumes) y las animaciones de portada hechas por la app.

## Aviso de actualización
- Ajustes › Acerca de: «Avisar de actualizaciones», campo «Repositorio de GitHub» (usuario/repositorio) y «Buscar actualizaciones». La app consulta la última Release (etiqueta `build-N`) y la compara con `version.json` (`build`, que escribe el workflow); si N es mayor muestra una barra «Nueva versión disponible» con «Descargar».
- Hay que reemplazar el workflow del repositorio por `WORKFLOW_actualizaciones.yml` (no va dentro de `.github` en este zip). Sin ese workflow no hay Releases y el aviso no tiene de dónde leer.
- No probado con un repositorio real; la instalación del APK la hace Android al abrir el archivo descargado.

## Reproductor tipo "Nadie"
Portada a todo el ancho que se funde con el color, sin reflejo; título a la izquierda, ★ y ⋮ a la derecha; controles sin círculos y sin aplastarse.

## Optimización y Hz
Ajustes: "Tasa de refresco" (Automática/60/90/120 según la pantalla). Fondo ambiental sin desenfoque animado, animaciones ocultas en pausa, listas con content-visibility, lienzo a ~60 fps en pantallas de 120 Hz.

## Portada 3D
Portada con perspectiva y sombra profunda sobre el color de la canción, que llena toda la pantalla (también bajo la barra de estado).

## Ajustes nuevos
Reproducción (sin esperar, audífonos, Bluetooth, volumen máximo, radio infinita, sincronía de letra), Apariencia (tema, texto, pestaña inicial, pestañas visibles), Letra (tipo, traducción, pronunciación), Datos y seguridad (ahorro de datos, historial, caché, bloqueo, portada en bloqueo, restablecer) y Acerca de (compilación, reportar problema).

## Más funciones
Tarjeta para compartir (imagen), modo coche, audio 8D y graves extra, ecualizador y volumen por canción/artista, listas inteligentes, resumen como imagen, forma de portada, alto contraste, negrita, reducir movimiento 3D, agitar para saltar y compartir enlaces de YouTube hacia la app.

## Jamendo quitado
Se quitó Jamendo (búsqueda, descargas, Client ID y opción FLAC). Descargas queda como gestor de lo que ya descargaste.

## Portadas sin internet
Ajustes › Datos y seguridad: guarda las portadas de tus Me gusta, listas, recientes y cola para verlas sin conexión (Cache API). Se borran con «Borrar caché».

## Música que se puede guardar (Audius)
En Descargar música buscas artistas independientes de todo el mundo (Audius, API pública). Solo se pueden guardar las canciones que el artista permite descargar; las demás se escuchan en streaming desde la búsqueda.

## Atajos y widget
Ajustes > Atajos y widget: añadir el widget (canción actual con anterior/pausa/siguiente), elegir los botones de los lados de la notificación (anterior, me gusta, aleatorio, repetir, siguiente), y abrir directo el reproductor. El resumen tiene pestañas por año ("Resumen 2026"); se junta desde que instalas esta versión.

## Compatibilidad
Funciona desde Android 7.0 (API 24). En teléfonos viejos o de poca memoria se activa solo el modo ligero (sin desenfoques ni sombras pesadas; las animaciones suaves se mantienen). Para que vaya bien en Android 7 conviene tener «Android System WebView» actualizado desde Play Store.

## Instalar actualizaciones sin errores
Desde la versión 1.7 Beta todas las compilaciones van firmadas con la misma llave (`app/debug.keystore`) y su número de versión sube con cada compilación. Así Android instala cada APK nuevo encima del anterior. La primera vez hay que desinstalar la versión vieja (antes, haz una copia en Ajustes > Copia de seguridad), porque estaba firmada con otra llave.
