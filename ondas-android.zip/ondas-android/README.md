# Spotifree para Android

Reproductor con YouTube Music, interfaz estilo Apple Music con vidrio líquido, letras sincronizadas
(Better Lyrics, KuGou, Apple Music, LRCLIB), música local, modo video y portadas en movimiento.
Todo corre dentro de la app, sin servidor. Creada por Claude para Steven Pantoja.

## Cómo generar el APK (GitHub, sin Android Studio)

1. Entra a tu repositorio y sube este zip con el mismo nombre (`ondas-android.zip`). Reemplaza al anterior.
2. Abre la pestaña Actions y espera la palomita verde (unos 5 minutos).
3. En Releases baja el nuevo `app-debug.apk` e instálalo.

Spotifree se instala como una app nueva (no reemplaza a Ondas). Después de comprobar que funciona
puedes desinstalar Ondas.

## Qué trae

- **Barra inferior**: Inicio, Novedades, Radio, Biblioteca y Buscar. Inicio y Novedades salen de YouTube Music;
  Radio crea estaciones sin fin por género, artista o canción.
- **Cristal líquido ajustable**: Ajustes > Apariencia. De 0 % (paneles mate) a 100 % (translúcidos con desenfoque).
- **Animaciones**: transiciones con resorte entre secciones, portada que vuela al mini reproductor, arrastrar hacia
  abajo para cerrar el reproductor y vibración suave opcional.
- **Cuenta**: Ajustes > Añadir cuenta. Elige Spotify o YouTube, pon tu nombre, importa listas de YouTube con su enlace
  o conecta Spotify con tu propio Client ID (gratis, developer.spotify.com; dirección de retorno `spotifree://callback`).
  La música siempre suena desde YouTube Music.
- **Descargas**: botón Descargar en el reproductor y en Ajustes. Baja música con licencia libre de Internet Archive
  y de Jamendo (necesita tu Client ID gratuito de devportal.jamendo.com). Se guarda en la app y suena sin internet.
- **Biblioteca**: Me gusta, descargas, tu música del teléfono y listas propias.
- **Canvas estilo Spotify**: botón Canvas en el reproductor. Pon un video corto o GIF a una canción y se ve a pantalla completa detrás del reproductor. Ya no hay portada con distorsión.
- **Reproductor**: aleatorio, repetir (lista o una canción), temporizador de sueño, velocidad (0,75× a 2×),
  fundido suave al pausar, doble toque en la portada para dar me gusta y deslizar el mini reproductor para cambiar de canción.
- **Ecualizador de audio**: 5 bandas y presets (Graves, Vocal, Rock...). Solo actúa en música del teléfono y descargas.
- **Tu resumen**: tiempo escuchado, canciones y artistas favoritos, y la fila "Lo más escuchado" en Inicio.
- **Color de acento** a elegir, o automático según la portada.
- **Tirar hacia abajo** en Inicio y Novedades para actualizar.
- **Mi música**, **modo video**, **letras**, **ecualizador**, **modo ahorro**
  y **controles de Android** (notificación, pantalla de bloqueo, auriculares) siguen como antes.

## Notas

- El ecualizador de archivos locales usa el espectro real del audio. En canciones de YouTube es una animación
  que sigue el ritmo, porque YouTube no deja leer su audio.
- Las letras de Apple Music necesitan tus tokens (Ajustes > Apple Music).
- Las APIs de YouTube Music, Better Lyrics, KuGou, Apple y Spotify no son oficiales o pueden cambiar.
- Spotifree no descarga música de YouTube ni de Spotify.

## Fotos de artistas y tipografías
- Foto del artista (Deezer, necesita internet) junto a su nombre en el reproductor, en la búsqueda, en Inicio/Radio y en su página. Se apaga en Ajustes > Fotos de artistas.
- Cada artista conocido tiene su propia tipografía (Bebas Neue, Bungee, Pacifico, etc.); el resto recibe una de forma estable según su nombre.
- Toda la app usa Inter en negrita (estilo iOS). Las fuentes van dentro del APK (carpeta `www/fonts`).

## Arreglos de reproducción
- Portadas/álbum: solo se usa el resultado que coincide en título, artista y duración; si no hay coincidencia segura se queda la portada de YouTube Music.
- Si la música se pausa sola, se traba o se queda cargando, la app la reanuda o recarga en el mismo segundo. Pausar a mano se respeta.
- La app mantiene el reproductor vivo en segundo plano (servicio con notificación).

## Inicio estilo Apple Music
Título grande «Escuchar ahora», Recientes en tarjetas grandes con el nombre sobre la portada, barra inferior flotante en píldora con la búsqueda aparte y mini reproductor en píldora.

## Cristal líquido adaptable
Burbuja de cristal en la barra: se estira al cambiar de pestaña y se puede arrastrar. Si el teléfono va justo, baja solo de nivel (alto, medio, ahorro). Al apagar Modo ahorro en Ajustes vuelve a alto.

## Reproductor estilo Apple Music
Agarrador arriba, portada grande, título con estrella y más, tiempo restante (-3:29), rebobinar/pausa/adelantar grandes y fila de iconos abajo (letra, cola, aleatorio, repetir, video, canvas, descargar). La letra tiene cabecera con portada y texto grande a la izquierda.

## Más fuentes de letra
NetEase, QQ Música y Lyrics.ovh (solo texto) además de Better Lyrics, KuGou, Apple Music y LRCLIB. Auto las prueba en orden.

## Todo en cristal
Filas, fichas, hojas, menús y todo el reproductor en cristal líquido, con animaciones de entrada, brillo que recorre la barra y respiración del botón de play. Los efectos pesados se apagan solos en teléfonos justos o con Modo ahorro.

## Volumen
El deslizador controla el volumen real del teléfono (sonido multimedia) y sigue a los botones físicos.

## Rosado y más ajustes
Color por defecto rosado (como Apple Music). Nuevos ajustes: animaciones (completas/suaves/ninguna), fondo negro puro, pantalla encendida, tiempo restante, y sección Letra (tamaño, alineación, difuminado).

## Dúos
Si la letra trae varios cantantes (Better Lyrics / Apple Music), cada uno va en su lado: el primero a la izquierda, el segundo a la derecha, los coros al centro.

## Cristal extremo y portada en el reproductor de Android
- Ajustes > Cristal extremo: refracción tipo lente con aberración cromática (solo en nivel alto).
- La portada aparece en la notificación y la pantalla de bloqueo.

## Rendimiento del cristal
Calidad automática/extrema/alta/media/ahorro, lente de una sola pasada, desenfoque simple mientras se desliza, barras ocultas con el reproductor abierto, resplandor sin repintado, ahorro con batería baja. Ajustes: desenfoque y brillo de bordes.

## Música del teléfono
Ajustes > Escanear música del teléfono (o Biblioteca > Teléfono): lee la música con MediaStore, con portadas, filtro, reproducir todo y aleatorio. Aparece también en los resultados de búsqueda. Pide el permiso de audio.

## Cambios: modo plano, portada 3D, todas las fuentes juntas
- **Sin cristal líquido** por defecto (Ajustes > Cristal líquido para volver a activarlo).
- **Portada 3D**: sombras en capas, brillo del color de la portada e inclinación suave con el giroscopio o el dedo.
- **Búsqueda unificada**: YouTube Music + Spotify (si conectas la cuenta) + Apple Music (iTunes) + Deezer + SoundCloud (necesita Client ID en Ajustes). Chips para elegir una sola fuente. Las canciones de Apple/Deezer suenan emparejadas con YouTube Music.
- **Segundo plano**: servicio en primer plano, MediaSession, WebView siempre "visible" y aviso para quitar la optimización de batería (Ajustes > Sonar con la pantalla apagada).
- **Barra de estado**: toma el color de la canción (y la de navegación también), con transición suave.
- **Gama baja** (Ajustes > Optimizar para gama baja, Automático por defecto): se activa con poca RAM (<7 GB), Android 10 o menor, o procesadores Snapdragon 4xx/6xx, Helio, Unisoc y similares. Quita sombras y filtros, fondo estático con el color de la canción, portada animada y fondo móvil apagados la primera vez, 20 cuadros por segundo en el visualizador, listas que solo pintan lo visible y sin inclinación 3D. Gama alta queda igual.
- **Sin retraso al salir**: si el sistema pausa el audio al salir de la app, se reanuda al instante (antes esperaba 0.4 s o más) y también desde onPause de Android.
- **Mezcla entre canciones**: botón en cada lista y en la cola (y duración en Ajustes, 3 a 12 s). La canción se apaga y la siguiente sube, sin silencio; es un fundido encadenado, no un solape real.
- **Hoja de mezcla**: al tocar el botón de mezcla (listas, cola o Ajustes) se abre un editor con gráfico de la transición, ajustes predefinidos (Automática, Fundido, Corte rápido, Club, Vinilo, Personalizada), duración, curva de volumen y efecto; botón Probar la mezcla.
