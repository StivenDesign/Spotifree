package com.spotifree.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#08080A"))
        setContentView(web)

        // Sirve los archivos de assets/www bajo https para que YouTube acepte el reproductor incrustado.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        // Selector de archivos: música local y videos de portada (canvas).
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        // Los botones de la notificación, la pantalla de bloqueo y los auriculares llegan a la página.
        PlayerService.onCommand = { cmd, arg ->
            runOnUiThread { web.evaluateJavascript("window.__media&&window.__media('$cmd',$arg)", null) }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onDestroy() {
        PlayerService.onCommand = null
        stopService(Intent(this, PlayerService::class.java))
        web.destroy()
        super.onDestroy()
    }

    /** Atrás cierra la pantalla abierta; si no hay nada que cerrar, manda la app a segundo plano. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    inner class Bridge {
        /** Peticiones HTTP sin restricciones CORS (YouTube Music, KuGou, Apple, etc.). */
        @JavascriptInterface
        fun request(id: Int, method: String, url: String, headers: String, body: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = method
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    h.keys().forEach { k -> c.setRequestProperty(k, h.getString(k)) }
                    if (body.isNotEmpty()) {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    status = c.responseCode
                    val stream = if (status >= 400) c.errorStream else c.inputStream
                    text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga una imagen y la devuelve como "tipo|base64" (para usarla en WebGL sin CORS). */
        @JavascriptInterface
        fun requestBytes(id: Int, url: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    status = c.responseCode
                    if (status < 400) {
                        val mime = c.contentType?.substringBefore(';') ?: "image/jpeg"
                        val bytes = c.inputStream.use { it.readBytes() }
                        text = mime + "|" + Base64.encodeToString(bytes, Base64.NO_WRAP)
                    }
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** La página avisa qué suena y en qué punto va; Android actualiza notificación y pantalla de bloqueo. */
        @JavascriptInterface
        fun media(title: String, artist: String, playing: Boolean, posMs: Long, durMs: Long) {
            runOnUiThread {
                val i = Intent(this@MainActivity, PlayerService::class.java)
                    .putExtra("title", title).putExtra("artist", artist).putExtra("playing", playing)
                    .putExtra("pos", posMs).putExtra("dur", durMs)
                try {
                    if (PlayerService.running) startService(i) else startForegroundService(i)
                } catch (e: Exception) {
                    // sin permiso para iniciar el servicio en segundo plano: la música sigue sonando igual
                }
            }
        }
    }
}
