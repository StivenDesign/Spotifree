# Spotifree para Android

Reproductor con YouTube Music, interfaz estilo Apple Music con vidrio líquido, letras sincronizadas
(Better Lyrics, KuGou, Apple Music, LRCLIB), música local, modo video y portadas en movimiento.
Todo corre dentro de la app, sin servidor. Creada por Claude para Steven Pantoja.

## Cómo generar el APK (GitHub, sin Android Studio)

1. Entra a tu repositorio y sube este zip con el mismo nombre (`ondas-android.zip`). Reemplaza al anterior.
2. Abre la pestaña Actions y espera la palomita verde (unos 5 minutos).
3. En Releases baja el nuevo `app-debug.apk` e instálalo.

Spotifree se instala como una app nueva (no reemplaza a Ondas). Después de comprobar que funciona
puedes desinstalar Ondas.

## Qué trae

- **Barra inferior**: Inicio, Novedades, Radio, Biblioteca y Buscar. Inicio y Novedades salen de YouTube Music;
  Radio crea estaciones sin fin por género, artista o canción.
- **Cristal líquido ajustable**: Ajustes > Apariencia. De 0 % (paneles mate) a 100 % (translúcidos con desenfoque).
- **Animaciones**: transiciones con resorte entre secciones, portada que vuela al mini reproductor, arrastrar hacia
  abajo para cerrar el reproductor y vibración suave opcional.
- **Cuenta**: Ajustes > Añadir cuenta. Elige Spotify o YouTube, pon tu nombre, importa listas de YouTube con su enlace
  o conecta Spotify con tu propio Client ID (gratis, developer.spotify.com; dirección de retorno `spotifree://callback`).
  La música siempre suena desde YouTube Music.
- **Descargas**: botón Descargar en el reproductor y en Ajustes. Baja música con licencia libre de Internet Archive
  y de Jamendo (necesita tu Client ID gratuito de devportal.jamendo.com). Se guarda en la app y suena sin internet.
- **Biblioteca**: Me gusta, descargas, tu música del teléfono y listas propias.
- **Canvas estilo Spotify**: botón Canvas en el reproductor. Pon un video corto o GIF a una canción y se ve a pantalla completa detrás del reproductor. Ya no hay portada con distorsión.
- **Reproductor**: aleatorio, repetir (lista o una canción), temporizador de sueño, velocidad (0,75× a 2×),
  fundido suave al pausar, doble toque en la portada para dar me gusta y deslizar el mini reproductor para cambiar de canción.
- **Ecualizador de audio**: 5 bandas y presets (Graves, Vocal, Rock...). Solo actúa en música del teléfono y descargas.
- **Tu resumen**: tiempo escuchado, canciones y artistas favoritos, y la fila "Lo más escuchado" en Inicio.
- **Color de acento** a elegir, o automático según la portada.
- **Tirar hacia abajo** en Inicio y Novedades para actualizar.
- **Mi música**, **modo video**, **letras**, **ecualizador**, **modo ahorro**
  y **controles de Android** (notificación, pantalla de bloqueo, auriculares) siguen como antes.

## Notas

- El ecualizador de archivos locales usa el espectro real del audio. En canciones de YouTube es una animación
  que sigue el ritmo, porque YouTube no deja leer su audio.
- Las letras de Apple Music necesitan tus tokens (Ajustes > Apple Music).
- Las APIs de YouTube Music, Better Lyrics, KuGou, Apple y Spotify no son oficiales o pueden cambiar.
- Spotifree no descarga música de YouTube ni de Spotify.

## Fotos de artistas y tipografías
- Foto del artista (Deezer, necesita internet) junto a su nombre en el reproductor, en la búsqueda, en Inicio/Radio y en su página. Se apaga en Ajustes > Fotos de artistas.
- Cada artista conocido tiene su propia tipografía (Bebas Neue, Bungee, Pacifico, etc.); el resto recibe una de forma estable según su nombre.
- Toda la app usa Inter en negrita (estilo iOS). Las fuentes van dentro del APK (carpeta `www/fonts`).
