package com.ondas.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#161618"))
        setContentView(web)

        // Sirve los archivos de assets/www bajo https para que YouTube acepte el reproductor incrustado.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    /** Atrás cierra la pantalla de reproducción; si no hay nada que cerrar, manda la app a segundo plano. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    inner class Bridge {
        /** Peticiones HTTP sin restricciones CORS (YouTube Music, KuGou, etc.). */
        @JavascriptInterface
        fun request(id: Int, method: String, url: String, headers: String, body: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = method
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    h.keys().forEach { k -> c.setRequestProperty(k, h.getString(k)) }
                    if (body.isNotEmpty()) {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    status = c.responseCode
                    val stream = if (status >= 400) c.errorStream else c.inputStream
                    text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun setPlaying(on: Boolean, title: String) {
            runOnUiThread {
                val i = Intent(this@MainActivity, PlayerService::class.java).putExtra("title", title)
                if (on) startForegroundService(i) else stopService(i)
            }
        }
    }
}
