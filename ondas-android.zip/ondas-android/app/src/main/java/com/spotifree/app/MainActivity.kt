package com.spotifree.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.util.Size
import java.io.ByteArrayOutputStream
import org.json.JSONArray
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * WebView que nunca se entera de que la app pasó a segundo plano: así Chromium no suspende el audio
 * (ni el de los videos de YouTube) al salir de la app o apagar la pantalla.
 */
class KeepAliveWebView(c: Context) : WebView(c) {
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(android.view.View.VISIBLE) }
    override fun onVisibilityChanged(changedView: android.view.View, visibility: Int) { super.onVisibilityChanged(changedView, android.view.View.VISIBLE) }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingOauth: String? = null
    private val dlDir: File get() = File(filesDir, "dl").apply { mkdirs() }

    /** Lee solo `left` bytes: así se responden las peticiones con Range (buscar dentro de la canción). */
    private class Limited(s: InputStream, private var left: Long) : FilterInputStream(s) {
        override fun read(): Int { if (left <= 0) return -1; val r = super.read(); if (r >= 0) left--; return r }
        override fun read(b: ByteArray, o: Int, l: Int): Int {
            if (left <= 0) return -1
            val r = super.read(b, o, minOf(l.toLong(), left).toInt()); if (r > 0) left -= r; return r
        }
    }

    /** Respuesta con soporte de Range para cualquier fuente de audio (descargas o música del teléfono). */
    private fun respondRange(req: WebResourceRequest, mime: String, len: Long, open: (Long) -> InputStream): WebResourceResponse {
        var start = 0L; var end = len - 1; var status = 200
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Access-Control-Allow-Origin" to "*")
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
        if (m != null) {
            val a = m.groupValues[1]; val b = m.groupValues[2]
            if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1) }
            else if (b.isNotEmpty()) start = maxOf(0L, len - b.toLong())
            if (start >= len) return WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$len"), ByteArrayInputStream(ByteArray(0)))
            status = 206; headers["Content-Range"] = "bytes $start-$end/$len"
        }
        headers["Content-Length"] = (end - start + 1).toString()
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", headers, Limited(open(start), end - start + 1))
    }

    private fun notFound() = WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
    private fun trackUri(id: Long) = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    /** Música del teléfono: https://appassets.androidplatform.net/media/<id> */
    private fun serveMedia(req: WebResourceRequest): WebResourceResponse {
        val id = req.url.lastPathSegment?.toLongOrNull() ?: return notFound()
        return try {
            val afd = contentResolver.openAssetFileDescriptor(trackUri(id), "r") ?: return notFound()
            val len = afd.length.takeIf { it > 0 } ?: afd.parcelFileDescriptor.statSize
            val mime = contentResolver.getType(trackUri(id)) ?: "audio/mpeg"
            respondRange(req, mime, len) { start ->
                val fis = FileInputStream(afd.fileDescriptor); fis.channel.position(afd.startOffset + start); fis
            }
        } catch (e: Exception) { notFound() }
    }

    /** Portada de una canción del teléfono: https://appassets.androidplatform.net/art/<id>?a=<albumId> */
    private fun serveArt(req: WebResourceRequest): WebResourceResponse {
        val id = req.url.lastPathSegment?.toLongOrNull() ?: return notFound()
        val albumId = req.url.getQueryParameter("a")?.toLongOrNull() ?: 0L
        return try {
            val bmp = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(trackUri(id), Size(512, 512), null)
            else contentResolver.openInputStream(ContentUris.withAppendedId(android.net.Uri.parse("content://media/external/audio/albumart"), albumId))?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return notFound()
            val out = ByteArrayOutputStream(); bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
            WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "max-age=86400"), ByteArrayInputStream(out.toByteArray()))
        } catch (e: Exception) { notFound() }
    }

    private val audioPerm get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    private fun hasAudioPerm() = checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            runOnUiThread { web.evaluateJavascript("window.__scanPerm&&window.__scanPerm($ok)", null) }
        }
    }

    /** Sirve las canciones descargadas en https://appassets.androidplatform.net/dl/<archivo> con soporte de Range. */
    private fun serveDownload(req: WebResourceRequest): WebResourceResponse {
        val name = File(Uri.decode(req.url.path.orEmpty().removePrefix("/dl/"))).name
        val f = File(dlDir, name)
        if (!f.isFile) return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        val len = f.length()
        val mime = when (f.extension.lowercase()) { "m4a", "mp4" -> "audio/mp4"; "ogg", "opus" -> "audio/ogg"; "flac" -> "audio/flac"; "wav" -> "audio/wav"; else -> "audio/mpeg" }
        var start = 0L; var end = len - 1; var status = 200
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Access-Control-Allow-Origin" to "*")
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
        if (m != null) {
            val a = m.groupValues[1]; val b = m.groupValues[2]
            if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1) }
            else if (b.isNotEmpty()) start = maxOf(0L, len - b.toLong())
            if (start >= len) return WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$len"), ByteArrayInputStream(ByteArray(0)))
            status = 206; headers["Content-Range"] = "bytes $start-$end/$len"
        }
        headers["Content-Length"] = (end - start + 1).toString()
        val fis = FileInputStream(f); fis.channel.position(start)
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", headers, Limited(fis, end - start + 1))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC     // los botones de volumen mueven el sonido multimedia
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = KeepAliveWebView(this)
        web.setBackgroundColor(Color.parseColor("#08080A"))
        setContentView(web)

        // Sirve los archivos de assets/www bajo https para que YouTube acepte el reproductor incrustado.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/dl/") == true) serveDownload(request)
                else if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/media/") == true) serveMedia(request)
                else if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/art/") == true) serveArt(request)
                else loader.shouldInterceptRequest(request.url)
        }
        // Selector de archivos: música local y videos de portada (canvas).
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        // Los botones de la notificación, la pantalla de bloqueo y los auriculares llegan a la página.
        PlayerService.onCommand = { cmd, arg ->
            runOnUiThread { web.evaluateJavascript("window.__media&&window.__media('$cmd',$arg)", null) }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        captureOauth(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun captureOauth(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "spotifree") pendingOauth = d.toString()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureOauth(intent)
        if (pendingOauth != null) web.evaluateJavascript("window.pollOauth&&window.pollOauth()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // Al salir de la app el WebView sigue vivo: así la música no se corta.
    override fun onPause() { super.onPause(); web.onResume(); web.resumeTimers() }
    override fun onStop() {
        super.onStop(); web.onResume(); web.resumeTimers()
        web.evaluateJavascript("window.__bg&&window.__bg(true)", null)
    }
    override fun onStart() { super.onStart(); web.evaluateJavascript("window.__bg&&window.__bg(false)", null) }

    override fun onDestroy() {
        PlayerService.onCommand = null
        stopService(Intent(this, PlayerService::class.java))
        web.destroy()
        super.onDestroy()
    }

    /** Atrás cierra la pantalla abierta; si no hay nada que cerrar, manda la app a segundo plano. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    inner class Bridge {
        /** Pide a Android que no frene la app en segundo plano (ahorro de batería de fábrica). */
        @JavascriptInterface
        fun batteryOk(): Boolean = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)

        /** Datos del teléfono para decidir si necesita el modo gama baja (memoria, versión de Android, procesador). */
        @JavascriptInterface
        fun deviceInfo(): String {
            return try {
                val mi = android.app.ActivityManager.MemoryInfo()
                (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
                val soc = (if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else "") + " " + Build.HARDWARE + " " + Build.BOARD
                JSONObject().put("ramMb", mi.totalMem / 1048576L).put("sdk", Build.VERSION.SDK_INT).put("cores", Runtime.getRuntime().availableProcessors())
                    .put("lowRam", mi.lowMemory || (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).isLowRamDevice).put("soc", soc.lowercase()).toString()
            } catch (e: Exception) { "{}" }
        }

        @JavascriptInterface
        fun allowBackground() {
            runOnUiThread {
                try {
                    if (!batteryOk()) startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) {}
                }
            }
        }

        /**
         * Escanea la música del teléfono (MediaStore). Devuelve el JSON con las canciones, o "perm" si falta el permiso
         * (con ask=true lo pide; la página recibe la respuesta en window.__scanPerm).
         */
        @JavascriptInterface
        fun scanMusic(ask: Boolean): String {
            if (!hasAudioPerm()) {
                if (ask) runOnUiThread { requestPermissions(arrayOf(audioPerm), 2) }
                return "perm"
            }
            val arr = JSONArray()
            val proj = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DATE_ADDED
            )
            try {
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000", null,
                    "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val artist = c.getString(2) ?: ""
                        arr.put(JSONObject()
                            .put("id", c.getLong(0)).put("title", c.getString(1) ?: "Sin título")
                            .put("artist", if (artist == "<unknown>") "" else artist)
                            .put("album", c.getString(3)?.takeIf { it != "<unknown>" } ?: "")
                            .put("duration", c.getLong(4) / 1000).put("albumId", c.getLong(5)).put("added", c.getLong(6)))
                    }
                }
            } catch (e: Exception) { return "[]" }
            return arr.toString()
        }

        /** Volumen multimedia del teléfono, de 0 a 100. */
        @JavascriptInterface
        fun getVolume(): Int {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
        }

        @JavascriptInterface
        fun setVolume(pct: Int) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (pct.coerceIn(0, 100) * max + 50) / 100, 0)
        }

        /** Peticiones HTTP sin restricciones CORS (YouTube Music, KuGou, Apple, etc.). */
        @JavascriptInterface
        fun request(id: Int, method: String, url: String, headers: String, body: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = method
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    h.keys().forEach { k -> c.setRequestProperty(k, h.getString(k)) }
                    if (body.isNotEmpty()) {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    status = c.responseCode
                    val stream = if (status >= 400) c.errorStream else c.inputStream
                    text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga una imagen y la devuelve como "tipo|base64" (para usarla en WebGL sin CORS). */
        @JavascriptInterface
        fun requestBytes(id: Int, url: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    status = c.responseCode
                    if (status < 400) {
                        val mime = c.contentType?.substringBefore(';') ?: "image/jpeg"
                        val bytes = c.inputStream.use { it.readBytes() }
                        text = mime + "|" + Base64.encodeToString(bytes, Base64.NO_WRAP)
                    }
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga un archivo de música a la carpeta privada de la app y avisa del progreso. */
        @JavascriptInterface
        fun download(id: Int, url: String, file: String) {
            Thread {
                val name = File(file).name
                val part = File(dlDir, "$name.part")
                var ok = false; var msg = ""; var size = 0L
                try {
                    if (!url.startsWith("https://")) throw Exception("Solo se permiten enlaces https")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    if (c.responseCode >= 400) throw Exception("El servidor respondió " + c.responseCode)
                    val total = c.contentLengthLong
                    var done = 0L; var lastPct = -1; var lastAt = 0L
                    c.inputStream.use { ins -> part.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = ins.read(buf); if (n < 0) break
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt(); val now = System.currentTimeMillis()
                                if (pct != lastPct && now - lastAt > 200) { lastPct = pct; lastAt = now; runOnUiThread { web.evaluateJavascript("window.__dlProgress&&window.__dlProgress($id,$pct)", null) } }
                            }
                        }
                    } }
                    if (done < 1024) throw Exception("Archivo vacío")
                    if (!part.renameTo(File(dlDir, name))) throw Exception("No pude guardar el archivo")
                    ok = true; size = done
                } catch (e: Exception) {
                    part.delete(); msg = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript(if (ok) "window.__dlDone($id,true,$size)" else "window.__dlDone($id,false,${JSONObject.quote(msg)})", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun dlDelete(file: String) { File(dlDir, File(file).name).delete() }

        /** Abre un enlace https en el navegador (inicio de sesión de Spotify). */
        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {} }
        }

        /** Devuelve (una sola vez) la dirección spotifree://callback con la que Spotify volvió a la app. */
        @JavascriptInterface
        fun takeOauth(): String { val u = pendingOauth ?: ""; pendingOauth = null; return u }

        /** Pinta la barra de estado y la de navegación con el color de la canción, con transición suave. */
        @JavascriptInterface
        fun setBars(hex: String) {
            runOnUiThread {
                try {
                    val to = Color.parseColor(hex)
                    val from = window.statusBarColor
                    android.animation.ValueAnimator.ofObject(android.animation.ArgbEvaluator(), from, to).apply {
                        duration = 450
                        addUpdateListener { a -> val c = a.animatedValue as Int; window.statusBarColor = c; window.navigationBarColor = c }
                        start()
                    }
                    val lum = (0.299 * Color.red(to) + 0.587 * Color.green(to) + 0.114 * Color.blue(to)) / 255.0
                    if (Build.VERSION.SDK_INT >= 23) {
                        var f = window.decorView.systemUiVisibility
                        f = if (lum > 0.62) f or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                        window.decorView.systemUiVisibility = f
                    }
                } catch (e: Exception) {}
            }
        }

        /** La página avisa qué suena y en qué punto va; Android actualiza notificación y pantalla de bloqueo. */
        @JavascriptInterface
        fun media(title: String, artist: String, playing: Boolean, posMs: Long, durMs: Long, cover: String) {
            runOnUiThread {
                val i = Intent(this@MainActivity, PlayerService::class.java)
                    .putExtra("title", title).putExtra("artist", artist).putExtra("playing", playing)
                    .putExtra("pos", posMs).putExtra("dur", durMs).putExtra("cover", cover)
                try {
                    if (PlayerService.running) startService(i) else startForegroundService(i)
                } catch (e: Exception) {
                    // sin permiso para iniciar el servicio en segundo plano: la música sigue sonando igual
                }
            }
        }
    }
}
