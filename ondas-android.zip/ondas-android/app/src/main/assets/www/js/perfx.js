/* ===== Rendimiento: perfiles, AutoFPS y SmartCache =====
   Todo lo de aquí es añadido: no cambia ningún ajuste existente salvo cuando TÚ eliges un perfil a mano.
   «Automático» no escribe tus ajustes: solo detecta el teléfono y adapta efectos en tiempo real. */
'use strict';
const PFX_NAMES = { patata: 'Patata', lite: 'Lite', balanced: 'Balanceado', ultra: 'Ultra' };
/* qué ajustes mueve cada perfil cuando lo eliges a mano (se guarda una copia para volver a Automático) */
const PFX_PRESETS = {
  patata:   { perf: true,  lite: 'on',  anim: 'soft', motion: false, amb: false, animArt: false, autoCv: false, art3d: false, gq: 'ahorro', blur: 40,  shine: 0 },
  lite:     { perf: false, lite: 'on',  anim: 'soft', motion: false, amb: false, animArt: false, autoCv: false, art3d: false, gq: 'media',  blur: 60,  shine: 50 },
  balanced: { perf: false, lite: 'off', anim: 'full', motion: true,  amb: true,  animArt: true,  autoCv: true,  art3d: false, gq: 'media',  blur: 100, shine: 100 },
  ultra:    { perf: false, lite: 'off', anim: 'full', motion: true,  amb: true,  animArt: true,  autoCv: true,  gq: 'auto', blur: 100, shine: 100 },
};
const PFX_LIM = { patata: { img: 40, lyr: 20 }, lite: { img: 90, lyr: 40 }, balanced: { img: 160, lyr: 80 }, ultra: { img: 300, lyr: 150 } };

/* ---- detección de gama ---- */
function pfxDetect() {
  const d = (typeof DEVINFO !== 'undefined' && DEVINFO) || {}, ram = d.ramMb || ((navigator.deviceMemory || 4) * 1024), cores = d.cores || navigator.hardwareConcurrency || 4;
  let cls;
  if (d.lowRam || ram < 3500 || cores <= 4 && ram < 4500) cls = 'patata';
  else if (typeof lowEnd !== 'undefined' && lowEnd) cls = 'lite';
  else if (ram < 9500) cls = 'balanced';
  else cls = 'ultra';
  return { cls, ram, cores, sdk: d.sdk || 0, soc: d.soc || '' };
}
const PFX = { dev: pfxDetect(), level: 0, thermal: 0 };
const pfxEff = () => { const c = CFG.pfx || 'auto'; return c === 'auto' ? PFX.dev.cls : (PFX_NAMES[c] ? c : PFX.dev.cls); };

function pfxPaint() {
  const b = document.body, e = pfxEff();
  Object.keys(PFX_NAMES).forEach((k) => b.classList.toggle('pf-' + k, k === e));
  b.classList.toggle('fps-1', PFX.level >= 1); b.classList.toggle('fps-2', PFX.level >= 2);
  try { const v = document.getElementById('motion'); if (v && PFX.level >= 2) v.pause(); else if (typeof syncMotion === 'function') syncMotion(); } catch {}
  const n = document.getElementById('pfxNote');
  if (n) {
    const d = PFX.dev, auto = (CFG.pfx || 'auto') === 'auto';
    n.textContent = (auto ? 'Automático → ' : '') + PFX_NAMES[e] + ' · ' + (d.ram ? (d.ram / 1024).toFixed(1) + ' GB de RAM' : 'RAM desconocida') + ' · ' + d.cores + ' núcleos' + (d.sdk ? ' · Android API ' + d.sdk : '') + (PFX.level ? ' · AutoFPS nivel ' + PFX.level : '');
  }
}

/* ---- aplicar un perfil elegido a mano / volver a Automático ---- */
function pfxApply(choice, quiet) {
  const keys = Object.keys(PFX_PRESETS.balanced).concat(['art3d']);
  if (choice === 'auto') {
    if (CFG.pfxBak) { keys.forEach((k) => { if (k in CFG.pfxBak) { if (CFG.pfxBak[k] === '__u') delete CFG[k]; else CFG[k] = CFG.pfxBak[k]; } }); CFG.pfxBak = null; }
  } else if (PFX_PRESETS[choice]) {
    if (!CFG.pfxBak) { CFG.pfxBak = {}; keys.forEach((k) => { CFG.pfxBak[k] = k in CFG ? CFG[k] : '__u'; }); }
    Object.assign(CFG, PFX_PRESETS[choice]);
  }
  CFG.pfx = choice; saveCfg();
  try { document.body.classList.toggle('perf', !!CFG.perf); } catch {}
  try { LITE = CFG.lite === 'on'; } catch {}
  try { if (typeof applyGq === 'function') applyGq(); } catch {}
  try { if (typeof applyLook === 'function') applyLook(); } catch {}
  try { if (typeof applyMoreLook === 'function') applyMoreLook(); } catch {}
  try { if (typeof syncSettingsUI === 'function') syncSettingsUI(); } catch {}
  try { if (typeof syncMotion === 'function') syncMotion(); } catch {}
  PFX.level = 0; pfxPaint(); pfxSub();
  if (!quiet) toast('Perfil de rendimiento: ' + (choice === 'auto' ? 'Automático (' + PFX_NAMES[PFX.dev.cls] + ')' : PFX_NAMES[choice]));
}

/* ---- AutoFPS: mide los cuadros por segundo (y la temperatura si el teléfono la da) y baja o sube efectos ---- */
(function () {
  let last = 0, acc = [], bad = 0, good = 0;
  const on = () => CFG.autoFps !== false && pfxEff() !== 'patata';
  function judge() {
    if (!acc.length) return; const a = acc.slice().sort((x, y) => x - y), med = a[a.length >> 1], p90 = a[Math.floor(a.length * .9)]; acc = [];
    const slow = med > 24 || p90 > 40;        // menos de ~40 fps estables, o tirones frecuentes
    let want = PFX.level;
    if (slow) { bad++; good = 0; if (bad >= 2 && want < 2) { want++; bad = 0; } }
    else if (med < 19 && p90 < 28) { good++; bad = 0; if (good >= 7 && want > 0) { want--; good = 0; } }
    else { bad = 0; good = 0; }
    if (PFX.thermal >= 3) want = 2; else if (PFX.thermal >= 2) want = Math.max(want, 1);
    if (want !== PFX.level) { PFX.level = want; pfxPaint(); }
  }
  function tick(ts) {
    requestAnimationFrame(tick);
    if (document.hidden || !on()) { last = 0; return; }
    const hot = document.body.classList.contains('np-open') || document.body.classList.contains('scrolling') || document.body.classList.contains('is-playing');
    if (last && hot) { const d = ts - last; if (d > 0 && d < 200) acc.push(d); }
    last = ts;
    if (acc.length >= 120) judge();
  }
  if (ts0()) requestAnimationFrame(tick);
  function ts0() { return typeof requestAnimationFrame === 'function'; }
  // temperatura: Android 10+ la da a través de la app (Native.thermal); si no existe, solo se usan los cuadros
  setInterval(() => { try { if (window.Native && Native.thermal && !document.hidden) { PFX.thermal = +Native.thermal() || 0; } } catch {} }, 30000);
  document.addEventListener('visibilitychange', () => { acc = []; last = 0; });
  window.pfxFpsReset = () => { acc = []; bad = good = 0; PFX.level = 0; pfxPaint(); };
})();

/* ---- SmartCache: mantiene portadas, letras y datos dentro de un tamaño razonable ---- */
async function smartTrim(why) {
  if (CFG.smartCache === false) return null;
  const lim = PFX_LIM[pfxEff()] || PFX_LIM.balanced, out = { img: 0, lyr: 0 };
  try {   // portadas guardadas para uso sin conexión: se borran las más viejas
    if (window.caches) {
      const c = await caches.open(typeof IMGC !== 'undefined' ? IMGC : 'sf-img-v1'), ks = await c.keys(), keep = why === 'memory' ? Math.floor(lim.img / 2) : lim.img;
      if (ks.length > keep) { const old = ks.slice(0, ks.length - keep); await Promise.all(old.map((k) => c.delete(k))); out.img = old.length; }
    }
  } catch {}
  try {   // letras guardadas
    if (typeof LYC !== 'undefined') {
      const k = Object.keys(LYC), max = Math.min(CFG.cacheN ?? 60, lim.lyr);
      if (CFG.cacheN && k.length > max) { k.sort((a, b) => (LYC[a].at || 0) - (LYC[b].at || 0)).slice(0, k.length - max).forEach((x) => { delete LYC[x]; }); out.lyr = k.length - max; }
    }
  } catch {}
  if (why === 'memory') { try { if (typeof API_CACHE !== 'undefined') API_CACHE.clear(); if (typeof PRE !== 'undefined') PRE.clear(); } catch {} }
  return out;
}
async function smartInfo() {
  let img = 0, use = 0;
  try { if (window.caches) img = (await (await caches.open(typeof IMGC !== 'undefined' ? IMGC : 'sf-img-v1')).keys()).length; } catch {}
  try { if (navigator.storage && navigator.storage.estimate) use = (await navigator.storage.estimate()).usage || 0; } catch {}
  const n = document.getElementById('cacheNote');
  if (n) n.textContent = img + ' portadas guardadas' + (use ? ' · ' + (use / 1048576).toFixed(0) + ' MB usados' : '') + ' · límite ' + (PFX_LIM[pfxEff()] || PFX_LIM.balanced).img + ' portadas';
}
// Kotlin avisa cuando el sistema pide memoria (onTrimMemory)
window.__trim = (lvl) => { smartTrim(lvl >= 40 ? 'memory' : 'idle'); };
document.addEventListener('visibilitychange', () => { if (document.hidden) smartTrim('hidden'); });
(window.requestIdleCallback || ((f) => setTimeout(f, 6000)))(() => setTimeout(() => smartTrim('start'), 4000), { timeout: 12000 });

/* ---- botones y selectores de la pantalla de ajustes ---- */
function pfxSub() { smartInfo(); }
document.addEventListener('change', (e) => {
  const t = e.target; if (!t || !t.dataset) return;
  if (t.dataset.cfg === 'pfx') pfxApply(t.value);
  else if (t.dataset.cfg === 'autoFps') { if (t.checked === false) { PFX.level = 0; } pfxPaint(); }
  else if (t.dataset.cfg === 'imgOpt' || t.dataset.cfg === 'smartCache') { smartInfo(); }
});
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act="cache-clear"]'); if (!b) return;
  smartTrim('memory').then(async () => { try { if (window.caches) { await caches.delete(typeof IMGC !== 'undefined' ? IMGC : 'sf-img-v1'); } } catch {} toast('Caché limpia'); smartInfo(); });
});

/* ---- arranque ---- */
if (!CFG.pfx) CFG.pfx = 'auto';
const sel = document.querySelector('[data-cfg="pfx"]'); if (sel) sel.value = CFG.pfx;
pfxPaint(); setTimeout(pfxSub, 1500);
