'use strict';
/* ===== Música local: IndexedDB, etiquetas ID3 y lista "Mi música" ===== */
const DB = { db: null };
function idb() {
  if (DB.db) return Promise.resolve(DB.db);
  return new Promise((res, rej) => {
    if (!window.indexedDB) return rej(new Error('Sin almacenamiento'));
    const r = indexedDB.open('spotifree', 1);
    r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('tracks', { keyPath: 'id', autoIncrement: true }); d.createObjectStore('canvas'); };
    r.onsuccess = () => { DB.db = r.result; res(DB.db); };
    r.onerror = () => rej(r.error);
  });
}
async function idbReq(store, mode, fn) {
  const d = await idb();
  return new Promise((res, rej) => {
    const t = d.transaction(store, mode); const rq = fn(t.objectStore(store));
    t.oncomplete = () => res(rq && rq.result); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('Cancelado'));
  });
}
const canvasGet = (k) => idbReq('canvas', 'readonly', (s) => s.get(k)).catch(() => null);
const canvasPut = (k, blob) => idbReq('canvas', 'readwrite', (s) => s.put(blob, k));
const canvasDel = (k) => idbReq('canvas', 'readwrite', (s) => s.delete(k)).catch(() => {});
const canvasClear = () => idbReq('canvas', 'readwrite', (s) => s.clear()).catch(() => {});

/* ---------- etiquetas ID3v2 (título, artista, álbum, portada) ---------- */
function decodeText(f, off = 1) {
  const enc = f[0]; let d = f.subarray(off), label = ['iso-8859-1', 'utf-16le', 'utf-16be', 'utf-8'][enc] || 'utf-8';
  if (enc === 1) { if (d[0] === 0xFE && d[1] === 0xFF) { label = 'utf-16be'; d = d.subarray(2); } else if (d[0] === 0xFF && d[1] === 0xFE) d = d.subarray(2); }
  return new TextDecoder(label).decode(d).replace(/\0[\s\S]*$/, '').trim();
}
function parseAPIC(f) {
  const enc = f[0]; let i = 1;
  while (i < f.length && f[i] !== 0) i++;
  i += 2;                                   // fin del tipo MIME y byte "tipo de imagen"
  if (enc === 1 || enc === 2) { while (i + 1 < f.length && !(f[i] === 0 && f[i + 1] === 0)) i += 2; i += 2; }
  else { while (i < f.length && f[i] !== 0) i++; i += 1; }
  const data = f.subarray(i);
  if (data.length < 100) return null;
  const type = data[0] === 0x89 && data[1] === 0x50 ? 'image/png' : 'image/jpeg';
  return new Blob([data], { type });
}
function parseID3(b) {
  const out = {}, ver = b[3];
  if (ver < 3) return out;
  const ss = (o) => (b[o] << 21) | (b[o + 1] << 14) | (b[o + 2] << 7) | b[o + 3];
  const end = Math.min(b.length, 10 + ss(6)); let p = 10;
  if (b[5] & 0x40) p += ver === 4 ? ss(p) : (((b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3]) >>> 0) + 4;
  while (p + 10 <= end) {
    const id = String.fromCharCode(b[p], b[p + 1], b[p + 2], b[p + 3]);
    if (!/^[A-Z0-9]{4}$/.test(id)) break;
    const size = ver === 4 ? ss(p + 4) : (((b[p + 4] << 24) | (b[p + 5] << 16) | (b[p + 6] << 8) | b[p + 7]) >>> 0);
    const start = p + 10; if (size <= 0 || start + size > b.length) break;
    const f = b.subarray(start, start + size);
    if (id === 'TIT2') out.title = decodeText(f); else if (id === 'TPE1') out.artist = decodeText(f); else if (id === 'TALB') out.album = decodeText(f);
    else if (id === 'APIC' && !out.cover) out.cover = parseAPIC(f);
    p = start + size;
  }
  return out;
}
async function readMeta(f) {
  const base = f.name.replace(/\.[^.]+$/, '');
  let title = base, artist = '', album = '', coverBlob = null;
  const m = base.match(/^(.+?)\s+-\s+(.+)$/); if (m) { artist = m[1].trim(); title = m[2].trim(); }
  try {
    const buf = new Uint8Array(await f.slice(0, 2500000).arrayBuffer());
    if (buf[0] === 0x49 && buf[1] === 0x44 && buf[2] === 0x33) {
      const t = parseID3(buf);
      if (t.title) title = t.title; if (t.artist) artist = t.artist; if (t.album) album = t.album; coverBlob = t.cover || null;
    }
  } catch {}
  return { title, artist: artist || 'Archivo local', album, coverBlob };
}
function probeDuration(f) {
  return new Promise((res) => {
    const a = new Audio(), u = URL.createObjectURL(f); let done = false;
    const end = (d) => { if (done) return; done = true; URL.revokeObjectURL(u); res(isFinite(d) ? d : 0); };
    a.preload = 'metadata'; a.onloadedmetadata = () => end(a.duration); a.onerror = () => end(0); setTimeout(() => end(0), 4000); a.src = u;
  });
}
// portada generada cuando el archivo no trae una
function makeCover(seed) {
  const c = document.createElement('canvas'); c.width = c.height = 512; const x = c.getContext('2d'), h = hue(seed);
  const g = x.createLinearGradient(0, 0, 512, 512); g.addColorStop(0, `hsl(${h} 80% 52%)`); g.addColorStop(1, `hsl(${(h + 60) % 360} 75% 30%)`);
  x.fillStyle = g; x.fillRect(0, 0, 512, 512);
  x.fillStyle = 'rgba(255,255,255,.88)'; x.font = '700 280px -apple-system,Segoe UI,Roboto,sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('♪', 256, 276);
  return c.toDataURL('image/jpeg', 0.85);
}

/* ---------- biblioteca ---------- */
const LIB = [];
let curURL = null;
async function loadLibrary() {
  let total = 0;
  try {
    const recs = (await idbReq('tracks', 'readonly', (s) => s.getAll())) || [];
    LIB.forEach((t) => t._blobUrl && URL.revokeObjectURL(t._blobUrl)); LIB.length = 0;
    recs.sort((a, b) => b.added - a.added).forEach((r) => {
      const blobUrl = r.coverBlob ? URL.createObjectURL(r.coverBlob) : null; total += r.file ? r.file.size : 0;
      LIB.push({ local: true, kind: 'local', lid: r.id, title: r.title, artist: r.artist, album: r.album, duration: r.duration, cover: blobUrl || makeCover(r.title + r.artist), _blobUrl: blobUrl });
    });
  } catch {}
  renderLibrary();
  const el = $('libSize'); if (el) el.textContent = LIB.length ? `${LIB.length} ${LIB.length === 1 ? 'canción' : 'canciones'} · ${(total / 1048576).toFixed(0)} MB` : 'No hay música local';
}
function renderLibrary() { if (typeof refreshLibViews === 'function') refreshLibViews(); }
async function importFiles(files) {
  let n = 0; toast('Añadiendo música…');
  for (const f of files) {
    if (!(f.type.startsWith('audio/') || /\.(mp3|m4a|flac|wav|ogg|opus|aac|wma|amr)$/i.test(f.name))) continue;
    try {
      const meta = await readMeta(f); meta.duration = await probeDuration(f);
      await idbReq('tracks', 'readwrite', (s) => s.add({ ...meta, file: f, added: Date.now() + n })); n++;
    } catch { toast('No pude guardar «' + f.name + '». ¿Falta espacio?'); }
  }
  await loadLibrary();
  toast(n ? `${n} ${n === 1 ? 'canción añadida' : 'canciones añadidas'}` : 'No encontré audio en esos archivos');
}
async function libraryURL(t) {
  try {
    const r = await idbReq('tracks', 'readonly', (s) => s.get(t.lid));
    if (!r) { toast('No encuentro ese archivo'); return ''; }
    if (curURL) URL.revokeObjectURL(curURL);
    return (curURL = URL.createObjectURL(r.file));
  } catch { toast('No pude abrir el archivo'); return ''; }
}
function removeTrack(t) {
  const i = LIB.indexOf(t); if (i < 0) return;
  LIB.splice(i, 1); renderLibrary(); let undone = false;
  toast('Canción quitada', () => { undone = true; LIB.splice(i, 0, t); renderLibrary(); });
  setTimeout(() => { if (!undone) { idbReq('tracks', 'readwrite', (s) => s.delete(t.lid)).catch(() => {}); canvasDel('L' + t.lid); loadLibrary(); } }, 5200);
}
async function clearLibrary() { await idbReq('tracks', 'readwrite', (s) => s.clear()).catch(() => {}); await canvasClear(); await loadLibrary(); toast('Música local borrada'); }
