'use strict';
/* Copia automática de tus datos ANTES de que se aplique cualquier migración de esta versión.
   Se hace una sola vez; se puede restaurar desde Ajustes > Copia de seguridad. No incluye claves ni tokens. */
(function () {
  try {
    if (localStorage.getItem('sf_backup_v2') || !Object.keys(localStorage).some((k) => /^(sf_|ondas_)/.test(k))) return;
    const out = {};
    Object.keys(localStorage).forEach((k) => { if (/^(sf_|ondas_)/.test(k) && !/^(sf_pkce|ondas_apple|sf_jkey|sf_acc|sf_backup)/.test(k)) out[k] = localStorage.getItem(k); });
    localStorage.setItem('sf_backup_v2', JSON.stringify({ at: Date.now(), data: out }));
  } catch {}
})();
