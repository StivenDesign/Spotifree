# Configuración de proveedores (Spotifree)

Todas las claves se escriben **dentro de la app** (Ajustes) y se guardan **solo en el teléfono**. Ninguna viene incluida en el código ni en la copia de seguridad.
Aviso honesto: sin un servidor propio, una clave guardada en una app nunca es 100 % secreta. Usa claves **gratuitas y de bajo riesgo**, con la cuota limitada.

| Proveedor | Para qué sirve | Dónde se configura | Qué se necesita |
|---|---|---|---|
| **YouTube Music (reproductor oficial IFrame)** | Reproducir | Ya funciona | Nada |
| **YouTube Data API v3** | Búsqueda oficial de YouTube | Ajustes > Música y descargas > *Clave de YouTube Data API* | Clave de Google Cloud (activa "YouTube Data API v3"). Déjala **sin restricción de aplicación** (solo restringida a esa API); cuota gratuita diaria |
| **Apple Music API** | Búsqueda y metadatos del catálogo (portadas, álbum, ISRC) y letras | Ajustes > Apple Music | Token de desarrollador (JWT) de una cuenta Apple Developer. Sin él se usa la búsqueda pública de iTunes |
| **Spotify Web API** | Búsqueda, metadatos y tu biblioteca | Ajustes > Conectar con Spotify | Tu Client ID de developer.spotify.com |
| **Internet Archive** | Música libre: búsqueda, **reproducción y descarga** | Ya funciona | Nada |
| **Deezer / iTunes Search** | Búsqueda y metadatos | Ya funciona | Nada |
| **SoundCloud** | Búsqueda; intenta su audio directo | Ajustes > Música y descargas > *Client ID de SoundCloud* | Client ID (SoundCloud ya no entrega claves nuevas a todos) |
| **Tu teléfono** | Música local (MP3, FLAC…) | Ajustes > Música y descargas | Permiso de audio |

## Qué puede hacer cada proveedor (búsqueda, reproducción y descarga son cosas distintas)

| | Buscar | Reproducir | Descargar |
|---|:-:|:-:|:-:|
| YouTube Music / YouTube Data API | sí | sí, con el reproductor oficial | **no** |
| Spotify | sí | **no** dentro de la app (se empareja con YouTube Music) | **no** |
| Apple Music | sí | **no** dentro de la app (se empareja con YouTube Music; MusicKit requiere suscripción y token de usuario) | **no** |
| Deezer / iTunes | sí | **no** (se empareja con YouTube Music) | **no** |
| SoundCloud | sí | solo si el proveedor entrega el audio | **no** |
| Internet Archive | sí | sí | sí (licencias libres) |
| Teléfono / descargas | sí | sí, sin conexión | ya están en el teléfono |

"Emparejar con YouTube Music" significa buscar esa misma canción en YouTube Music al pulsar play. No se inventan resultados: si no aparece, la app lo dice.
Si una canción no se encuentra en el proveedor elegido, la app busca automáticamente en los demás.

## Lo que la app NO hace (por diseño)
- No extrae audio de YouTube, Spotify, Apple Music ni TIDAL, ni evade DRM.
- Para una canción sin descarga autorizada muestra: «Esta canción está disponible para escuchar, pero su proveedor no permite descargarla desde esta aplicación».

## Copia de seguridad
Ajustes > Copia de seguridad: guardar un archivo JSON (en Descargas/Spotifree), restaurarlo, o volver a la **copia automática** que se hace sola al instalar esta actualización, antes de migrar nada. No incluye claves, tokens ni los archivos de música descargados.
