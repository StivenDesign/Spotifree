'use strict';
/* ===== Última reproducción: al abrir la app queda en el mini reproductor, pausada, donde la dejaste ===== */
(function () {
  const KEY = 'sf_resume';
  let restored = false, pos0 = 0;
  const save = () => {
    try {
      if (!S.queue.length || S.i < 0) return;
      if (restored && !S.loadTok) return;                         // todavía no se tocó: se conserva lo guardado
      const pos = Math.floor(E.time() || 0), t = S.queue[S.i];
      if (!t || (t.local && !t.dl && !t.dev)) return;             // los archivos locales cambian de ruta: no se restauran
      store.set(KEY, { q: S.queue.slice(Math.max(0, S.i - 5), S.i + 60).map(slim), i: Math.min(S.i, 5), pos, ts: Date.now() });
    } catch {}
  };
  // restaurar
  try {
    const r = store.get(KEY, null);
    if (r && Array.isArray(r.q) && r.q.length && S.queue.length === 0) {
      S.queue = r.q; S.orig = r.q.slice(); S.i = Math.max(0, Math.min(r.i || 0, r.q.length - 1)); pos0 = r.pos || 0; restored = true;
      paintTrack(S.queue[S.i]);
      $('mini').classList.add('show');
      if (pos0 && S.queue[S.i].duration) { const f = Math.min(1, pos0 / S.queue[S.i].duration); $('miniProg').style.transform = `scaleX(${f})`; $('cur').textContent = fmt(pos0); $('seek').value = Math.round(f * 1000); }
    }
  } catch {}
  // el primer toque en reproducir carga la canción y salta al segundo guardado
  document.addEventListener('click', (e) => {
    if (!restored || S.loadTok) return;
    const b = e.target.closest('[data-act=play]'); if (!b) return;
    e.stopImmediatePropagation(); e.preventDefault();
    const go = pos0; load(S.i);
    if (go > 3) { let n = 0; const iv = setInterval(() => { if (++n > 60) return clearInterval(iv); if (E.dur() > 0 && E.time() < go - 2) { E.seek(go); clearInterval(iv); } }, 250); }
  }, true);
  let lastKey = '';
  setInterval(() => {   // también en pausa: si pausas y cierras, la canción y el segundo quedan guardados
    if (S.i < 0 || !S.queue.length) return;
    const k = S.i + ':' + Math.floor((E.time() || 0) / 2) + ':' + S.queue.length;
    if (S.playing || S.want || k !== lastKey) { lastKey = k; save(); }
  }, 4000);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
  window.addEventListener('pagehide', save);
  const bg = window.__bg; window.__bg = (v) => { if (v) save(); return bg && bg(v); };
})();
