# Spotifree para Android

Reproductor con YouTube Music, interfaz estilo Apple Music con vidrio líquido, letras sincronizadas
(Better Lyrics, KuGou, Apple Music, LRCLIB), música local, modo video y portadas en movimiento.
Todo corre dentro de la app, sin servidor. Creada por Claude para Steven Pantoja.

## Cómo generar el APK (GitHub, sin Android Studio)

1. Entra a tu repositorio y sube este zip con el mismo nombre (`ondas-android.zip`). Reemplaza al anterior.
2. Abre la pestaña Actions y espera la palomita verde (unos 5 minutos).
3. En Releases baja el nuevo `app-debug.apk` e instálalo.

Spotifree se instala como una app nueva (no reemplaza a Ondas). Después de comprobar que funciona
puedes desinstalar Ondas.

## Qué trae

- **Barra inferior**: Inicio, Novedades, Radio, Biblioteca y Buscar. Inicio y Novedades salen de YouTube Music;
  Radio crea estaciones sin fin por género, artista o canción.
- **Cristal líquido ajustable**: Ajustes > Apariencia. De 0 % (paneles mate) a 100 % (translúcidos con desenfoque).
- **Animaciones**: transiciones con resorte entre secciones, portada que vuela al mini reproductor, arrastrar hacia
  abajo para cerrar el reproductor y vibración suave opcional.
- **Cuenta**: Ajustes > Añadir cuenta. Elige Spotify o YouTube, pon tu nombre, importa listas de YouTube con su enlace
  o conecta Spotify con tu propio Client ID (gratis, developer.spotify.com; dirección de retorno `spotifree://callback`).
  La música siempre suena desde YouTube Music.
- **Descargas**: botón Descargar en el reproductor y en Ajustes. Baja música con licencia libre de Internet Archive
  y de Jamendo (necesita tu Client ID gratuito de devportal.jamendo.com). Se guarda en la app y suena sin internet.
- **Biblioteca**: Me gusta, descargas, tu música del teléfono y listas propias.
- **Canvas estilo Spotify**: botón Canvas en el reproductor. Pon un video corto o GIF a una canción y se ve a pantalla completa detrás del reproductor. Ya no hay portada con distorsión.
- **Reproductor**: aleatorio, repetir (lista o una canción), temporizador de sueño, velocidad (0,75× a 2×),
  fundido suave al pausar, doble toque en la portada para dar me gusta y deslizar el mini reproductor para cambiar de canción.
- **Ecualizador de audio**: 5 bandas y presets (Graves, Vocal, Rock...). Solo actúa en música del teléfono y descargas.
- **Tu resumen**: tiempo escuchado, canciones y artistas favoritos, y la fila "Lo más escuchado" en Inicio.
- **Color de acento** a elegir, o automático según la portada.
- **Tirar hacia abajo** en Inicio y Novedades para actualizar.
- **Mi música**, **modo video**, **letras**, **ecualizador**, **modo ahorro**
  y **controles de Android** (notificación, pantalla de bloqueo, auriculares) siguen como antes.

## Notas

- El ecualizador de archivos locales usa el espectro real del audio. En canciones de YouTube es una animación
  que sigue el ritmo, porque YouTube no deja leer su audio.
- Las letras de Apple Music necesitan tus tokens (Ajustes > Apple Music).
- Las APIs de YouTube Music, Better Lyrics, KuGou, Apple y Spotify no son oficiales o pueden cambiar.
- Spotifree no descarga música de YouTube ni de Spotify.

## Fotos de artistas y tipografías
- Foto del artista (Deezer, necesita internet) junto a su nombre en el reproductor, en la búsqueda, en Inicio/Radio y en su página. Se apaga en Ajustes > Fotos de artistas.
- Cada artista conocido tiene su propia tipografía (Bebas Neue, Bungee, Pacifico, etc.); el resto recibe una de forma estable según su nombre.
- Toda la app usa Inter en negrita (estilo iOS). Las fuentes van dentro del APK (carpeta `www/fonts`).

## Arreglos de reproducción
- Portadas/álbum: solo se usa el resultado que coincide en título, artista y duración; si no hay coincidencia segura se queda la portada de YouTube Music.
- Si la música se pausa sola, se traba o se queda cargando, la app la reanuda o recarga en el mismo segundo. Pausar a mano se respeta.
- La app mantiene el reproductor vivo en segundo plano (servicio con notificación).

## Inicio estilo Apple Music
Título grande «Escuchar ahora», Recientes en tarjetas grandes con el nombre sobre la portada, barra inferior flotante en píldora con la búsqueda aparte y mini reproductor en píldora.

## Cristal líquido adaptable
Burbuja de cristal en la barra: se estira al cambiar de pestaña y se puede arrastrar. Si el teléfono va justo, baja solo de nivel (alto, medio, ahorro). Al apagar Modo ahorro en Ajustes vuelve a alto.

## Reproductor estilo Apple Music
Agarrador arriba, portada grande, título con estrella y más, tiempo restante (-3:29), rebobinar/pausa/adelantar grandes y fila de iconos abajo (letra, cola, aleatorio, repetir, video, canvas, descargar). La letra tiene cabecera con portada y texto grande a la izquierda.

## Más fuentes de letra
NetEase, QQ Música y Lyrics.ovh (solo texto) además de Better Lyrics, KuGou, Apple Music y LRCLIB. Auto las prueba en orden.

## Todo en cristal
Filas, fichas, hojas, menús y todo el reproductor en cristal líquido, con animaciones de entrada, brillo que recorre la barra y respiración del botón de play. Los efectos pesados se apagan solos en teléfonos justos o con Modo ahorro.

## Volumen
El deslizador controla el volumen real del teléfono (sonido multimedia) y sigue a los botones físicos.

## Rosado y más ajustes
Color por defecto rosado (como Apple Music). Nuevos ajustes: animaciones (completas/suaves/ninguna), fondo negro puro, pantalla encendida, tiempo restante, y sección Letra (tamaño, alineación, difuminado).

## Dúos
Si la letra trae varios cantantes (Better Lyrics / Apple Music), cada uno va en su lado: el primero a la izquierda, el segundo a la derecha, los coros al centro.

## Cristal extremo y portada en el reproductor de Android
- Ajustes > Cristal extremo: refracción tipo lente con aberración cromática (solo en nivel alto).
- La portada aparece en la notificación y la pantalla de bloqueo.

## Rendimiento del cristal
Calidad automática/extrema/alta/media/ahorro, lente de una sola pasada, desenfoque simple mientras se desliza, barras ocultas con el reproductor abierto, resplandor sin repintado, ahorro con batería baja. Ajustes: desenfoque y brillo de bordes.

## Música del teléfono
Ajustes > Escanear música del teléfono (o Biblioteca > Teléfono): lee la música con MediaStore, con portadas, filtro, reproducir todo y aleatorio. Aparece también en los resultados de búsqueda. Pide el permiso de audio.

## Cambios: modo plano, portada 3D, todas las fuentes juntas
- **Sin cristal líquido** por defecto (Ajustes > Cristal líquido para volver a activarlo).
- **Portada 3D**: sombras en capas, brillo del color de la portada e inclinación suave con el giroscopio o el dedo.
- **Búsqueda unificada**: YouTube Music + Spotify (si conectas la cuenta) + Apple Music (iTunes) + Deezer + SoundCloud (necesita Client ID en Ajustes). Chips para elegir una sola fuente. Las canciones de Apple/Deezer suenan emparejadas con YouTube Music.
- **Segundo plano**: servicio en primer plano, MediaSession, WebView siempre "visible" y aviso para quitar la optimización de batería (Ajustes > Sonar con la pantalla apagada).
- **Barra de estado**: toma el color de la canción (y la de navegación también), con transición suave.
- **Gama baja** (Ajustes > Optimizar para gama baja, Automático por defecto): se activa con poca RAM (<7 GB), Android 10 o menor, o procesadores Snapdragon 4xx/6xx, Helio, Unisoc y similares. Quita sombras y filtros, fondo estático con el color de la canción, portada animada y fondo móvil apagados la primera vez, 20 cuadros por segundo en el visualizador, listas que solo pintan lo visible y sin inclinación 3D. Gama alta queda igual.
- **Sin retraso al salir**: si el sistema pausa el audio al salir de la app, se reanuda al instante (antes esperaba 0.4 s o más) y también desde onPause de Android.
- **Mezcla entre canciones**: botón en cada lista y en la cola (y duración en Ajustes, 3 a 12 s). La canción se apaga y la siguiente sube, sin silencio; es un fundido encadenado, no un solape real.
- **Hoja de mezcla**: al tocar el botón de mezcla (listas, cola o Ajustes) se abre un editor con gráfico de la transición, ajustes predefinidos (Automática, Fundido, Corte rápido, Club, Vinilo, Personalizada), duración, curva de volumen y efecto; botón Probar la mezcla.
- **Página de lista estilo Apple Music**: portada grande con 3D, fondo con el color/portada, título centrado, botones aleatorio · Reproducir · añadir; mezcla y más arriba a la derecha.
- **Añadir música a una lista**: botón + en la lista (y en la lista vacía): buscador con tus Me gusta/recientes y resultados de YouTube Music, con +/✓ por canción.
- **Sugerencias al escribir** en el buscador: sugerencias de búsqueda (con lo que falta en negrita) y 4 canciones en vivo, en cada letra.
- **Mezcla editable**: arrastra los bordes del gráfico para la duración y el punto de la curva para darle forma; texto "Mezclando…" que brilla (también en el reproductor mientras se mezcla), línea verde de progreso y final fundido editable (3 a 15 s, 5 s por defecto).
- **Vista previa de la mezcla**: al abrir el editor suena el fragmento del punto de mezcla en bucle (se apaga y vuelve a subir con tus ajustes), con barra para moverte por toda la canción y pausa; al cerrar vuelve a donde estabas. "Probar con la siguiente canción" hace la transición real.

## Actualización definitiva (resumen)
- **Modo gráfico** (Ajustes > Apariencia): Automático, Light Glass (gama baja), Smooth Glass (media), Full Glass (alta) y Sólido. Respeta el movimiento reducido del sistema.
- **Buscador unificado** con YouTube Music, YouTube Data API (con tu clave), Spotify, Apple Music (API o iTunes), Deezer, Jamendo, Internet Archive y SoundCloud; los resultados aparecen según llega cada proveedor, con caché de 6 minutos y búsqueda automática en los demás si el elegido no la tiene.
- **Disponibilidad**: menú de cada canción > Disponibilidad (búsqueda / reproducción / descarga por separado).
- **Descargas**: botón en cada canción y en el reproductor, progreso y porcentaje, cancelar, duplicados, espacio usado y libre, chip flotante; solo con licencia libre (Jamendo, Internet Archive).
- **Audio de fuentes libres** servido por la app (visualizador y ecualizador funcionan).
- **Calidad de audio** en el reproductor (formato y origen reales; nada inventado).
- **Copia de seguridad** y copia automática previa a la migración; ver INSTRUCCIONES_APIS.md.
- Aviso de **sin conexión**.

## Letras sincronizadas: más fuentes + nuevo reproductor

- Nuevas fuentes de letra (Ajustes › Letra, o el menú ⋯ de la vista de letra): **LRCLIB (amplia)** (búsqueda con título limpio, solo versiones sincronizadas), **SimpMusic** (por videoId de YouTube) y **Subtítulos YouTube** (si el video trae subtítulos). El modo Auto las prueba en este orden: Better Lyrics, Apple, LRCLIB, SimpMusic, LRCLIB amplia, KuGou, NetEase, QQ, subtítulos, texto plano.
- Si una fuente falla, se reintenta con el título limpio (sin "feat.", "(Remastered)", "- Remix"…).
- ⚠ Estas fuentes no se pudieron probar contra sus servidores reales desde el entorno de desarrollo; si alguna cambia su API simplemente falla y el modo Auto pasa a la siguiente.
- Reproductor: portada a pantalla completa tras la barra de estado, título/artista sobre la portada, una línea de letra con flecha, controles planos, fila inferior (letra, aleatorio+repetir, cola) y botones Video/Canvas/Descargar. La vista de letra comparte los mismos controles (el botón de letra se resalta) y muestra «Letra de <fuente>».
- Los botones de globo/traducir de la referencia no se agregaron porque no hay traducción real implementada.

## Letra: puntos de espera, brillo por palabra, modo limpio y pantalla completa

- Puntos de espera (●●●) al inicio, en silencios largos entre estrofas y en las líneas vacías de la letra; se llenan mientras pasa el silencio y desaparecen cuando vuelve a cantar.
- La palabra que se canta se ilumina progresivamente. Si la fuente trae tiempos por palabra (Better Lyrics/Apple) se usan; si no, el tiempo de la línea se reparte según el largo de cada palabra (es una estimación).
- Con la letra abierta solo se ven el título y la letra. Los controles aparecen al tocar la zona de abajo o la portada pequeña, y se ocultan solos a los 4,5 s. Para cerrar la letra: botón de letra (con los controles visibles) o el gesto de atrás.
- Pantalla completa real: barras de estado y navegación transparentes; la portada y el fondo se dibujan detrás. Los márgenes se leen en Android (`Native.insets`) y se aplican a `--sat`/`--sab`. Con el teclado abierto la página se encoge.

- Letra alineada a la izquierda por defecto (los dúos siguen cada uno en su lado; se cambia en Ajustes › Alineación).
- Video, Canvas y Descargar ya no están en la pantalla del reproductor: están en el menú ⋯ de la canción.

## Géneros con foto, Biblioteca estilo Apple Music
- Radio (estaciones) y Explorar todo: cada género lleva la foto de un cantante representativo (ver `GENRE_ARTIST` en `js/views.js`), en gris y teñida con el color del botón; en Radio va como portada inclinada. Hay más géneros (Cumbia, Vallenato, Bachata, Corridos tumbados, Trap, Country, Reggae, Punk, Soul, Blues, House). La foto se busca con el mismo servicio de fotos de artistas de la app; si no llega, el botón queda solo con su color.
- Biblioteca: lista Playlists / Artistas / Álbumes / Canciones / Me gusta / Descargas / Mi música / Del teléfono / Tu resumen / Ecualizador, y «Agregadas recientemente». Artistas y Álbumes se arman con tus canciones guardadas (me gusta, descargas, tu música, teléfono).
- Degradado bajo la barra de estado para que el contenido no choque con la hora y los iconos.

## Última reproducción y cierre
- La app guarda cada pocos segundos la cola y el segundo en que ibas (`js/resume.js`). Al abrirla de nuevo aparece en el mini reproductor, en pausa; al tocar reproducir carga la canción y salta a ese segundo (es aproximado). Los archivos locales sueltos no se restauran.
- Al salir con el botón de inicio la música sigue; al quitar la app de recientes se detiene la notificación, la reproducción y el proceso (`PlayerService.onTaskRemoved`).

## Inicio, Novedades y Radio estilo Apple Music; letra con puntos y barrido suave
- Títulos grandes con línea debajo y menú ⋮ rojo (Ajustes, Cuenta y acciones de cada pantalla). Inicio: «Top selecciones para ti» (la primera fila de YouTube Music en tarjetas grandes), «Reproducciones recientes ›» y el resto. Novedades: «NUEVO ÁLBUM» con tarjeta grande en carrusel y «Canciones nuevas destacadas ›» en columnas de 4. Radio: cuadrícula de 3 columnas y «Al aire ahora» con tarjetas grandes con la foto del cantante. No se usan logos ni marcas de Apple.
- Letra: puntos del tamaño de la letra que se llenan, brillan y se encogen al terminar el silencio; el barrido de cada palabra tiene borde suave.

- Barra inferior estilo Apple Music: mini reproductor plano de borde a borde y pestañas (Inicio, Novedades, Radio, Biblioteca, Buscar) pegadas al borde de la pantalla, con el color del fondo del sistema debajo del gesto de inicio.

- Ilustración animada (Ajustes): cuando el álbum tiene portada animada en Apple Music, la portada se mueve (solo con la pantalla de reproducción abierta y sonando). No todos los álbumes la tienen, la búsqueda se hace por título/artista y no pude probarla con el servidor real. Se quitaron las barras del ecualizador que bailaban sobre la portada.

- Canvas automático (Ajustes): ilustración animada de Apple → video oficial de YouTube (modo Video del reproductor) → fondo animado por género (Pixabay, licencia libre, con tu clave gratis; el género sale de iTunes). Tu canvas propio siempre tiene prioridad. La clave de Pixabay no entra en las copias de seguridad. No se usa el Canvas de Spotify (no tiene API oficial).

## Reproductor plano (estilo Apple Music)
Portada a pantalla completa que se funde con el color de la portada, título/artista grandes con ★ y ⋮, tiempo restante, controles planos, solo letra y cola abajo. Aleatorio y Repetir pasaron al menú ⋮; Video/Canvas/Descargar siguen en ⋮. Volumen y filas extra ocultos.

## Vista de letra plana
Cabecera de la letra sin cápsula: miniatura, título/artista, ★ y ⋮ en círculos translúcidos. El botón de letra activo se ve como cuadro relleno.

## Menú ⋮ estilo Apple Music
Hoja plana oscura con portada grande, título, artista en rojo, álbum en gris e iconos rojos. "Iniciar radio" ahora se llama "Crear estación" y "Temporizador de sueño" → "Temporizador de reposo". La pantalla de la fila ya tenía ese diseño.

## Botón de la fila (cola) como el ejemplo
El botón de la cola usa el ícono de lista con viñetas y, al abrirse la fila dentro del reproductor, queda como cuadro relleno (igual que el de letra). Iconos inferiores más grandes y en tono de la portada.

## Animaciones + audio sin retraso al salir/entrar
- Animaciones suaves (solo transform/opacity): cabeceras y tarjetas al entrar, filas, menú ⋮, entrada escalonada del reproductor, pulsación con muelle, latido de la estrella. No se aplican en modo ligero/rendimiento.
- Audio: tras salir o volver a la app hay 5 s de gracia en los que el vigilante ya no recarga ni reinicia el video (esas recargas causaban los cortes y retrasos); también se ignora el vigilante mientras la app está en segundo plano.

## "Reproduciendo" con brillo y botones animados
Entre los controles y la fila de iconos aparece "Reproduciendo" con un brillo que lo recorre (muestra "En pausa" cuando está pausado). Play/pausa con rebote al cambiar, anillo suave mientras suena y anterior/siguiente se desplazan al tocarlos.

## Puntos de la letra animados
Los 3 puntos (intro o silencio) entran uno a uno con rebote, respiran con brillo mientras esperan y al terminar se encogen uno tras otro y el espacio se cierra suave. Se desactivan en modo ligero/rendimiento.
