/* Ajustes extra: personalizar inicio y opciones del reproductor */
(function () {
  const HIDE = { hRecent: 'shRecent', hFy: 'forYou', hMyArt: 'shMyArt', hTop: 'shTop', hMine: 'shMine', hArtists: 'artists' };
  function apply() {
    Object.keys(HIDE).forEach((k) => document.body.classList.toggle('hide-' + k, CFG[k] === true));
  }
  apply();
  document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('[data-cfg]')) apply(); });

  // abrir la letra automáticamente al abrir el reproductor
  const oNP = window.openNP;
  if (typeof oNP === 'function') window.openNP = function () {
    const r = oNP.apply(this, arguments);
    if (CFG.autoLyr === true) setTimeout(() => { try { if (S.npOpen && !S.lyrOpen && typeof openLyr === 'function') openLyr(); } catch {} }, 450);
    return r;
  };

  // doble toque en la portada = me gusta
  let last = 0;
  const ab = document.getElementById('artbox');
  if (ab) ab.addEventListener('click', (e) => {
    if (CFG.dblLike === false) return;
    const now = Date.now();
    if (now - last < 320) {
      last = 0; e.stopPropagation();
      try {
        const t = S.queue[S.i]; if (t && typeof toggleLike === 'function') { toggleLike(t); haptic(12); }
      } catch {}
    } else last = now;
  });
})();

/* ---- más ajustes: deslizar portada, insignia E, línea de calidad, tamaño de recientes ---- */
(function () {
  const look = () => {
    const b = document.body;
    b.classList.toggle('hide-exp', CFG.hideExp === true);
    b.classList.toggle('hide-qual', CFG.hideQual === true);
    ['s', 'm', 'l'].forEach((k) => b.classList.toggle('rc-' + k, (CFG.recSize || 'm') === k));
  };
  look();
  document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('[data-cfg]')) look(); });
  const ab = document.getElementById('artbox'); if (!ab) return;
  let x0 = 0, y0 = 0, t0 = 0;
  ab.addEventListener('touchstart', (e) => { const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; t0 = Date.now(); }, { passive: true });
  ab.addEventListener('touchend', (e) => {
    if (CFG.swipeCover === false) return;
    const t = e.changedTouches[0], dx = t.clientX - x0, dy = t.clientY - y0;
    if (Date.now() - t0 > 700 || Math.abs(dx) < 70 || Math.abs(dy) > 50) return;
    try { haptic(8); if (dx < 0) next(); else prev(); } catch {}
  }, { passive: true });
})();
