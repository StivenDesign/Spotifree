'use strict';
/* ===== Vistas: Inicio, Novedades, Radio, Biblioteca, Buscar, páginas de lista, cola y menús ===== */
const GENRES = ['Pop', 'Reguetón', 'Hip hop', 'Rock', 'Electrónica', 'Latino', 'Indie', 'Baladas', 'Lo-fi', 'Salsa', 'Regional mexicano', 'K-pop', 'Jazz', 'Clásica', 'Metal', 'R&B'];
const STATIONS = ['Pop', 'Reguetón', 'Hip hop', 'Rock', 'Electrónica', 'Latino', 'Indie', 'Lo-fi', 'Salsa', 'Baladas'];
const ARTISTS = ['Bad Bunny', 'Karol G', 'Rosalía', 'The Weeknd', 'Dua Lipa', 'Taylor Swift', 'Peso Pluma', 'Shakira', 'Feid', 'Billie Eilish'];

/* ---------- datos propios: me gusta y listas ---------- */
const slim = (t) => {
  const o = { title: t.title, artist: t.artist || '', album: t.album || '', duration: t.duration || 0, cover: t.cover || '' };
  if (t.src) o.src = t.src;
  if (t.dlUrl) Object.assign(o, { dlUrl: t.dlUrl, dlSrc: t.dlSrc, license: t.license || '' });
  if (t.stream && t.url) Object.assign(o, { stream: true, free: true, url: t.url, license: t.license || '' });
  if (t.sc) Object.assign(o, { sc: true, scId: t.scId, scTr: t.scTr });
  if (t.dl) Object.assign(o, { local: true, dl: true, did: t.did, url: t.url }); else if (t.videoId) o.videoId = t.videoId;
  return o;
};
let LIKES = store.get('sf_likes', []);
let LISTS = store.get('sf_lists', []);
const saveLikes = () => store.set('sf_likes', LIKES);
const saveLists = () => store.set('sf_lists', LISTS);
const isLiked = (t) => !!t && LIKES.some((x) => tid(x) === tid(t));
function toggleLike(t) {
  if (!t) return;
  if (t.local && !t.dl) return toast('Me gusta funciona con canciones de YouTube y con tus descargas');
  const was = isLiked(t);
  LIKES = was ? LIKES.filter((x) => tid(x) !== tid(t)) : [slim(t), ...LIKES];
  saveLikes(); paintLike(true); refreshLibViews(); haptic(10);
  toast(was ? 'Quitada de Me gusta' : 'Añadida a Me gusta');
}
function paintLike(pop) {
  const on = isLiked(S.queue[S.i]);
  document.querySelectorAll('.like-btn').forEach((b) => { b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
  if (pop) { const h = document.querySelector('.heart'); h.classList.remove('pop'); void h.offsetWidth; h.classList.add('pop'); }
}
function newList(name, tracks = []) { const l = { id: 'l' + Date.now() + Math.random().toString(36).slice(2, 5), name, tracks: tracks.map(slim) }; LISTS.unshift(l); saveLists(); refreshLibViews(); return l; }
function addToList(l, t) {
  if (l.tracks.some((x) => tid(x) === tid(t))) return toast('Ya está en «' + l.name + '»');
  l.tracks.push(slim(t)); saveLists(); refreshLibViews(); toast('Añadida a «' + l.name + '»');
}
function askText(title, placeholder, initial, cb) {
  const w = document.createElement('div'); w.className = 'cfg';
  w.innerHTML = `<form class="glass"><h3>${esc(title)}</h3><label><input autocomplete="off" placeholder="${esc(placeholder)}" value="${esc(initial || '')}"></label><div class="btns"><button type="button" class="c">Cancelar</button><button class="ok" type="submit">Guardar</button></div></form>`;
  document.body.append(w); const inp = w.querySelector('input'); setTimeout(() => inp.focus(), 50);
  w.querySelector('.c').onclick = () => w.remove();
  w.querySelector('form').onsubmit = (e) => { e.preventDefault(); const v = inp.value.trim(); w.remove(); if (v) cb(v); };
}

/* ---------- piezas comunes ---------- */
document.addEventListener('load', (e) => { if (e.target.tagName === 'IMG') e.target.classList.add('ld'); }, true);
const grad = (s) => `linear-gradient(135deg,hsl(${hue(s)} 62% 42%),hsl(${(hue(s) + 50) % 360} 60% 22%))`;
function card({ title, sub, img, round, big, onclick }) {
  const b = document.createElement('button'); b.className = 'rcard' + (round ? ' round' : '') + (big ? ' big' : '');
  b.innerHTML = `<div class="im">${img ? `<img src="${esc(img)}" alt="" loading="lazy">` : ''}${big ? `<div class="ov"><b>${esc(title)}</b><small>${esc(sub || '')}</small></div>` : ''}</div>${big ? '' : `<b>${esc(title)}</b><small>${esc(sub || '')}</small>`}`;
  if (!img) { const im = b.firstChild; im.style.background = grad(title); im.innerHTML = `<span style="display:grid;place-items:center;height:100%;font-size:46px;font-weight:800;opacity:.85">${esc((title[0] || '♪').toUpperCase())}</span>`; }
  b.onclick = () => onclick(b);
  return b;
}
const SRC_NAME = { am: 'APPLE MUSIC', dz: 'DEEZER', sc: 'SOUNDCLOUD', yd: 'YOUTUBE', jm: 'JAMENDO', ia: 'ARCHIVE' };
const BARS_HTML = '<span class="bars"><b></b><b></b><b></b><b></b></span>';
function trackRow(t, list, idx, o = {}) {
  const cur = S.queue[S.i], now = cur && tid(cur) === tid(t);
  const r = document.createElement('div'); r.className = 'row rip' + (now ? ' cur' : ''); r.tabIndex = 0; r.setAttribute('role', 'button'); r.style.setProperty('--i', Math.min(idx, 12));
  const badge = t.dl ? '<span class="badge">DESCARGADA</span>' : t.local ? '<span class="badge">LOCAL</span>' : t.sp ? '<span class="badge">SPOTIFY</span>' : t.free ? `<span class="badge">LIBRE · ${esc(String(t.src || '').toUpperCase())}</span>` : t.src && SRC_NAME[t.src] ? `<span class="badge">${SRC_NAME[t.src]}</span>` : '';
  r.innerHTML = `<img class="cv" src="${esc(t.cover || makeCover(t.title + t.artist))}" alt="" loading="lazy"><div class="tx"><b>${esc(t.title)}</b><small>${badge}${esc(t.artist || '')}${t.album && !o.noAlbum ? ' · ' + esc(t.album) : ''}</small></div>${t.duration ? `<span class="dur">${fmt(t.duration)}</span>` : ''}${!t.local && !t.dl ? `<button class="dlb${dlOk(t) ? ' free' : ''}" aria-label="Descargar"><svg class="ic s"><use href="#i-dl"/></svg></button>` : ''}<button class="more" aria-label="Más opciones"><svg class="ic"><use href="#i-dots"/></svg></button>`;
  { const im = r.querySelector('.cv'); if (im) im.onerror = () => { im.onerror = null; im.src = makeCover(t.title + t.artist); }; }
  r.dataset.tid = tid(t);
  if (now) r.querySelector('.more').insertAdjacentHTML('beforebegin', BARS_HTML);
  r.onclick = (e) => {
    if (e.target.closest('.more')) { e.stopPropagation(); return trackMenu(t, o); }
    if (e.target.closest('.dlb')) { e.stopPropagation(); return downloadTrack(t); }
    r.classList.remove('tap'); void r.offsetWidth; r.classList.add('tap'); setTimeout(() => r.classList.remove('tap'), 700);
    haptic(8); play(list, idx, r.querySelector('.cv'), o.radio ? { radio: t.videoId } : undefined);
  };
  r.onkeydown = (e) => { if (e.key === 'Enter') r.onclick(e); };
  return r;
}
function fillList(box, list, o) { box.innerHTML = ''; list.forEach((t, i) => box.append(trackRow(t, list, i, o))); }
const skel = (n = 4) => '<div class="skel"></div>'.repeat(n);
const songsOf = (items) => items.filter((x) => x.kind === 'song');

/* ---------- menú de una canción ---------- */
function trackMenu(t, o = {}) {
  const liked = isLiked(t);
  openMenu({ title: t.title, sub: t.artist, cover: t.cover }, [
    { icon: 'queue', label: 'Reproducir a continuación', run: () => { if (S.i < 0) return play([t], 0); S.queue.splice(S.i + 1, 0, t); toast('Sonará a continuación'); renderQueue(); } },
    { icon: 'plus', label: 'Añadir a la cola', run: () => { if (S.i < 0) return play([t], 0); S.queue.push(t); toast('Añadida a la cola'); renderQueue(); } },
    { icon: 'heart', label: liked ? 'Quitar de Me gusta' : 'Me gusta', run: () => toggleLike(t) },
    { icon: 'lib', label: 'Añadir a una lista…', keep: true, run: () => listPicker(t) },
    t.videoId ? { icon: 'radio', label: 'Iniciar radio', run: () => startRadio(t) } : null,
    !t.local ? { icon: 'dl', label: dlOk(t) ? 'Descargar' : 'Descargar…', run: () => downloadTrack(t) } : null,
    !t.local ? { icon: 'chart', label: 'Disponibilidad', run: () => availMenu(t) } : null,
    o.remove ? { icon: 'trash', label: o.removeLabel || 'Quitar de esta lista', run: o.remove } : null,
    o.np ? { icon: 'moon', label: 'Temporizador de sueño', run: sleepMenu } : null,
    o.np ? { icon: 'chart', label: 'Velocidad: ' + (CFG.rate || 1) + '×', run: speedMenu } : null,
    o.np ? { icon: 'sliders', label: 'Ecualizador de audio', run: () => { openSheet('eqs'); paintEq(); } } : null,
    t.dl ? { icon: 'trash', label: 'Eliminar descarga', run: () => deleteDownload(t) } : null,
    t.local && !t.dl && !t.dev ? { icon: 'trash', label: 'Quitar de Mi música', run: () => removeTrack(t) } : null,
  ]);
}
function listPicker(t) {
  openMenu({ title: 'Añadir a una lista', sub: t.title, cover: t.cover }, [
    { icon: 'plus', label: 'Nueva lista…', run: () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { addToList(newList(n), t); }) },
    ...LISTS.map((l) => ({ icon: 'lib', label: `${l.name} · ${l.tracks.length}`, run: () => addToList(l, t) })),
  ]);
}
async function startRadio(seed) {
  if (!seed || !seed.videoId) return;
  toast('Creando radio…');
  try {
    const d = await apiGet('radio', { videoId: seed.videoId });
    const list = [seed, ...d.tracks.filter((x) => x.videoId !== seed.videoId)];
    play(list, 0, null, { radio: list[list.length - 1].videoId }); S.radioName = seed.title; paintRadioNow();
  } catch (e) { toast('No pude crear la radio: ' + e.message); }
}

/* ---------- Inicio ---------- */
let homeChip = 'all', homeData = store.get('sf_home', null);
function greeting() {
  const h = new Date().getHours(), base = h < 6 ? 'Buenas noches' : h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
  const n = (typeof ACC !== 'undefined' && ACC.name) || ''; return n ? `${base}, ${n}` : base;
}
function recents() { return store.get('ondas_recent', []); }
function addRecent(t) {
  if (t.local && !t.dl) return;
  const rec = recents().filter((x) => tid(x) !== tid(t)); rec.unshift(slim(t)); store.set('ondas_recent', rec.slice(0, 14));
}
function dlTracksSafe() { return typeof dlTracks === 'function' ? dlTracks() : []; }
// artistas que más escuchas (o los de tus recientes), con su foto
let myArtKey = '';
function paintMyArtists() {
  const count = {};
  (typeof STATS !== 'undefined' ? Object.values(STATS.plays) : []).forEach((p) => { const a = mainArtist(p.track.artist); if (a) count[a] = (count[a] || 0) + p.n; });
  recents().forEach((t) => { const a = mainArtist(t.artist); if (a && !count[a]) count[a] = 0.1; });
  const names = Object.entries(count).sort((x, y) => y[1] - x[1]).slice(0, 10).map((e) => e[0]), key = names.join('|');
  $('shMyArt').hidden = !(names.length && homeChip === 'all');
  if (key === myArtKey) return; myArtKey = key;
  const box = $('myArtists'); box.innerHTML = '';
  names.forEach((n) => { const c = card({ title: n, sub: 'Artista', round: true, onclick: () => openArtist(n) }); box.append(c); decorateArtistCard(c, n); });
}
function refreshHome() {
  const rec = recents(), mine = LIB, dls = dlTracksSafe();
  const q = [];
  q.push({ title: 'Canciones que te gustan', img: LIKES[0] && LIKES[0].cover, grad: 'likes', go: () => openColl({ title: 'Canciones que te gustan', sub: LIKES.length + ' canciones', tracks: LIKES, cover: LIKES[0] && LIKES[0].cover, key: 'likes' }) });
  q.push({ title: 'Mis descargas', img: dls[0] && dls[0].cover, go: () => openColl({ title: 'Mis descargas', sub: dls.length + ' canciones', tracks: dlTracksSafe(), cover: dls[0] && dls[0].cover, key: 'dl' }) });
  q.push({ title: 'Mi música', img: mine[0] && mine[0].cover, go: () => openColl({ title: 'Mi música', sub: LIB.length + ' canciones', tracks: LIB, cover: LIB[0] && LIB[0].cover, key: 'mine' }) });
  rec.slice(0, rec[0] && rec[0].videoId ? 2 : 3).forEach((t, i) => q.push({ title: t.title, img: t.cover, go: () => play(rec, i) }));
  if (rec[0] && rec[0].videoId && window.ClientAPI) q.push({ title: 'Radio de ' + rec[0].title, img: rec[0].cover, go: () => startRadio(rec[0]) });
  const quick = $('quick'); quick.innerHTML = '';
  q.forEach((x) => {
    const b = document.createElement('button'); b.className = 'q';
    b.innerHTML = `${x.img ? `<img src="${esc(x.img)}" alt="">` : `<img alt="" src="${makeCover(x.title)}">`}<span>${esc(x.title)}</span>`;
    b.onclick = () => { haptic(6); x.go(); }; quick.append(b);
  });
  const rail = (box, list, playList, big) => { box.innerHTML = ''; list.forEach((t, i) => box.append(card({ title: t.title, sub: t.artist, img: t.cover, big, onclick: (b) => { haptic(8); play(playList || list, i, b.querySelector('img')); } }))); };
  rail($('recent'), rec, null, true); rail($('homeMine'), mine); rail($('homeDl'), dls);
  paintMyArtists();
  const top = typeof topTracks === 'function' ? topTracks(10).filter((p) => p.n >= 2).map((p) => p.track) : [];
  rail($('homeTop'), top);
  const all = homeChip === 'all';
  $('quick').hidden = true; if (typeof paintSpHome === 'function') paintSpHome();
  $('shRecent').hidden = !(rec.length && (all || homeChip === 'recent'));
  $('shTop').hidden = !(top.length >= 3 && all);
  $('shMine').hidden = !(mine.length && homeChip === 'mine');
  $('shDl').hidden = !(dls.length && homeChip === 'dl');
  $('ytShelves').hidden = !all; $('artists').parentElement.hidden = !all;
  $('shEmpty').hidden = !(all && !rec.length && !LIKES.length && !mine.length && !dls.length && !homeData);
}
$('hChips').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return; homeChip = b.dataset.chip;
  $('hChips').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); haptic(5); refreshHome();
});
function shelfHTML(box, sections, max = 7) {
  box.innerHTML = '';
  sections.slice(0, max).forEach((s, i) => {
    const sec = document.createElement('section'); sec.className = 'shelf';
    sec.innerHTML = `<h2>${esc(s.title || 'Para ti')}</h2><div class="hscroll"></div>`;
    const rail = sec.querySelector('.hscroll'), songs = songsOf(s.items);
    s.items.slice(0, 14).forEach((it) => rail.append(card({
      title: it.title, sub: it.kind === 'song' ? it.artist : it.sub, img: it.cover, round: it.kind === 'artist',
      onclick: (b) => { haptic(8); if (it.kind === 'song') play(songs, songs.indexOf(it), b.querySelector('img')); else openColl({ id: it.id, title: it.title, sub: it.sub || '', cover: it.cover, isArtist: it.kind === 'artist' }); },
    })));
    sec.style.animationDelay = i * 70 + 'ms'; box.append(sec);
  });
}
async function loadHome(force) {
  if (!window.ClientAPI) { $('ytShelves').innerHTML = '<p class="empty-t">Las secciones de YouTube Music están disponibles en la app de Android.</p>'; return; }
  const fresh = homeData && Date.now() - homeData.t < 6 * 3600e3;
  if (homeData) shelfHTML($('ytShelves'), homeData.sections); else $('ytShelves').innerHTML = `<div class="shelf"><h2>Para ti</h2>${skel(3)}</div>`;
  if (fresh && !force) return;
  try {
    const [d, ch] = await Promise.all([apiGet('home', {}), apiGet('charts', {}).catch(() => ({ sections: [] }))]);
    // listas oficiales (éxitos del momento) primero
    const charts = (ch.sections || []).filter((s) => s.items.some((x) => x.kind === 'song')).slice(0, 2).map((s) => ({ title: 'Éxitos oficiales' + (s.title ? ' · ' + s.title : ''), items: s.items }));
    d.sections = [...charts, ...d.sections];
    if (d.sections.length) { homeData = { t: Date.now(), sections: d.sections.slice(0, 9).map((s) => ({ title: s.title, items: s.items.slice(0, 14) })) }; store.set('sf_home', homeData); shelfHTML($('ytShelves'), homeData.sections); }
    else if (!homeData) $('ytShelves').innerHTML = '';
    refreshHome();
    loadSpHome();
  } catch (e) { if (!homeData) $('ytShelves').innerHTML = `<p class="empty-t">No pude cargar tu inicio (${esc(e.message)}). Prueba a buscar algo.</p>`; }
}
function initArtists() {
  const box = $('artists'); box.innerHTML = '';
  ARTISTS.forEach((n) => { const c = card({ title: n, sub: 'Artista', round: true, onclick: () => openArtist(n) }); box.append(c); decorateArtistCard(c, n); });
}
async function openArtist(name) {
  haptic(6); const info = await artistInfo(name).catch(() => null);
  openColl({ title: (info && info.name) || name, sub: info && info.fans ? Number(info.fans).toLocaleString('es') + ' seguidores' : 'Canciones populares', cover: info && info.picture, tracks: null, loading: true, isArtist: true });
  try { const d = await apiGet('search', { q: name, type: 'songs' }); fillCollTracks({ title: (info && info.name) || name, sub: info && info.fans ? Number(info.fans).toLocaleString('es') + ' seguidores' : 'Canciones populares', cover: (info && info.picture) || (d.results[0] && d.results[0].cover), tracks: d.results, isArtist: true }); }
  catch (e) { $('collList').innerHTML = `<p class="empty-t">No pude buscar: ${esc(e.message)}</p>`; }
}

/* ---------- Novedades ---------- */
let newsData = store.get('sf_news', null), newsBusy = false;
function paintNews() {
  const box = $('newsBody'); box.innerHTML = '';
  if (!newsData) return;
  const first = newsData.sections.find((s) => s.items.some((i) => i.kind === 'album' || i.kind === 'playlist')), hero = first && first.items.find((i) => i.kind !== 'song');
  if (hero) {
    const h = document.createElement('button'); h.className = 'news-hero';
    h.innerHTML = `<img src="${esc(hero.cover)}" alt=""><div class="ov"><small>Nuevo lanzamiento</small><b>${esc(hero.title)}</b><small>${esc(hero.sub || '')}</small></div>`;
    h.onclick = () => { haptic(8); openColl({ id: hero.id, title: hero.title, sub: hero.sub || '', cover: hero.cover }); }; box.append(h);
  }
  const wrap = document.createElement('div'); box.append(wrap); shelfHTML(wrap, newsData.sections, 8);
}
async function loadNews(force) {
  if (!window.ClientAPI) { $('newsBody').innerHTML = '<p class="empty-t">Las novedades están disponibles en la app de Android.</p>'; return; }
  if (newsBusy) return; const fresh = newsData && Date.now() - newsData.t < 6 * 3600e3;
  if (newsData) paintNews(); else $('newsBody').innerHTML = skel(5);
  if (fresh && !force) return;
  newsBusy = true; $('newsRefresh').classList.add('spin');
  try {
    const d = await apiGet('news', {});
    newsData = { t: Date.now(), sections: d.sections.slice(0, 10).map((s) => ({ title: s.title, items: s.items.slice(0, 14) })) }; store.set('sf_news', newsData); paintNews();
  } catch (e) { if (!newsData) $('newsBody').innerHTML = `<p class="empty-t">No pude cargar las novedades (${esc(e.message)}).</p>`; else toast('No pude actualizar'); }
  newsBusy = false; $('newsRefresh').classList.remove('spin');
}

/* ---------- Radio ---------- */
function paintRadioNow() {
  const t = S.queue[S.i], box = $('radioNow');
  if (!t || !t.videoId) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="radio-now glass"><img src="${esc(t.cover)}" alt=""><div style="flex:1;min-width:0"><b>${S.radioSeed ? 'Radio en marcha' : 'Radio de esta canción'}</b><small>${esc(t.title)} · ${esc(t.artist)}</small></div><button class="pill glass solid" id="rnGo">${S.radioSeed ? 'Reiniciar' : 'Iniciar'}</button></div>`;
  $('rnGo').onclick = () => startRadio(t);
}
async function stationFrom(q) {
  toast('Sintonizando…');
  try {
    const d = await apiGet('search', { q, type: 'songs' });
    if (!d.results.length) return toast('No encontré canciones');
    if (window.ClientAPI) startRadio(d.results[0]); else play(d.results, 0);
  } catch (e) { toast('No pude sintonizar: ' + e.message); }
}
function initRadio() {
  const box = $('stations'); box.innerHTML = '';
  STATIONS.forEach((n) => {
    const b = document.createElement('button'); b.className = 'st'; b.style.background = grad('st' + n);
    b.innerHTML = `<span>${esc(n)}</span><small>Radio sin fin</small><svg class="ic s"><use href="#i-radio"/></svg>`;
    b.onclick = () => { haptic(8); stationFrom(n + ' hits'); }; box.append(b);
  });
  const ra = $('radioArtists'); ra.innerHTML = '';
  ARTISTS.forEach((n) => { const c = card({ title: n, sub: 'Radio', round: true, onclick: () => { haptic(8); stationFrom(n); } }); ra.append(c); decorateArtistCard(c, n); });
}

/* ---------- Biblioteca ---------- */
let libFilter = 'all';
function listCover(tracks) { return tracks[0] && tracks[0].cover; }
function renderLib() {
  const box = $('libBody'); box.innerHTML = '';
  const dls = dlTracksSafe(), f = libFilter;
  const tile = (icon, title, sub, color, go) => {
    const b = document.createElement('button'); b.className = 'glass'; b.innerHTML = `<div class="ico" style="background:${color}"><svg class="ic s"><use href="#i-${icon}"/></svg></div><div><span>${esc(title)}</span><small>${esc(sub)}</small></div>`; b.onclick = () => { haptic(6); go(); }; return b;
  };
  if (f === 'all') {
    const top = document.createElement('div'); top.className = 'lib-top';
    top.append(
      tile('heart', 'Me gusta', LIKES.length + ' canciones', 'linear-gradient(135deg,#5b3df0,#b7a8ff)', () => { libFilter = 'likes'; syncLibChips(); renderLib(); }),
      tile('dl', 'Descargas', dls.length + ' canciones', 'linear-gradient(135deg,#0d9d4f,#6af0a0)', () => { libFilter = 'dl'; syncLibChips(); renderLib(); }),
      tile('note', 'Mi música', LIB.length + ' canciones', 'linear-gradient(135deg,#d6336c,#ff9bb7)', () => { libFilter = 'mine'; syncLibChips(); renderLib(); }),
      tile('queue', 'Del teléfono', (typeof DEV !== 'undefined' && DEV.length ? DEV.length + ' canciones' : 'Escanear música'), 'linear-gradient(135deg,#0ea5a4,#7ff0e8)', () => { libFilter = 'device'; syncLibChips(); renderLib(); }),
      tile('chart', 'Tu resumen', 'Lo que más escuchas', 'linear-gradient(135deg,#e67e22,#f9c784)', () => { renderStats(); openSheet('stats'); }),
      tile('sliders', 'Ecualizador', 'Graves y agudos', 'linear-gradient(135deg,#2c7be5,#8ec0ff)', () => { openSheet('eqs'); paintEq(); }),
      tile('plus', 'Nueva lista', 'Crea una lista', 'linear-gradient(135deg,#444,#888)', () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { newList(n); toast('Lista creada'); }))
    );
    box.append(top);
  }
  if (f === 'all' || f === 'lists') {
    if (f === 'lists') { const nb = document.createElement('button'); nb.className = 'pill glass'; nb.textContent = 'Nueva lista'; nb.onclick = () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { newList(n); toast('Lista creada'); }); box.append(nb); }
    if (LISTS.length) {
      const h = document.createElement('div'); h.className = 'sec-h'; h.style.padding = '10px 0 4px'; h.textContent = 'Tus listas'; box.append(h);
      LISTS.forEach((l, i) => {
        const r = document.createElement('div'); r.className = 'row rip'; r.tabIndex = 0; r.setAttribute('role', 'button'); r.style.setProperty('--i', i);
        r.innerHTML = `<img class="cv" src="${esc(listCover(l.tracks) || makeCover(l.name))}" alt=""><div class="tx"><b>${esc(l.name)}</b><small>Lista · ${l.tracks.length} ${l.tracks.length === 1 ? 'canción' : 'canciones'}</small></div><button class="more" aria-label="Más"><svg class="ic"><use href="#i-dots"/></svg></button>`;
        r.onclick = (e) => { if (e.target.closest('.more')) { e.stopPropagation(); return listMenu(l); } haptic(6); openColl({ title: l.name, sub: l.tracks.length + ' canciones', tracks: l.tracks, cover: listCover(l.tracks), key: 'list:' + l.id }); };
        box.append(r);
      });
    } else if (f === 'lists') box.insertAdjacentHTML('beforeend', '<p class="empty-t">Aún no tienes listas. Crea una o añade canciones desde el menú ⋯.</p>');
  }
  const showTracks = (list, empty, o) => { if (!list.length) box.insertAdjacentHTML('beforeend', `<p class="empty-t">${empty}</p>`); else { const l = document.createElement('div'); l.className = 'list'; l.style.padding = '0'; box.append(l); fillList(l, list, o); } };
  if (f === 'likes') showTracks(LIKES, 'Toca el corazón en una canción y aparecerá aquí.', { remove: null });
  if (f === 'dl') showTracks(dls, 'Todavía no descargaste nada. Usa el botón Descargar del reproductor.', {});
  if (f === 'device') paintDevice(box);
  if (f === 'mine') showTracks(LIB, 'Añade música de tu teléfono con el botón +.', {});
  if (f === 'all' && !LIKES.length && !LISTS.length && !dls.length && !LIB.length) box.insertAdjacentHTML('beforeend', '<p class="empty-t">Tu biblioteca está vacía. Dale me gusta a canciones, descarga música libre o añade archivos de tu teléfono.</p>');
}
// música del teléfono: escanear, filtrar y tocar (se muestran por tandas para que no se trabe con miles de canciones)
let devQ = '', devShow = 150;
function paintDevice(box) {
  const head = document.createElement('div'); head.className = 'dl-row';
  head.innerHTML = `<div class="tx"><b>Música del teléfono</b><small>${DEV.length ? DEV.length + ' canciones' : 'Aún no se ha escaneado'}</small></div><button class="pill glass" id="devScanBtn" data-act="scan-device">${DEV.length ? 'Escanear de nuevo' : 'Escanear ahora'}</button>`;
  box.append(head);
  if (!devCanScan()) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">El escaneo funciona en la app de Android.</p>'); return; }
  if (!DEV.length) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">Toca «Escanear ahora» y dame permiso para encontrar la música guardada en tu teléfono.</p>'); return; }
  const f = document.createElement('label'); f.className = 'search glass'; f.innerHTML = '<svg class="ic s"><use href="#i-search"/></svg><input type="search" placeholder="Filtrar en tu teléfono" autocomplete="off" autocapitalize="off">';
  const inp = f.querySelector('input'); inp.value = devQ; box.append(f);
  const act = document.createElement('div'); act.className = 'row-btns'; act.style.margin = '4px 0 10px';
  const mk = (t, fn) => { const b = document.createElement('button'); b.className = 'pill glass'; b.textContent = t; b.onclick = fn; return b; };
  const list = document.createElement('div'); list.className = 'list'; list.style.padding = '0';
  const draw = () => {
    const n = normTxt(devQ), all = devTracks().filter((t) => !n || normTxt(t.title + ' ' + t.artist + ' ' + t.album).includes(n));
    list.innerHTML = ''; const part = all.slice(0, devShow); fillList(list, part, {});
    if (all.length > part.length) { const m = mk(`Mostrar más (${all.length - part.length})`, () => { devShow += 200; draw(); }); m.style.margin = '10px auto'; m.style.display = 'block'; list.append(m); }
    if (!all.length) list.innerHTML = '<p class="empty-t">Nada con ese nombre.</p>';
    act.innerHTML = ''; if (all.length) { act.append(mk('Reproducir todo', () => play(all, 0)), mk('Aleatorio', () => { const c = CFG.shuffle; CFG.shuffle = true; play(all, Math.floor(Math.random() * all.length)); CFG.shuffle = c; })); }
  };
  inp.addEventListener('input', () => { devQ = inp.value; devShow = 150; draw(); });
  box.append(act, list); draw();
}
function listMenu(l) {
  openMenu({ title: l.name, sub: l.tracks.length + ' canciones', cover: listCover(l.tracks) }, [
    { icon: 'plus', label: 'Cambiar nombre', run: () => askText('Cambiar nombre', 'Nombre', l.name, (n) => { l.name = n; saveLists(); refreshLibViews(); }) },
    { icon: 'trash', label: 'Eliminar lista', run: () => { LISTS = LISTS.filter((x) => x !== l); saveLists(); refreshLibViews(); toast('Lista eliminada'); } },
  ]);
}
function syncLibChips() { $('libChips').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.f === libFilter)); }
$('libChips').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; libFilter = b.dataset.f; syncLibChips(); haptic(5); renderLib(); });
function refreshLibViews() { renderLib(); refreshHome(); if ($('coll').classList.contains('open') && COLL.key) rebuildColl(); }

/* ---------- Buscar ---------- */
let recentQ = store.get('sf_qs', []);
function renderCats() {
  const box = $('cats'); box.innerHTML = '';
  GENRES.forEach((n) => { const b = document.createElement('button'); b.className = 'cat'; b.style.background = grad('c' + n); b.textContent = n; b.onclick = () => { haptic(6); $('q').value = n; search(n); }; box.append(b); });
}
function renderRecentQ() {
  $('shRecentQ').hidden = !recentQ.length; const box = $('recentQ'); box.innerHTML = '';
  recentQ.forEach((q) => { const b = document.createElement('button'); b.textContent = q; b.onclick = () => { $('q').value = q; search(q); }; box.append(b); });
}
function renderKinds() { $('kinds').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.kind === CFG.kind)); }
$('kinds').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; CFG.kind = b.dataset.kind; saveCfg(); renderKinds(); haptic(5); if (S.lastQ) search(S.lastQ); });
$('searchForm').addEventListener('submit', (e) => { e.preventDefault(); $('q').blur(); search($('q').value.trim()); });
$('q').addEventListener('input', () => { const has = !!$('q').value; $('qClear').hidden = !has; if (!has) showSearchHome(); });
$('qClear').onclick = () => { $('q').value = ''; $('qClear').hidden = true; showSearchHome(); $('q').focus(); };
function showSearchHome() { S.lastQ = ''; $('searchHome').hidden = false; $('searchRes').hidden = true; }
let searchTok = 0;
const SRC_LABEL = { yt: 'YouTube Music', yd: 'YouTube (API)', sp: 'Spotify', am: 'Apple Music', dz: 'Deezer', sc: 'SoundCloud', jm: 'Jamendo', ia: 'Internet Archive' };
const SRC_ORDER = ['sp', 'am', 'dz', 'yt', 'yd', 'jm', 'ia', 'sc'];
function srcAvail() {
  const ap = store.get('ondas_apple', {});
  return { yt: true, sp: spOn(), am: !!window.ClientAPI, dz: !!window.ClientAPI, yd: !!(window.ClientAPI && CFG.ytKey), sc: !!(window.ClientAPI && CFG.scId), jm: !!(window.ClientAPI && store.get('sf_jkey', '')), ia: !!window.ClientAPI, _ap: ap };
}
async function iaTracks(q) {
  const d = await apiGet('ia', { q, free: '1' }), albums = (d.results || []).slice(0, 2);
  const parts = await Promise.allSettled(albums.map((a) => apiGet('iafiles', { id: a.id })));
  return parts.flatMap((p) => (p.status === 'fulfilled' ? p.value.tracks || [] : [])).slice(0, 14);
}
async function search(q) {
  if (!q) return;
  clearTimeout(SUG.t); SUG.tok++; $('sugg').hidden = true; S.lastQ = q; showArtistHit(q); $('qClear').hidden = false; $('searchHome').hidden = true; $('searchRes').hidden = false; renderKinds();
  if (NAV.tab !== 'search') goTab('search', { silent: true });
  recentQ = [q, ...recentQ.filter((x) => x !== q)].slice(0, 10); store.set('sf_qs', recentQ); renderRecentQ();
  $('list').innerHTML = skel(5); $('searchScroll').scrollTo({ top: 0 });
  renderSrcs();
  runSearch(q, CFG.kind === 'videos' ? 'yt' : (CFG.src || 'both'), true);
}
/* todas las fuentes a la vez: cada una pinta sus resultados en cuanto llega; si la elegida no tiene nada, se busca en las demás */
function runSearch(q, sel, canFallback) {
  const my = ++searchTok, kind = CFG.kind, av = srcAvail(), ap = av._ap;
  const ids = (sel === 'both' ? Object.keys(SRC_LABEL) : [sel]).filter((k) => av[k]); if (!ids.length) ids.push('yt');
  const job = {
    yt: () => apiGet('search', { q, type: kind }), sp: () => spSearchTracks(q), dz: () => apiGet('deezer', { q }), sc: () => apiGet('sc', { q, cid: CFG.scId }),
    am: () => (ap.dev ? apiGet('amapi', { q, dev: ap.dev, sf: ap.storefront || 'us' }).catch(() => apiGet('itunes', { q })) : apiGet('itunes', { q })),
    yd: () => apiGet('ytapi', { q, key: CFG.ytKey }), jm: () => apiGet('jamendo', { q, key: store.get('sf_jkey', '') }), ia: () => iaTracks(q),
  };
  const lists = {}, failed = []; let pending = ids.length, lastErr = null;
  const paint = () => {
    const order = SRC_ORDER.filter((k) => lists[k] && lists[k].length);
    let res = order.length === 1 ? lists[order[0]] : mergeMany(order.map((k) => lists[k]));
    res = rankOfficial(res); if (typeof devMatches === 'function' && kind !== 'videos') res = [...devMatches(q), ...res];
    S.results = res; if (res.length) renderList();
  };
  ids.forEach((k) => job[k]().then((r) => { lists[k] = Array.isArray(r) ? r : (r.results || []); }).catch((e) => { failed.push(k); lastErr = e; lists[k] = []; }).finally(() => {
    if (my !== searchTok) return; pending--;
    if (lists[k] && lists[k].length) paint();
    if (pending) return;
    const total = Object.values(lists).reduce((n, l) => n + l.length, 0);
    if (!total) {
      if (canFallback && sel !== 'both') { toast('No la encontré en ' + (SRC_LABEL[sel] || 'ese proveedor') + '. Busco en los demás…'); return runSearch(q, 'both', false); }
      $('list').innerHTML = failed.length === ids.length
        ? `<p class="empty-t">${navigator.onLine === false ? 'Sin conexión. Solo puedes oír tu música descargada y la del teléfono.' : 'No pude buscar: ' + esc((lastErr && lastErr.message) || 'error de conexión')}</p>`
        : '<p class="empty-t">Sin resultados. Prueba con otro nombre.</p>';
      return;
    }
    const bad = failed.filter((x) => x !== 'yt'); if (bad.length && sel !== 'both') toast('No respondió: ' + bad.map((x) => SRC_LABEL[x]).join(', '));
  }));
}
function renderList() {
  if (!S.results.length) { $('list').innerHTML = '<p class="empty-t">Sin resultados. Prueba con otro nombre.</p>'; return; }
  fillList($('list'), S.results, { radio: false });
}

/* ---------- página de álbum, lista o artista ---------- */
const COLL = { stack: [], cur: null, key: null };
function openColl(c) {
  if ($('coll').classList.contains('open') && COLL.cur) COLL.stack.push(COLL.cur);
  COLL.cur = c; COLL.key = c.key || null; paintColl(c);
  openSheet('coll'); $('collBody').scrollTop = 0;
  if (c.id) loadCollRemote(c);
}
function closeColl() { if (COLL.stack.length) { COLL.cur = COLL.stack.pop(); COLL.key = COLL.cur.key || null; paintColl(COLL.cur); return; } COLL.cur = null; closeSheet('coll'); }
// perfil de artista: foto a pantalla completa que se difumina hacia el negro, con el nombre encima
function heroArt(c) {
  const h = document.querySelector('#collBody .coll-hero'), bg = $('collBg'), on = !!c.isArtist && !!c.cover;
  h.classList.toggle('art', on);
  bg.style.backgroundImage = c.cover && !c.cover.startsWith('data:image/svg') ? `url("${String(c.cover).replace(/"/g, '%22')}")` : '';
}
function paintColl(c) {
  $('collTitle').textContent = c.title || ''; $('collSub').textContent = c.sub || '';
  if (c.isArtist) { styleArtist($('collTitle'), c.title); $('collTitle').style.fontSize = '34px'; } else { clearArtistStyle($('collTitle')); $('collTitle').style.fontSize = ''; }
  const cov = $('collCover'); cov.src = c.cover || makeCover(c.title || ''); cov.style.display = ''; cov.classList.toggle('round', !!c.isArtist);
  heroArt(c);
  $('collBg').style.setProperty('--c1', `hsl(${hue(c.title || '')} 55% 38%)`); $('coll').style.setProperty('--c1', `hsl(${hue(c.title || '')} 55% 38%)`);
  document.querySelectorAll('#collBody .coll-more-rails').forEach((n) => n.remove());
  if (c.loading || (c.id && !c.tracks)) $('collList').innerHTML = skel(6); else fillCollTracks(c);
  $('collMore').hidden = !c.key || !c.key.startsWith('list:');
  $('collAdd').hidden = !c.key || !c.key.startsWith('list:');
}
function fillCollTracks(c) {
  COLL.cur = Object.assign(COLL.cur || {}, c); const tracks = c.tracks || [];
  $('collTitle').textContent = c.title || ''; $('collSub').textContent = c.sub ? c.sub : tracks.length + ' canciones';
  if (c.cover) $('collCover').src = c.cover;
  heroArt(c);
  const isList = c.key && c.key.startsWith('list:'), lst = isList && LISTS.find((l) => 'list:' + l.id === c.key);
  const box = $('collList'); box.innerHTML = '';
  if (!tracks.length) { box.innerHTML = `<p class="empty-t">No hay canciones todavía.</p>${lst ? '<div class="empty-add"><button class="pill" data-act="coll-add">+ Añadir música</button></div>' : ''}`; return; }
  tracks.forEach((t, i) => box.append(trackRow(t, tracks, i, { noAlbum: !!c.id && !c.sections, remove: lst ? () => { lst.tracks = lst.tracks.filter((x) => tid(x) !== tid(t)); saveLists(); refreshLibViews(); } : c.key === 'likes' ? () => toggleLike(t) : null, removeLabel: c.key === 'likes' ? 'Quitar de Me gusta' : undefined })));
}
function rebuildColl() {
  const c = COLL.cur; if (!c) return;
  if (c.key === 'likes') c.tracks = LIKES; else if (c.key === 'dl') c.tracks = dlTracksSafe(); else if (c.key === 'mine') c.tracks = LIB;
  else if (c.key && c.key.startsWith('list:')) { const l = LISTS.find((x) => 'list:' + x.id === c.key); if (l) { c.tracks = l.tracks; c.title = l.name; } else return closeColl(); }
  fillCollTracks(c);
}
async function loadCollRemote(c) {
  try {
    const d = await apiGet('collection', { id: c.id });
    if (COLL.cur !== c) return;
    c.tracks = d.tracks; c.sections = d.sections; if (!c.cover && d.cover) c.cover = d.cover;
    fillCollTracks({ title: d.title || c.title, sub: c.sub || d.sub, cover: c.cover || d.cover, tracks: d.tracks, sections: d.sections });
    if (d.sections && d.sections.length) {
      const wrap = document.createElement('div'); wrap.className = 'coll-more-rails'; $('collBody').append(wrap);
      shelfHTML(wrap, d.sections, 5);
    }
  } catch (e) { $('collList').innerHTML = `<p class="empty-t">No pude abrir esta página (${esc(e.message)}).</p>`; }
}
function collTracks() { return (COLL.cur && COLL.cur.tracks) || []; }

/* ---------- cola ---------- */
function renderQueue() {
  const box = $('queList'); if (!box || $('que').hidden) return;
  box.innerHTML = '';
  S.queue.forEach((t, i) => {
    const r = trackRow(t, S.queue, i, { noAlbum: true });
    r.onclick = (e) => { if (e.target.closest('.more')) { e.stopPropagation(); return trackMenu(t, { remove: () => { S.queue.splice(i, 1); if (i < S.i) S.i--; renderQueue(); } }); } haptic(6); load(i); renderQueue(); };
    box.append(r);
  });
  const cur = box.querySelector('.cur'); if (cur) cur.scrollIntoView({ block: 'center' });
}
function openQueue() { openSheet('que'); renderQueue(); }

/* ---------- acciones de esta parte ---------- */
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  switch (b.dataset.act) {
    case 'close-coll': closeColl(); break;
    case 'coll-add': { const c = COLL.cur, l = c && LISTS.find((x) => 'list:' + x.id === c.key); if (l) openAddMusic(l); break; }
    case 'add-close': closeSheet('addm'); break;
    case 'mix-toggle': openMix(); break;
    case 'coll-play': { const l = collTracks(); if (l.length) { haptic(10); play(l, 0); } break; }
    case 'coll-shuffle': { const l = collTracks().slice(); if (l.length) { for (let i = l.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [l[i], l[j]] = [l[j], l[i]]; } haptic(10); play(l, 0); } break; }
    case 'coll-more': { const c = COLL.cur, l = c && LISTS.find((x) => 'list:' + x.id === c.key); if (l) listMenu(l); break; }
    case 'open-queue': openQueue(); break; case 'close-queue': closeSheet('que'); break;
    case 'news-refresh': loadNews(true); break;
    case 'lib-add': openMenu({ title: 'Añadir', sub: 'A tu biblioteca' }, [
      { icon: 'note', label: 'Música del teléfono', run: () => $('fileAudio').click() },
      { icon: 'dl', label: 'Descargar música libre', run: () => openDownloads('') },
      { icon: 'plus', label: 'Nueva lista', run: () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { newList(n); toast('Lista creada'); }) },
    ]); break;
    case 'like': toggleLike(S.queue[S.i]); break;
    case 'track-menu': { const t = S.queue[S.i]; if (t) trackMenu(t, { np: true }); break; }
    case 'clear-q': recentQ = []; store.set('sf_qs', recentQ); renderRecentQ(); break;
  }
});

function onTabShow(name) {
  if (name === 'news') loadNews(); else if (name === 'radio') paintRadioNow(); else if (name === 'lib') renderLib(); else if (name === 'home') refreshHome();
}
function initViews() {
  initArtists(); initRadio(); renderCats(); renderRecentQ(); renderKinds(); refreshHome(); renderLib(); paintLike();
  $('tabbar').style.setProperty('--i', 0);
  loadHome();
}
// compatibilidad con el resto del código
const renderRecent = refreshHome;
document.addEventListener('error', (e) => { const im = e.target; if (im.tagName === 'IMG' && !im._fb && !/^data:/.test(im.src)) { im._fb = 1; im.src = makeCover(im.alt || im.src); im.classList.add('ld'); } }, true);

/* ---------- añadir música a una lista ---------- */
let ADD = { l: null, tok: 0, t: 0 };
function addRow(t) {
  const l = ADD.l, has = () => l.tracks.some((x) => tid(x) === tid(t));
  const r = document.createElement('div'); r.className = 'row add-row';
  r.innerHTML = `<img class="cv" src="${esc(t.cover || makeCover(t.title + t.artist))}" alt="" loading="lazy"><div class="tx"><b>${esc(t.title)}</b><small>${esc(t.artist || '')}${t.album ? ' · ' + esc(t.album) : ''}</small></div><button class="addbtn" aria-label="Añadir"></button>`;
  const btn = r.querySelector('.addbtn'), paint = () => { btn.innerHTML = `<svg class="ic s"><use href="#i-${has() ? 'check' : 'plus'}"/></svg>`; btn.classList.toggle('on', has()); };
  paint();
  r.onclick = () => { if (!has()) { l.tracks.push(slim(t)); saveLists(); refreshLibViews(); if (typeof rebuildColl === 'function') rebuildColl(); haptic(8); } paint(); };
  return r;
}
function fillAdd(list, head) { $('addH').textContent = head; $('addH').hidden = !head; const box = $('addList'); box.innerHTML = ''; if (!list.length) { box.innerHTML = '<p class="empty-t">Sin resultados.</p>'; return; } list.forEach((t) => box.append(addRow(t))); }
function addBase() { const seen = new Set(), out = []; [...LIKES, ...(typeof LIB !== 'undefined' ? LIB : []), ...recents()].forEach((t) => { const k = tid(t); if (!seen.has(k)) { seen.add(k); out.push(t); } }); return out; }
function openAddMusic(l) {
  ADD.l = l; $('addTitle').textContent = 'Añadir a «' + l.name + '»'; $('addQ').value = '';
  const base = addBase().filter((t) => !l.tracks.some((x) => tid(x) === tid(t))).slice(0, 40);
  fillAdd(base, base.length ? 'Tus Me gusta y recientes' : ''); if (!base.length) $('addList').innerHTML = '<p class="empty-t">Escribe arriba el nombre de una canción o artista.</p>';
  openSheet('addm');
}
$('addForm').addEventListener('submit', (e) => { e.preventDefault(); $('addQ').blur(); });
$('addQ').addEventListener('input', () => {
  clearTimeout(ADD.t); const q = $('addQ').value.trim(), my = ++ADD.tok;
  if (!q) return openAddMusic(ADD.l);
  const lc = q.toLowerCase(), loc = addBase().filter((t) => (t.title + ' ' + t.artist).toLowerCase().includes(lc)).slice(0, 6);
  fillAdd(loc, loc.length ? 'En tu música' : '');
  ADD.t = setTimeout(async () => {
    try { const d = await apiGet('search', { q, type: 'songs' }); if (my !== ADD.tok) return; const have = new Set(loc.map(tid)); fillAdd([...loc, ...(d.results || []).filter((t) => !have.has(tid(t)))].slice(0, 30), 'Resultados'); }
    catch { if (my === ADD.tok && !loc.length) $('addList').innerHTML = '<p class="empty-t">No pude buscar ahora.</p>'; }
  }, 280);
});

/* ---------- sugerencias al escribir en el buscador ---------- */
let SUG = { t: 0, tok: 0, cache: {} };
function boldRest(s, q) { const i = s.toLowerCase().startsWith(q.toLowerCase()) ? q.length : 0; return `${esc(s.slice(0, i))}<b>${esc(s.slice(i))}</b>`; }
$('q').addEventListener('input', () => {
  clearTimeout(SUG.t); const q = $('q').value.trim(), my = ++SUG.tok;
  if (!q) { $('sugg').hidden = true; return; }
  SUG.t = setTimeout(async () => {
    $('searchHome').hidden = true; $('searchRes').hidden = true; $('sugg').hidden = false;
    const paintList = (arr) => { if (my !== SUG.tok) return; const lc = q.toLowerCase(), items = [q, ...arr.filter((x) => x.toLowerCase() !== lc)].slice(0, 7);
      $('suggList').innerHTML = items.map((s) => `<button class="sug" data-q="${esc(s)}"><svg class="ic s"><use href="#i-search"/></svg><span>${boldRest(s, q)}</span></button>`).join(''); };
    paintList(SUG.cache[q] || []);
    apiGet('suggest', { q }).then((d) => { SUG.cache[q] = d.list || []; paintList(SUG.cache[q]); }).catch(() => {});
    apiGet('search', { q, type: 'songs' }).then((d) => {
      if (my !== SUG.tok) return; const list = (d.results || []).slice(0, 4); $('suggH').hidden = !list.length;
      const box = $('suggSongs'); box.innerHTML = ''; list.forEach((t, i) => box.append(trackRow(t, list, i, { noAlbum: false })));
    }).catch(() => {});
  }, 170);
});
$('suggList').addEventListener('click', (e) => { const b = e.target.closest('.sug'); if (!b) return; $('q').value = b.dataset.q; haptic(5); search(b.dataset.q); });
