'use strict';
/* ===== Artistas: foto y tipografía propia para cada uno ===== */
const FONT_POOL = ['Bebas Neue', 'Anton', 'Permanent Marker', 'Pacifico', 'Playfair Display', 'Orbitron', 'Righteous', 'Rock Salt', 'Abril Fatface', 'Dancing Script', 'Special Elite', 'Cinzel', 'Bungee', 'Fredoka', 'Lobster', 'Bangers', 'Rye'];
// elegidas a mano para los más conocidos; el resto recibe una según su nombre (siempre la misma)
const ARTIST_FONTS = {
  'bad bunny': 'Bungee', 'karol g': 'Pacifico', 'rosalia': 'Playfair Display', 'the weeknd': 'Orbitron', 'dua lipa': 'Abril Fatface',
  'taylor swift': 'Dancing Script', 'peso pluma': 'Rye', 'shakira': 'Righteous', 'feid': 'Bebas Neue', 'billie eilish': 'Special Elite',
  'drake': 'Anton', 'kendrick lamar': 'Permanent Marker', 'eminem': 'Permanent Marker', 'travis scott': 'Cinzel', 'bts': 'Fredoka',
  'blackpink': 'Fredoka', 'metallica': 'Rock Salt', 'daft punk': 'Orbitron', 'queen': 'Playfair Display', 'ed sheeran': 'Dancing Script',
  'ariana grande': 'Pacifico', 'post malone': 'Rye', 'j balvin': 'Bangers', 'daddy yankee': 'Anton', 'maluma': 'Bebas Neue',
  'anuel aa': 'Cinzel', 'rauw alejandro': 'Orbitron', 'myke towers': 'Bebas Neue', 'ozuna': 'Bungee', 'lana del rey': 'Playfair Display',
  'olivia rodrigo': 'Lobster', 'harry styles': 'Pacifico', 'bruno mars': 'Righteous', 'coldplay': 'Fredoka', 'nirvana': 'Rock Salt',
  'guns n roses': 'Rock Salt', 'juanes': 'Lobster', 'carlos vives': 'Lobster', 'maná': 'Rye', 'mana': 'Rye', 'grupo frontera': 'Rye',
  'junior h': 'Rye', 'natanael cano': 'Rye', 'eslabon armado': 'Rye', 'fuerza regida': 'Rye', 'quevedo': 'Bebas Neue', 'bizarrap': 'Bangers',
};
const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
// "Bad Bunny, Jhay Cortez" -> "Bad Bunny"
const mainArtist = (s) => String(s || '').split(/\s*(?:,|&|\bfeat\.?\s|\bft\.?\s|\sx\s)\s*/i)[0].trim();
function fontFor(name) {
  const k = norm(mainArtist(name)); if (!k) return '';
  const f = ARTIST_FONTS[k] || FONT_POOL[hue(k) % FONT_POOL.length];
  return `"${f}", Inter, sans-serif`;
}
function afont(el, name) {
  if (!el) return;
  const f = fontFor(name);
  if (f) { el.style.fontFamily = f; el.classList.add('afont'); } else { el.style.fontFamily = ''; el.classList.remove('afont'); }
}

/* ---------- fotos (se buscan una vez y se guardan en el teléfono) ---------- */
const PICS = store.get('sf_artpics2', {});         // nombre normalizado -> {name, picture, fans} | 0 (no encontrado)
const picQ = {}, picWait = []; let picActive = 0, picSave = 0;
function picNext() {
  while (picActive < 3 && picWait.length) { const job = picWait.shift(); picActive++; job().finally(() => { picActive--; picNext(); }); }
}
// devuelve {name, picture, fans} o null; las respuestas se guardan para no repetir la búsqueda
function artistInfo(name) {
  const main = mainArtist(name), k = norm(main);
  if (!k || !CFG.artists || !window.ClientAPI) return Promise.resolve(null);
  if (PICS[k] !== undefined) return Promise.resolve(PICS[k] || null);
  if (picQ[k]) return picQ[k];
  return (picQ[k] = new Promise((resolve) => {
    picWait.push(async () => {
      try {
        const d = await apiGet('artist', { name: main });
        PICS[k] = d && d.picture ? { name: d.name || main, picture: d.picture, fans: d.fans || 0 } : 0;
        clearTimeout(picSave); picSave = setTimeout(() => { const keys = Object.keys(PICS); if (keys.length > 400) keys.slice(0, keys.length - 400).forEach((x) => delete PICS[x]); store.set('sf_artpics2', PICS); }, 1500);
        resolve(PICS[k] || null);
      } catch { delete picQ[k]; resolve(null); }
    });
    picNext();
  }));
}
function styleArtist(el, name) { afont(el, name); }
function clearArtistStyle(el) { if (!el) return; el.style.fontFamily = ''; el.classList.remove('afont'); }

// artista de la canción que suena: nombre con su tipografía y foto redonda
function paintArtist(t) {
  const span = $('bigA'), av = $('artAv'), name = t.artist || '';
  span.textContent = name; styleArtist(span, name); $('lyrA').textContent = name; styleArtist($('lyrA'), name);
  const k = norm(mainArtist(name)); av.dataset.k = k; av.hidden = true; av.classList.remove('ld'); av.removeAttribute('src');
  if (!k) return;
  artistInfo(name).then((i) => { if (av.dataset.k === k && i && i.picture) { av.hidden = false; av.src = i.picture; } });
}
// tarjeta redonda de artista: tipografía propia y foto cuando llega
function decorateArtistCard(c, name) {
  styleArtist(c.querySelector('b'), name);
  artistInfo(name).then((i) => { if (i && i.picture) { const im = c.querySelector('.im'); im.style.background = '#222'; im.innerHTML = `<img src="${esc(i.picture)}" alt="" loading="lazy">`; } });
}
// tarjeta grande arriba de los resultados cuando lo buscado es un artista
function showArtistHit(q) {
  const b = $('artistHit'); b.hidden = true; b.dataset.q = q;
  artistInfo(q).then((i) => {
    if (b.dataset.q !== q || !i) return;
    const a = norm(i.name), z = norm(q); if (!a || !(a === z || a.includes(z) || z.includes(a))) return;
    b.innerHTML = `<img class="av" src="${esc(i.picture)}" alt=""><div><b>${esc(i.name)}</b><small>Artista${i.fans ? ' · ' + Number(i.fans).toLocaleString('es') + ' seguidores' : ''}</small></div><svg class="ic s"><use href="#i-chev"/></svg>`;
    styleArtist(b.querySelector('b'), i.name); b.style.fontSize = ''; b.onclick = () => openArtist(i.name); b.hidden = false;
  });
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act="open-artist"]'); if (!b) return;
  const t = S.queue[S.i]; if (!t || !t.artist) return;
  closeNP(); openArtist(mainArtist(t.artist));
});
// la foto del artista ya cargó: se muestra con un fundido
document.addEventListener('load', (e) => { if (e.target.id === 'artAv') e.target.classList.add('ld'); }, true);
