'use strict';
/* ===== Navegación: pestañas inferiores, hojas, atrás y gesto para cerrar el reproductor ===== */
const NAV = { tab: 'home', order: ['home', 'news', 'radio', 'lib', 'search'], scroll: {}, inited: {} };
const SH = [];                                   // pila de hojas abiertas

function goTab(name, opts = {}) {
  if (!NAV.order.includes(name)) return;
  const prev = NAV.tab, cur = $('v-' + name);
  if (name === prev && !opts.force) {                       // tocar la pestaña activa sube al inicio
    const sc = cur.querySelector('.vscroll'); if (sc) sc.scrollTo({ top: 0, behavior: 'smooth' });
    if (name === 'search') { const q = $('q'); if (q) q.focus(); }
    return;
  }
  const dir = NAV.order.indexOf(name) > NAV.order.indexOf(prev) ? 1 : -1;
  $('v-' + prev).style.setProperty('--dir', dir); cur.style.setProperty('--dir', dir);
  const old = $('v-' + prev), oldSc = old.querySelector('.vscroll');
  NAV.scroll[prev] = oldSc ? oldSc.scrollTop : 0;
  old.classList.remove('on'); old.classList.add('out');
  setTimeout(() => old.classList.remove('out'), 230);
  cur.hidden = false; cur.classList.add('on');
  const sc = cur.querySelector('.vscroll'); if (sc) sc.scrollTop = NAV.scroll[name] || 0;
  NAV.tab = name;
  document.querySelectorAll('.tab').forEach((b) => { const on = b.dataset.tab === name; b.classList.toggle('on', on); on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current'); });
  $('tabbar').style.setProperty('--i', NAV.order.indexOf(name));
  $('tint').style.opacity = name === 'home' ? '.9' : name === 'search' ? '.35' : '.6';
  if (!opts.silent) haptic(6);
  if (typeof onTabShow === 'function') onTabShow(name);
}
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-tab]'); if (t && t.classList.contains('tab')) return goTab(t.dataset.tab);
  const g = e.target.closest('[data-go]'); if (g) goTab(g.dataset.go);
});

/* ---------- hojas ---------- */
function openSheet(id) {
  const s = $(id); if (!s || s.classList.contains('open')) return;
  s.hidden = false; void s.offsetWidth; s.classList.add('open'); SH.push(id);
  document.body.classList.add('set-open'); haptic(6);
}
function closeSheet(id) {
  const s = $(id); if (!s || !s.classList.contains('open')) return;
  s.classList.remove('open');
  const i = SH.lastIndexOf(id); if (i >= 0) SH.splice(i, 1);
  if (!SH.length) document.body.classList.remove('set-open');
  setTimeout(() => { if (!s.classList.contains('open')) s.hidden = true; }, 640);
}
// tocar el fondo oscuro cierra la hoja
document.addEventListener('click', (e) => {
  const s = e.target.classList && e.target.classList.contains('sheet') ? e.target : null;
  if (s && s.id !== 'coll') closeSheet(s.id);
});

/* ---------- menú contextual ---------- */
function openMenu(head, items) {
  const wrap = $('menu');
  $('menuHead').innerHTML = head ? `${head.cover ? `<img src="${esc(head.cover)}" alt="">` : ''}<div><b>${esc(head.title || '')}</b><small>${esc(head.sub || '')}</small></div>` : '';
  const box = $('menuItems'); box.innerHTML = '';
  items.filter(Boolean).forEach((it) => {
    const b = document.createElement('button'); b.setAttribute('role', 'menuitem');
    b.innerHTML = `<svg class="ic s"><use href="#i-${it.icon || 'note'}"/></svg><span>${esc(it.label)}</span>`;
    b.onclick = () => { if (!it.keep) closeMenu(); it.run(); };
    box.append(b);
  });
  wrap.hidden = false;
}
function closeMenu() { $('menu').hidden = true; }

/* ---------- botón atrás de Android ---------- */
window.__back = () => {
  if (!$('cfg').hidden) { $('cfg').hidden = true; return true; }
  if (!$('menu').hidden) { closeMenu(); return true; }
  if (SH.length) { const id = SH[SH.length - 1]; if (id === 'coll') closeColl(); else closeSheet(id); return true; }
  if (S.lyrOpen) { closeLyr(); return true; }
  if (S.npOpen) { closeNP(); return true; }
  if (NAV.tab !== 'home') { goTab('home'); return true; }
  return false;
};

/* ---------- teclado: oculta la barra inferior mientras se escribe ---------- */
if (window.visualViewport) {
  const base = window.innerHeight;
  visualViewport.addEventListener('resize', () => document.body.classList.toggle('kb', visualViewport.height < base * 0.75));
}

/* ---------- gesto: arrastrar hacia abajo para cerrar el reproductor ---------- */
(function dragToClose() {
  const np = $('np'); let y0 = 0, dy = 0, on = false, t0 = 0;
  const zone = (el) => el.closest('#npHead, #artwrap, .tbar') && !el.closest('button,input');
  np.addEventListener('pointerdown', (e) => {
    if (S.lyrOpen || !zone(e.target)) return;
    on = true; y0 = e.clientY; dy = 0; t0 = performance.now(); np.classList.add('drag'); np.setPointerCapture(e.pointerId);
  });
  np.addEventListener('pointermove', (e) => {
    if (!on) return;
    dy = Math.max(0, e.clientY - y0);
    np.style.setProperty('--dy', dy * 0.9 + 'px');
    np.style.transform = `translateY(${dy * 0.9}px) scale(${1 - Math.min(dy, 600) / 6000})`;
  });
  const end = () => {
    if (!on) return; on = false; np.classList.remove('drag');
    const v = dy / Math.max(1, performance.now() - t0);        // velocidad
    np.style.transform = ''; np.style.removeProperty('--dy');
    if (dy > 140 || v > 0.6 && dy > 40) closeNP();
  };
  np.addEventListener('pointerup', end); np.addEventListener('pointercancel', end);
})();
