'use strict';
/* ===== Ajustes nuevos: reproducción, apariencia, letras, datos y seguridad ===== */
function paintOut(el) {
  if (el.type !== 'range') return;
  const mn = +el.min, mx = +el.max, v = +el.value;
  el.style.setProperty('--p', ((v - mn) / (mx - mn) * 100) + '%');
  const o = document.querySelector(`[data-out="${el.dataset.cfg}"]`);
  if (o) o.textContent = (el.dataset.cfg === 'lyrOff' && v > 0 ? '+' : '') + v + (o.dataset.unit || '');
}

/* ---- pestañas visibles y pestaña de inicio ---- */
function applyTabs() {
  const show = { news: CFG.showNews !== false, radio: CFG.showRadio !== false };
  NAV.order = ['home', 'news', 'radio', 'lib'].filter((t) => show[t] !== false).concat('search');
  document.querySelectorAll('#tabbar .tab[data-tab]').forEach((b) => { const t = b.dataset.tab; b.hidden = t in show && !show[t]; });
  document.documentElement.style.setProperty('--nt', String(NAV.order.length - 1));
  if (!NAV.order.includes(NAV.tab)) goTab('home'); else $('tabbar').style.setProperty('--i', NAV.order.indexOf(NAV.tab));
}
function startTabNow() { const t = CFG.startTab || 'home'; return NAV.order.includes(t) ? t : 'home'; }

/* ---- tema, texto y letra ---- */
const lightMQ = window.matchMedia ? matchMedia('(prefers-color-scheme: light)') : { matches: false };
function applyMoreLook() {
  const th = CFG.theme || 'dark', light = th === 'light' || (th === 'auto' && lightMQ.matches);
  document.documentElement.classList.toggle('light', light);
  document.documentElement.style.setProperty('--tz', String((CFG.txt || 100) / 100));
  ['inter', 'serif', 'round', 'mono'].forEach((f) => document.body.classList.toggle('lf-' + f, (CFG.lyrFont || 'inter') === f));
  document.body.classList.toggle('data-saver', !!CFG.dataSaver);
  ['square', 'round', 'circle'].forEach((c) => document.body.classList.toggle('cv-' + c, (CFG.coverShape || 'square') === c));
  document.body.classList.toggle('hc', !!CFG.hc); document.body.classList.toggle('bold', !!CFG.bold); document.body.classList.toggle('calm', !!CFG.calm);
}
if (lightMQ.addEventListener) lightMQ.addEventListener('change', () => { if (CFG.theme === 'auto') applyMoreLook(); });

/* ---- traducción y pronunciación de la letra ---- */
const TRC = {};
const nonLatin = (s) => /[^\u0000-ɏ -⁯←-⇿\s\d]/.test(s);
const normTr = (s) => String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
async function addTranslations() {
  const L = S.lyrics; if (!L || !L.lines) return;
  document.querySelectorAll('#lbody .ln .tr').forEach((e) => e.remove());
  if ((!CFG.lyrTr && !CFG.lyrRom) || !window.ClientAPI) return;
  const idxs = []; L.lines.forEach((l, i) => { if (l.text && !l.dots && l._el) idxs.push(i); });
  const txt = (i) => L.lines[i].text.replace(/[()]/g, '');
  if (!CFG.lyrTr && !idxs.some((i) => nonLatin(txt(i)))) return;       // sin otro alfabeto no hay pronunciación que mostrar
  const key = (S.queue[S.i] ? tid(S.queue[S.i]) : '') + '|' + L.provider, tok = S.loadTok;
  let res = TRC[key];
  if (!res) { try { const d = await apiGet('translate', { lines: idxs.map(txt), to: 'es' }); res = TRC[key] = d.lines; } catch { return; } }
  if (S.loadTok !== tok || S.lyrics !== L || !res) return;
  idxs.forEach((i, k) => {
    const r = res[k], orig = txt(i); if (!r) return;
    const parts = [];
    if (CFG.lyrRom && r.r && nonLatin(orig)) parts.push(r.r);
    if (CFG.lyrTr && r.t && normTr(r.t) !== normTr(orig)) parts.push(r.t);
    if (!parts.length || !L.lines[i]._el) return;
    const el = document.createElement('small'); el.className = 'tr'; el.innerHTML = parts.map((p) => `<span>${esc(p)}</span>`).join('');
    L.lines[i]._el.append(el);
  });
}
const _renderLyrics = renderLyrics;
renderLyrics = function () { _renderLyrics(); try { addTranslations(); } catch {} };

/* ---- audífonos, Bluetooth y volumen ---- */
window.__noisy = () => { if (CFG.noisy !== false && S.playing) window.__media('pause'); };
window.__plug = () => { if (CFG.btPlay && performance.now() > 6000 && !S.playing && S.queue.length) window.__media('play'); };
let gapDone = -1;
setInterval(() => {                                                    // pasa a la siguiente justo al final, sin esperar al aviso de "terminó"
  if (!CFG.gapless || CFG.mixOn || !S.playing || S.seeking || !S.queue.length || CFG.repeat === 2) return;
  const d = E.dur(), c = E.time(); if (!d || d < 10) return;
  const hasNext = S.i < S.queue.length - 1 || CFG.repeat === 1 || !!S.radioSeed || !!CFG.autoRadio;
  if (hasNext && d - c > 0 && d - c <= 0.3 && gapDone !== S.loadTok) { gapDone = S.loadTok; next(); }
}, 100);

/* ---- bloqueo de la app con el bloqueo del teléfono ---- */
let lockBusy = false, hiddenAt = 0, pendingLock = false;
function askAuth() {
  lockBusy = true;
  if (window.Native && Native.authenticate) Native.authenticate(); else window.__auth(1);
}
function showLock() { if (!CFG.lock) return; $('lockScr').hidden = false; setTimeout(askAuth, 350); }
window.__auth = (r) => {
  lockBusy = false;
  const chk = document.querySelector('[data-cfg="lock"]');
  if (r === 1) { $('lockScr').hidden = true; if (pendingLock) { CFG.lock = true; saveCfg(); toast('Bloqueo activado'); } }
  else {
    if (r === 2) { toast('Primero pon un PIN, patrón o huella en tu teléfono'); $('lockScr').hidden = true; }
    if (pendingLock) { CFG.lock = false; saveCfg(); if (chk) chk.checked = false; }
  }
  pendingLock = false;
};
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { hiddenAt = Date.now(); return; }
  if (CFG.lock && !lockBusy && hiddenAt && Date.now() - hiddenAt > 60000 && $('lockScr').hidden) showLock();
});

/* ---- caché ---- */
async function coverCount() { try { return (await (await caches.open('sf-img-v1')).keys()).length; } catch { return 0; } }
function paintCacheSize() {
  let n = 0; ['sf_lyc', 'sf_home', 'sf_news', 'sf_vmap', 'sf_sph'].forEach((k) => { try { n += (localStorage.getItem(k) || '').length * 2; } catch {} });
  coverCount().then((c) => { const el = $('cacheSize'); if (!el) return; const a = n < 1024 ? 'Casi nada de letras y datos' : n < 1048576 ? Math.round(n / 1024) + ' KB de letras y datos' : (n / 1048576).toFixed(1) + ' MB de letras y datos'; el.textContent = a + (c ? ' · ' + c + ' portadas' : ''); });
}
setInterval(() => { if (document.body.classList.contains('set-open')) paintCacheSize(); }, 2500);

/* ---- enlazar los controles nuevos con CFG ---- */
function applyMore(key) {
  if (key === 'showNews' || key === 'showRadio') applyTabs();
  else if (key === 'lyrTr' || key === 'lyrRom') addTranslations();
  else if (key === 'volMax') { try { E.vol(outVol()); } catch {} }
  else applyMoreLook();
}
document.querySelectorAll('[data-cfg]').forEach((el) => {
  const key = el.dataset.cfg, sw = el.type === 'checkbox', rg = el.type === 'range';
  const dv = sw ? el.dataset.def === '1' : rg ? +el.dataset.def : el.dataset.def;
  const cur = CFG[key] === undefined ? dv : CFG[key];
  if (sw) el.checked = !!cur; else el.value = String(cur);
  paintOut(el);
  el.addEventListener(rg ? 'input' : 'change', () => {
    const v = sw ? el.checked : rg ? +el.value : el.value;
    paintOut(el);
    if (key === 'lock' && v) { pendingLock = true; askAuth(); return; }
    CFG[key] = v; saveCfg(); applyMore(key);
  });
});

/* ---- botones: restablecer, reportar, desbloquear ---- */
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act="reset-cfg"],[data-act="report-bug"],[data-act="unlock"]'); if (!b) return;
  if (b.dataset.act === 'unlock') return askAuth();
  if (b.dataset.act === 'reset-cfg') return confirmTap(b, () => { try { localStorage.removeItem('sf_cfg'); } catch {} location.reload(); });
  if (!CFG.repo) return toast('Escribe tu repositorio de GitHub en Acerca de, arriba');
  const info = `Versión: ${$('verB').textContent}\nTeléfono: ${(typeof DEVINFO === 'object' && (DEVINFO.model || DEVINFO.device)) || 'sin datos'}\nAndroid: ${(typeof DEVINFO === 'object' && DEVINFO.android) || 'sin datos'}\n\nQué pasó:\n`;
  const url = `https://github.com/${CFG.repo}/issues/new?title=${encodeURIComponent('Problema en Spotifree')}&body=${encodeURIComponent(info)}`;
  try { if (window.Native && Native.openUrl) Native.openUrl(url); else window.open(url, '_blank'); } catch {}
});

/* ---- arranque ---- */
fetch('version.json').then((r) => r.json()).then((d) => { $('verB').textContent = d.build ? String(d.build) : 'local'; }).catch(() => { $('verB').textContent = 'local'; });
applyMoreLook(); applyTabs(); paintCacheSize();
if (CFG.lock) { $('lockScr').hidden = false; setTimeout(askAuth, 700); }

/* WebView muy viejo (Android 7/8 sin actualizar): aviso una sola vez */
(function () {
  try {
    const m = /Chrome\/(\d+)/.exec(navigator.userAgent);
    if (m && +m[1] < 80 && !store.get('sf_oldwv', 0)) { store.set('sf_oldwv', 1); setTimeout(() => toast('Actualiza «Android System WebView» en Play Store para que la app vaya más fluida'), 3500); }
  } catch {}
})();
