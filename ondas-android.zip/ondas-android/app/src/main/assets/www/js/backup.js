'use strict';
/* ===== Copia de seguridad: exportar, importar y restaurar la copia automática =====
   Incluye ajustes, Me gusta, listas, historial y metadatos de descargas. NO incluye claves ni tokens
   (Spotify, Apple Music, Jamendo, YouTube, SoundCloud) ni los archivos de música descargados. */
const BK_SKIP = /^(sf_pkce|ondas_apple|sf_jkey|sf_acc|sf_backup|sf_tier2)/;
const BK_SECRET_CFG = ['scId', 'ytKey', 'amToken'];
function bkCollect() {
  const out = {};
  Object.keys(localStorage).forEach((k) => { if (/^(sf_|ondas_)/.test(k) && !BK_SKIP.test(k)) out[k] = localStorage.getItem(k); });
  try { const c = JSON.parse(out.sf_cfg || '{}'); BK_SECRET_CFG.forEach((f) => delete c[f]); out.sf_cfg = JSON.stringify(c); } catch {}
  return out;
}
function bkApply(data, merge) {
  const keep = {}; BK_SECRET_CFG.forEach((f) => { if (CFG[f]) keep[f] = CFG[f]; });
  Object.entries(data).forEach(([k, v]) => { if (/^(sf_|ondas_)/.test(k) && !BK_SKIP.test(k) && typeof v === 'string') { try { localStorage.setItem(k, v); } catch {} } });
  try { const c = JSON.parse(localStorage.getItem('sf_cfg') || '{}'); Object.assign(c, keep); localStorage.setItem('sf_cfg', JSON.stringify(c)); } catch {}
  toast('Datos restaurados. Reiniciando la app…'); setTimeout(() => location.reload(), 900);
}
function bkExport() {
  const name = 'spotifree-copia-' + new Date().toISOString().slice(0, 10) + '.json', text = JSON.stringify({ app: 'spotifree', v: 2, at: Date.now(), data: bkCollect() });
  if (window.Native && Native.saveFile) { const r = Native.saveFile(name, text); if (r && r !== 'error') return toast('Copia guardada en ' + r); toast('No pude guardar el archivo'); return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name; document.body.append(a); a.click(); a.remove(); toast('Copia descargada');
}
$('fileBackup').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try {
    const j = JSON.parse(await f.text()); if (j.app !== 'spotifree' || !j.data) throw new Error('No es una copia de Spotifree');
    askText('Restaurar copia', 'Escribe SI para reemplazar tus datos actuales', '', (v) => { if (/^s[ií]$/i.test(v.trim())) bkApply(j.data); else toast('No se restauró nada'); });
  } catch (err) { toast('Archivo no válido: ' + err.message); }
});
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  if (b.dataset.act === 'bk-export') bkExport();
  else if (b.dataset.act === 'bk-import') $('fileBackup').click();
  else if (b.dataset.act === 'bk-auto') {
    const s = store.get('sf_backup_v2', null); if (!s) return toast('No hay copia automática');
    askText('Restaurar copia automática', 'Escribe SI (' + new Date(s.at).toLocaleDateString() + ')', '', (v) => { if (/^s[ií]$/i.test(v.trim())) bkApply(s.data); else toast('No se restauró nada'); });
  }
});
