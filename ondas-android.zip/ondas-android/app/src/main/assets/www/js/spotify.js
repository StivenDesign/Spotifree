'use strict';
/* ===== Motor Spotify + YouTube Music =====
   Spotify pone el catálogo y tu cuenta (búsqueda, favoritas, lo más escuchado); el sonido sale de YouTube Music,
   emparejando cada canción por título, artista y duración. Spotify no deja reproducir su audio fuera de su app. */
const spOn = () => !!(ACC && ACC.sp && ACC.sp.refresh);
const spTrack = (t) => ({
  kind: 'song', sp: true, spId: t.id, title: t.name, artist: (t.artists || []).map((a) => a.name).join(', '),
  album: (t.album && t.album.name) || '', duration: Math.round((t.duration_ms || 0) / 1000),
  cover: (t.album && t.album.images && t.album.images[0] && t.album.images[0].url) || '',
});
async function spSearchTracks(q) {
  const d = await spGet('/search?' + new URLSearchParams({ q, type: 'track', limit: '25' }));
  return ((d.tracks && d.tracks.items) || []).filter(Boolean).map(spTrack);
}
/* mezcla YouTube Music y Spotify sin repetir canciones */
const spKey = (t) => normTxt(t.title) + '|' + normTxt(String(t.artist || '').split(/,|&/)[0]);
function mergeResults(yt, sp) {
  const seen = new Set(), out = [];
  const a = yt.slice(), b = sp.slice();
  while (a.length || b.length) {
    for (const src of [b, a]) {                      // primero Spotify: trae la portada y el álbum correctos
      const t = src.shift(); if (!t) continue;
      const k = spKey(t); if (seen.has(k)) continue; seen.add(k); out.push(t);
    }
  }
  return out;
}
/* junta varias fuentes: sin repetir, y si una canción del catálogo también está en YouTube Music se le pega su videoId (suena al instante y exacta) */
function mergeMany(lists) {
  const byKey = new Map(), out = [], q = lists.map((l) => l.slice());
  while (q.some((l) => l.length)) {
    for (const l of q) {
      const t = l.shift(); if (!t) continue;
      const k = spKey(t), ex = byKey.get(k);
      if (!ex) { byKey.set(k, t); out.push(t); }
      else if (!ex.videoId && t.videoId) { ex.videoId = t.videoId; if (!ex.duration) ex.duration = t.duration; }
    }
  }
  return out;
}
function normTxt(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim(); }

/* ---- inicio: lo tuyo en Spotify ---- */
let SPH = store.get('sf_sph', null), spHBusy = false;
async function loadSpHome(force) {
  if (!spOn() || spHBusy) return paintSpHome();
  if (SPH && Date.now() - SPH.t < 3600e3 && !force) return paintSpHome();
  spHBusy = true;
  try {
    const [top, saved] = await Promise.allSettled([spGet('/me/top/tracks?limit=20&time_range=short_term'), spGet('/me/tracks?limit=30')]);
    SPH = { t: Date.now(),
      top: top.status === 'fulfilled' ? (top.value.items || []).filter(Boolean).map(spTrack) : [],
      saved: saved.status === 'fulfilled' ? (saved.value.items || []).map((x) => x && x.track).filter(Boolean).map(spTrack) : [] };
    store.set('sf_sph', SPH);
  } catch {} finally { spHBusy = false; }
  paintSpHome();
}
function paintSpHome() {
  const all = homeChip === 'all', on = spOn() && SPH;
  const put = (secId, boxId, list) => {
    const sec = $(secId); sec.hidden = !(on && all && list && list.length >= 3); if (sec.hidden) return;
    const box = $(boxId); box.innerHTML = '';
    list.slice(0, 20).forEach((t, i) => box.append(card({ title: t.title, sub: t.artist, img: t.cover, onclick: (b) => { haptic(8); play(list, i, b.querySelector('img')); } })));
  };
  put('shSpTop', 'homeSpTop', on && SPH.top); put('shSpSaved', 'homeSpSaved', on && SPH.saved);
}

/* ---- selector de fuente en la búsqueda ---- */
function renderSrcs() {
  const box = $('srcs'); if (!box) return;
  box.hidden = !window.ClientAPI || CFG.kind === 'videos';
  const have = { sp: spOn(), sc: !!CFG.scId };
  box.querySelectorAll('button').forEach((b) => { b.hidden = b.dataset.src in have && !have[b.dataset.src]; b.classList.toggle('on', b.dataset.src === (CFG.src || 'both')); });
}
$('srcs').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; CFG.src = b.dataset.src; saveCfg(); renderSrcs(); haptic(5); if (S.lastQ) search(S.lastQ); });
