'use strict';
/* ===== Interfaz del reproductor: canción actual, pantallas, acciones, deslizadores y bucle principal ===== */

/* ---------- onda táctil ---------- */
const RIPPLE_SEL = '.rip,.pill,.chips button,.seg button,.kinds button,.item.btn,.menu-items button,.foot button,.q,.cat,.st,.lib-top button,.acc-card.btn';
document.addEventListener('pointerdown', (e) => {
  if (typeof LITE !== 'undefined' && LITE) return;
  const el = e.target.closest(RIPPLE_SEL); if (!el || e.target.closest('.more')) return;
  const r = el.getBoundingClientRect(), size = Math.max(r.width, r.height) * 1.6;
  const s = document.createElement('span'); s.className = 'rp';
  s.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
  el.append(s); setTimeout(() => s.remove(), 700);
});

/* ---------- canción actual ---------- */
function paintTrack(t) {
  addRecent(t); refreshHome();
  $('mini').classList.add('show');
  const mc = $('miniCover'); mc.src = t.cover || makeCover(t.title);
  mc.animate([{ transform: 'scale(.8)', opacity: .4 }, { transform: 'none', opacity: 1 }], { duration: 450, easing: 'cubic-bezier(.34,1.56,.64,1)' });
  $('miniT').textContent = t.title; $('miniA').textContent = t.artist;
  $('bigT').textContent = t.title; paintArtist(t);
  $('lyrT').textContent = t.title; $('lyrA').textContent = t.artist; $('lyrCover').src = t.cover || makeCover(t.title);
  $('srcName').textContent = t.dl ? 'Descarga' : t.local ? 'Tu música' : 'YouTube Music';
  $('artImg').src = t.cover || makeCover(t.title);
  const ab = $('artbox'); ab.classList.remove('swap'); void ab.offsetWidth; ab.classList.add('swap');
  $('btnDl').classList.toggle('off', !!t.local);
  S.offset = 0; $('offv').textContent = '0.0 s';
  if (S.results.length) renderList();
  paintLike(); renderQueue(); if (NAV.tab === 'radio') paintRadioNow();
  markPlayingRows();
}
// la fila de la canción que suena se resalta y muestra barras que bailan
function markPlayingRows() {
  const cur = S.queue[S.i], id = cur && tid(cur);
  document.querySelectorAll('.row[data-tid]').forEach((r) => {
    const on = r.dataset.tid === id, has = !!r.querySelector('.bars');
    r.classList.toggle('cur', on);
    if (on && !has) r.querySelector('.more').insertAdjacentHTML('beforebegin', BARS_HTML);
    else if (!on && has) r.querySelector('.bars').remove();
  });
}
// la portada vuela desde la lista hasta el mini reproductor con un resorte
function flyCover(img, url) {
  if (CFG.perf || !img || !img.getBoundingClientRect) return;
  const r = img.getBoundingClientRect(); if (!r.width || !img.isConnected) return;
  const tb = $('tabbar').getBoundingClientRect(), tx = 14, ty = tb.top - 64, size = 44;
  const el = document.createElement('img'); el.src = url; el.className = 'fly';
  el.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;border-radius:8px`;
  document.body.append(el);
  const a = el.animate([
    { transform: 'none', borderRadius: '8px', opacity: 1 },
    { transform: `translate(${tx - r.left}px,${ty - r.top}px) scale(${size / r.width})`, borderRadius: '10px', opacity: 1, offset: .85 },
    { transform: `translate(${tx - r.left}px,${ty - r.top}px) scale(${size / r.width})`, borderRadius: '10px', opacity: 0 },
  ], { duration: 620, easing: 'cubic-bezier(.22,1,.36,1)' });
  a.onfinish = () => el.remove();
}

/* ---------- pantallas ---------- */
function burst(b) { b.classList.remove('burst'); void b.offsetWidth; b.classList.add('burst'); setTimeout(() => b.classList.remove('burst'), 650); }
function openNP() {
  if (S.i < 0) return;
  const ab = $('artbox'), mc = $('miniCover').getBoundingClientRect();     // la portada crece desde el mini reproductor
  if (mc.width && ab.animate) ab.animate([{ translate: `${mc.left + mc.width / 2 - innerWidth / 2}px ${mc.top - innerHeight * .32}px`, scale: '.16', opacity: .5 }, { translate: '0 0', scale: '1', opacity: 1 }], { duration: 720, easing: 'cubic-bezier(.22,1,.36,1)' });
  S.npOpen = true; syncWake(); document.body.classList.add('np-open'); $('np').classList.add('open'); S.glDirty = true; syncMotion(); haptic(6); }
function closeNP() { S.npOpen = false; syncWake(); document.body.classList.remove('np-open'); $('np').classList.remove('open'); closeLyr(); syncMotion(); positionVideo(); }
function openLyr() { S.lyrOpen = true; $('lyr').classList.add('open'); S.active = -2; positionVideo(); haptic(6); }
function closeLyr() { S.lyrOpen = false; $('lopts').hidden = true; $('lyr').classList.remove('open'); positionVideo(); }

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  switch (b.dataset.act) {
    case 'play': haptic(10); toggle(); burst(b); break; case 'next': haptic(8); next(); break; case 'prev': haptic(8); prev(); break;
    case 'open-np': openNP(); break; case 'close-np': closeNP(); break;
    case 'open-lyr': openLyr(); break; case 'close-lyr': closeLyr(); break;
    case 'open-set': openSet(); break; case 'close-set': closeSet(); break; case 'close-menu': closeMenu(); break;
    case 'eq-mode': CFG.eq = (CFG.eq + 1) % 3; saveCfg(); syncSettingsUI(); toast('Ecualizador: ' + ['Barras', 'Ondas', 'Apagado'][CFG.eq]); break;
    case 'off-': S.offset -= 0.2; $('offv').textContent = S.offset.toFixed(1) + ' s'; break;
    case 'off+': S.offset += 0.2; $('offv').textContent = S.offset.toFixed(1) + ' s'; break;
    case 'video': setVideoMode(!S.video); break;
    case 'lyr-opts': { const o = $('lopts'); o.hidden = !o.hidden; haptic(6); break; }
    case 'canvas': canvasAction(); break;
    case 'add-audio': $('fileAudio').click(); break;
    case 'apple': openCfg(); break;
    case 'clear-lib': case 'clear-canvas': case 'clear-recent': case 'clear-dl': settingsAction(b.dataset.act, b); break;
  }
});
$('fileAudio').addEventListener('change', (e) => { const f = [...e.target.files]; e.target.value = ''; if (f.length) importFiles(f); });
$('fileCanvas').addEventListener('change', (e) => { const f = e.target.files[0]; e.target.value = ''; onCanvasFile(f); });
// al elegir una fuente de letra (o abrir las opciones de la canción) el panel se cierra solo
$('lopts').addEventListener('click', (e) => { if (e.target.closest('#seg button:not(:disabled)') || e.target.closest('.lo-more')) setTimeout(() => { $('lopts').hidden = true; }, 180); });
// tocar fuera del panel de opciones de la letra lo cierra
document.addEventListener('pointerdown', (e) => { const o = $('lopts'); if (!o.hidden && !e.target.closest('#lopts') && !e.target.closest('[data-act=lyr-opts]')) o.hidden = true; });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') window.__back();
  if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;
  if (e.code === 'Space') { e.preventDefault(); toggle(); }
});

/* ---------- deslizadores ---------- */
const paintRange = (el) => el.style.setProperty('--p', (el.value / el.max * 100) + '%');
$('seek').addEventListener('pointerdown', () => (S.seeking = true));
$('seek').addEventListener('input', (e) => {
  paintRange(e.target); const d = E.dur();
  if (d) { E.seek((e.target.value / 1000) * d); $('cur').textContent = fmt((e.target.value / 1000) * d); $('dur').textContent = '-' + fmt(Math.max(0, d - (e.target.value / 1000) * d)); }
});
['pointerup', 'pointercancel', 'change'].forEach((ev) => $('seek').addEventListener(ev, () => setTimeout(() => (S.seeking = false), 250)));
/* volumen: en Android mueve el volumen real del teléfono y sigue a los botones físicos */
let volDrag = false;
const readSysVol = () => { try { return Math.round(Native.getVolume()); } catch { return -1; } };
$('vol').value = sysVol() && readSysVol() >= 0 ? readSysVol() : store.get('ondas_vol', 80); paintRange($('vol'));
$('vol').addEventListener('pointerdown', () => (volDrag = true));
['pointerup', 'pointercancel', 'change'].forEach((ev) => $('vol').addEventListener(ev, () => setTimeout(() => (volDrag = false), 200)));
$('vol').addEventListener('input', (e) => {
  paintRange(e.target); store.set('ondas_vol', +e.target.value);
  if (sysVol()) { try { Native.setVolume(+e.target.value); } catch {} E.vol(100); } else E.vol(+e.target.value);
});
E.audio.volume = sysVol() ? 1 : $('vol').value / 100;
if (sysVol()) setInterval(() => {                              // los botones de volumen del teléfono mueven el deslizador
  if (document.hidden || volDrag) return;
  const v = readSysVol(); if (v >= 0 && Math.abs(v - +$('vol').value) >= 2) { $('vol').value = v; paintRange($('vol')); }
}, 700);

/* ---------- bucle principal ---------- */
let lastTick = -1, lastSec = -1, lastVis = 0;
/* el cristal se adapta al teléfono: si los cuadros tardan demasiado, baja un nivel (extremo → alto → medio → ahorro) */
const TIERS = ['ultra', 'high', 'mid', 'low'];
let tier = store.get('sf_tier2', null) || (lowEnd ? 'mid' : 'ultra'), dts = [], prevTs = 0, lastDown = 0, batLow = false;
if (tier === 'ultra' && !xgOk) tier = 'high';
function applyTier(t, say) {
  tier = t; store.set('sf_tier2', t); document.documentElement.dataset.tier = batLow ? 'low' : t; refreshXg();
  if (t === 'low' && !CFG.noAuto && !CFG.perf) { CFG.perf = true; saveCfg(); syncSettingsUI(); }
  if (say) toast(t === 'low' ? 'Activé el modo ahorro para que vaya fluido' : 'Bajé un poco el cristal para que vaya más fluido');
}
/* calidad elegida a mano en Ajustes */
function applyGq() {
  const m = { extrema: 'ultra', alta: 'high', media: 'mid', ahorro: 'low' };
  if (m[CFG.gq]) { CFG.perf = m[CFG.gq] === 'low'; CFG.noAuto = true; saveCfg(); document.body.classList.toggle('perf', CFG.perf); applyTier(m[CFG.gq]); syncSettingsUI(); toast('Calidad del cristal: ' + $('setGq').selectedOptions[0].textContent); }
  else { CFG.noAuto = false; CFG.perf = lowEnd; saveCfg(); document.body.classList.toggle('perf', CFG.perf); applyTier(lowEnd ? 'mid' : (xgOk ? 'ultra' : 'high')); syncSettingsUI(); dts = []; lastDown = performance.now(); }
}
applyTier(tier);
/* batería baja: efectos pesados apagados mientras no cargue */
function checkBattery() {
  if (!navigator.getBattery) return;
  navigator.getBattery().then((b) => {
    const low = CFG.batSaver !== false && !b.charging && b.level <= 0.2;
    if (low === batLow) return;
    batLow = low; document.documentElement.dataset.tier = low ? 'low' : tier; document.body.classList.toggle('perf', low || !!CFG.perf); refreshXg();
    if (low) toast('Batería baja: activé el modo ahorro');
    if (!checkBattery.bound) { checkBattery.bound = true; b.addEventListener('levelchange', checkBattery); b.addEventListener('chargingchange', checkBattery); }
  }).catch(() => {});
}
checkBattery();
/* al deslizar, el cristal usa un desenfoque simple (la lente se recalcula en cada cuadro y es lo más pesado) */
let scrollT = 0;
document.addEventListener('scroll', () => { if (!document.body.classList.contains('scrolling')) document.body.classList.add('scrolling'); clearTimeout(scrollT); scrollT = setTimeout(() => document.body.classList.remove('scrolling'), 160); }, { capture: true, passive: true });
function watchFps(ts) {
  const d = ts - prevTs; prevTs = ts;
  if (ts < 7000 || (CFG.gq && CFG.gq !== 'auto') || batLow) return;     // el arranque, la calidad manual y la batería baja no cuentan
  if (d > 200 || d <= 0) { dts = []; return; }                          // pausas de la app no cuentan
  dts.push(d); if (dts.length < 100) return;
  const s = dts.slice().sort((a, b) => a - b), p75 = s[Math.floor(s.length * .75)]; dts = [];
  if (p75 > 26 && ts - lastDown > 15000 && TIERS.indexOf(tier) < 3) { lastDown = ts; applyTier(TIERS[TIERS.indexOf(tier) + 1], true); }
}
function frame(ts) {
  requestAnimationFrame(frame);
  if (document.hidden || S.bg) { prevTs = 0; return; }          // en segundo plano no se dibuja nada: solo suena la música
  watchFps(ts);
  const t = ts / 1000, cur = E.time(), dur = E.dur();
  if (dur) {
    const tick = Math.round(cur / dur * 1000);            // solo se toca el DOM cuando algo cambia de verdad
    if (tick !== lastTick) {
      lastTick = tick; $('miniProg').style.transform = `scaleX(${tick / 1000})`;
      if (S.npOpen && !S.seeking) { const sk = $('seek'); sk.value = tick; paintRange(sk); }
    }
    const sec = Math.floor(cur);
    if (sec !== lastSec) {
      lastSec = sec; syncNative();
      if (S.npOpen && !S.seeking) { $('cur').textContent = fmt(cur); $('dur').textContent = CFG.remain === false ? fmt(dur) : '-' + fmt(Math.max(0, dur - cur)); }
    }
  }
  syncLyrics(cur);
  if (S.npOpen) {
    readFFT(); updateBands(t, cur);
    if ((!CFG.perf && !LITE) || ts - lastVis > (LITE ? 50 : 33)) { lastVis = ts; drawGL(t); drawEQ(); }
  }
  if (S.video) positionVideo();
}
window.addEventListener('resize', () => { S.glDirty = true; positionVideo(); });

initViews(); loadLibrary(); goTab('home', { force: true, silent: true });
requestAnimationFrame(frame);

/* inclinación 3D suave de la portada (giroscopio o dedo); apagada en modo ahorro */
(() => {
  const root = document.documentElement; let on = false;
  const set = (x, y) => { root.style.setProperty('--tx', x.toFixed(1)); root.style.setProperty('--ty', y.toFixed(1)); };
  const clamp = (v, m) => Math.max(-m, Math.min(m, v));
  window.addEventListener('deviceorientation', (e) => {
    if (document.hidden || LITE || document.body.classList.contains('perf') || !document.body.classList.contains('np-open') || e.beta == null) return;
    set(clamp((e.beta - 55) / 5, 7), clamp(e.gamma / 5, 7)); on = true;
  }, { passive: true });
  const box = () => document.getElementById('artbox');
  const pt = (e) => { if (on || LITE || document.body.classList.contains('perf')) return; const b = box(); if (!b) return; const r = b.getBoundingClientRect(), p = e.touches ? e.touches[0] : e; set(clamp(-((p.clientY - r.top) / r.height - .5) * 14, 8), clamp(((p.clientX - r.left) / r.width - .5) * 14, 8)); };
  document.addEventListener('touchmove', (e) => { if (e.target.closest && e.target.closest('#artwrap')) pt(e); }, { passive: true });
  document.addEventListener('touchend', () => { if (!on) set(0, 0); }, { passive: true });
  document.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse' && e.target.closest && e.target.closest('#artwrap')) pt(e); });
})();
