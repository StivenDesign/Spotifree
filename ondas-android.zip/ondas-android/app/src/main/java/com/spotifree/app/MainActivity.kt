package com.spotifree.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.util.Size
import java.io.ByteArrayOutputStream
import org.json.JSONArray
import android.graphics.Color
import android.content.res.Configuration
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * WebView que nunca se entera de que la app pasó a segundo plano: así Chromium no suspende el audio
 * (ni el de los videos de YouTube) al salir de la app o apagar la pantalla.
 */
class KeepAliveWebView(c: Context) : WebView(c) {
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(android.view.View.VISIBLE) }
    override fun onVisibilityChanged(changedView: android.view.View, visibility: Int) { super.onVisibilityChanged(changedView, android.view.View.VISIBLE) }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingOauth: String? = null
    private val cancelled: MutableSet<Int> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    private val dlDir: File get() = File(filesDir, "dl").apply { mkdirs() }

    /** Lee solo `left` bytes: así se responden las peticiones con Range (buscar dentro de la canción). */
    private class Limited(s: InputStream, private var left: Long) : FilterInputStream(s) {
        override fun read(): Int { if (left <= 0) return -1; val r = super.read(); if (r >= 0) left--; return r }
        override fun read(b: ByteArray, o: Int, l: Int): Int {
            if (left <= 0) return -1
            val r = super.read(b, o, minOf(l.toLong(), left).toInt()); if (r > 0) left -= r; return r
        }
    }

    /** Respuesta con soporte de Range para cualquier fuente de audio (descargas o música del teléfono). */
    private fun respondRange(req: WebResourceRequest, mime: String, len: Long, open: (Long) -> InputStream): WebResourceResponse {
        var start = 0L; var end = len - 1; var status = 200
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Access-Control-Allow-Origin" to "*")
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
        if (m != null) {
            val a = m.groupValues[1]; val b = m.groupValues[2]
            if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1) }
            else if (b.isNotEmpty()) start = maxOf(0L, len - b.toLong())
            if (start >= len) return WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$len"), ByteArrayInputStream(ByteArray(0)))
            status = 206; headers["Content-Range"] = "bytes $start-$end/$len"
        }
        headers["Content-Length"] = (end - start + 1).toString()
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", headers, Limited(open(start), end - start + 1))
    }

    private fun notFound() = WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
    private fun trackUri(id: Long) = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    /** Música del teléfono: https://appassets.androidplatform.net/media/<id> */
    private fun serveMedia(req: WebResourceRequest): WebResourceResponse {
        val id = req.url.lastPathSegment?.toLongOrNull() ?: return notFound()
        return try {
            val afd = contentResolver.openAssetFileDescriptor(trackUri(id), "r") ?: return notFound()
            val len = afd.length.takeIf { it > 0 } ?: afd.parcelFileDescriptor.statSize
            val mime = contentResolver.getType(trackUri(id)) ?: "audio/mpeg"
            respondRange(req, mime, len) { start ->
                val fis = FileInputStream(afd.fileDescriptor); fis.channel.position(afd.startOffset + start); fis
            }
        } catch (e: Exception) { notFound() }
    }

    /** Portada de una canción del teléfono: https://appassets.androidplatform.net/art/<id>?a=<albumId> */
    private fun serveArt(req: WebResourceRequest): WebResourceResponse {
        val id = req.url.lastPathSegment?.toLongOrNull() ?: return notFound()
        val albumId = req.url.getQueryParameter("a")?.toLongOrNull() ?: 0L
        return try {
            val bmp = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(trackUri(id), Size(512, 512), null)
            else contentResolver.openInputStream(ContentUris.withAppendedId(android.net.Uri.parse("content://media/external/audio/albumart"), albumId))?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return notFound()
            val out = ByteArrayOutputStream(); bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
            WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "max-age=86400"), ByteArrayInputStream(out.toByteArray()))
        } catch (e: Exception) { notFound() }
    }

    private val audioPerm get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    private fun hasAudioPerm() = checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            runOnUiThread { web.evaluateJavascript("window.__scanPerm&&window.__scanPerm($ok)", null) }
        }
    }

    /** Sirve las canciones descargadas en https://appassets.androidplatform.net/dl/<archivo> con soporte de Range. */
    /** Audio de fuentes con licencia libre (Internet Archive, Jamendo) y SoundCloud, servido desde el origen de la app para que el visualizador y el ecualizador funcionen. */
    private val proxyOk = Regex("^(?:[a-z0-9-]+\\.)*(archive\\.org|jamendo\\.com|sndcdn\\.com|soundcloud\\.com)$")
    private fun serveProxy(req: WebResourceRequest): WebResourceResponse {
        fun err(code: Int, why: String) = WebResourceResponse("text/plain", "utf-8", code, why, mapOf("Access-Control-Allow-Origin" to "*"), ByteArrayInputStream(ByteArray(0)))
        return try {
            val target = String(Base64.decode(req.url.path.orEmpty().removePrefix("/proxy/"), Base64.URL_SAFE or Base64.NO_WRAP))
            val u = URL(target)
            if (u.protocol != "https" || !proxyOk.matches(u.host.lowercase())) return err(403, "Forbidden")
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 30000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
            (req.requestHeaders["Range"] ?: req.requestHeaders["range"])?.let { c.setRequestProperty("Range", it) }
            val code = c.responseCode
            val h = mutableMapOf("Access-Control-Allow-Origin" to "*", "Accept-Ranges" to "bytes")
            listOf("Content-Range", "Content-Length").forEach { k -> c.getHeaderField(k)?.let { h[k] = it } }
            val mime = c.contentType?.substringBefore(';') ?: "audio/mpeg"
            val stream: InputStream = if (code >= 400) (c.errorStream ?: ByteArrayInputStream(ByteArray(0))) else c.inputStream
            WebResourceResponse(mime, null, code, if (code == 206) "Partial Content" else if (code < 400) "OK" else "Error", h, stream)
        } catch (e: Exception) { err(502, "Bad Gateway") }
    }

    private fun serveDownload(req: WebResourceRequest): WebResourceResponse {
        val name = File(Uri.decode(req.url.path.orEmpty().removePrefix("/dl/"))).name
        val f = File(dlDir, name)
        if (!f.isFile) return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        val len = f.length()
        val mime = when (f.extension.lowercase()) { "m4a", "mp4" -> "audio/mp4"; "ogg", "opus" -> "audio/ogg"; "flac" -> "audio/flac"; "wav" -> "audio/wav"; else -> "audio/mpeg" }
        var start = 0L; var end = len - 1; var status = 200
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Access-Control-Allow-Origin" to "*")
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
        if (m != null) {
            val a = m.groupValues[1]; val b = m.groupValues[2]
            if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1) }
            else if (b.isNotEmpty()) start = maxOf(0L, len - b.toLong())
            if (start >= len) return WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$len"), ByteArrayInputStream(ByteArray(0)))
            status = 206; headers["Content-Range"] = "bytes $start-$end/$len"
        }
        headers["Content-Length"] = (end - start + 1).toString()
        val fis = FileInputStream(f); fis.channel.position(start)
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", headers, Limited(fis, end - start + 1))
    }

    private var insT = 0f
    private var insB = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC     // los botones de volumen mueven el sonido multimedia
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = KeepAliveWebView(this)
        web.setBackgroundColor(Color.parseColor("#08080A"))
        setContentView(web)

        // Pantalla completa real: la página se dibuja detrás de la barra de estado y la de navegación (ambas transparentes).
        try {
            window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
            if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
            else window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            web.setOnApplyWindowInsetsListener { v, ins ->
                val d = resources.displayMetrics.density
                var t = 0; var b = 0; var ime = 0
                if (Build.VERSION.SDK_INT >= 30) {
                    val sb = ins.getInsets(android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout())
                    t = sb.top; b = sb.bottom; ime = ins.getInsets(android.view.WindowInsets.Type.ime()).bottom
                } else { @Suppress("DEPRECATION") run { t = ins.systemWindowInsetTop; b = ins.systemWindowInsetBottom } }
                insT = t / d; insB = b / d
                web.evaluateJavascript("window.__insets&&window.__insets($insT,$insB)", null)
                v.setPadding(0, 0, 0, if (ime > b) ime else 0)   // con el teclado abierto, la página se encoge
                ins
            }
        } catch (e: Exception) {}

        // Sirve los archivos de assets/www bajo https para que YouTube acepte el reproductor incrustado.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/dl/") == true) serveDownload(request)
                else if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/proxy/") == true) serveProxy(request)
                else if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/media/") == true) serveMedia(request)
                else if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/art/") == true) serveArt(request)
                else loader.shouldInterceptRequest(request.url)
        }
        // Selector de archivos: música local y videos de portada (canvas).
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        // Los botones de la notificación, la pantalla de bloqueo y los auriculares llegan a la página.
        PlayerService.onCommand = { cmd, arg ->
            runOnUiThread { web.evaluateJavascript("window.__media&&window.__media('$cmd',$arg)", null) }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        captureOauth(intent)
        captureShare(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        registerAudioEvents()
    }

    /** Avisa a la página cuando se desconectan los audífonos (para pausar) o se conectan (para reproducir). */
    private fun registerAudioEvents() {
        try {
            val noisy = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) { web.evaluateJavascript("window.__noisy&&window.__noisy()", null) }
            }
            val f = android.content.IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisy, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(noisy, f)
        } catch (e: Exception) {}
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.registerAudioDeviceCallback(object : android.media.AudioDeviceCallback() {
                override fun onAudioDevicesAdded(added: Array<out android.media.AudioDeviceInfo>?) {
                    val ok = added?.any {
                        it.isSink && (it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                            it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET)
                    } == true
                    if (ok) web.evaluateJavascript("window.__plug&&window.__plug()", null)
                }
            }, null)
        } catch (e: Exception) {}
    }

    private var pendingShare: String? = null

    private fun captureShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!t.isNullOrBlank()) pendingShare = t
        }
    }

    private fun captureOauth(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "spotifree") pendingOauth = d.toString()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureOauth(intent)
        captureShare(intent)
        if (pendingShare != null) web.evaluateJavascript("window.__share&&window.__share()", null)
        if (pendingOauth != null) web.evaluateJavascript("window.pollOauth&&window.pollOauth()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 78) {
            web.evaluateJavascript("window.__auth&&window.__auth(${if (resultCode == Activity.RESULT_OK) 1 else 0})", null)
        } else if (requestCode == 77) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // Horizontal = pantalla completa: sin hora, batería ni barras (se ven un momento al deslizar desde el borde)
    private fun applyLandscapeFullscreen() {
        try {
            val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            val c = WindowCompat.getInsetsController(window, window.decorView)
            if (land) {
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            } else {
                c.show(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            }
        } catch (e: Exception) {}
    }
    override fun onConfigurationChanged(newConfig: Configuration) { super.onConfigurationChanged(newConfig); applyLandscapeFullscreen() }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) applyLandscapeFullscreen() }

    // Al salir de la app el WebView sigue vivo: así la música no se corta.
    override fun onPause() { super.onPause(); web.onResume(); web.resumeTimers(); web.evaluateJavascript("window.__kick&&window.__kick()", null) }
    override fun onStop() {
        super.onStop(); web.onResume(); web.resumeTimers()
        web.evaluateJavascript("window.__bg&&window.__bg(true)", null)
    }
    override fun onStart() { super.onStart(); web.evaluateJavascript("window.__bg&&window.__bg(false)", null) }

    override fun onDestroy() {
        PlayerService.onCommand = null
        stopService(Intent(this, PlayerService::class.java))
        web.destroy()
        super.onDestroy()
    }

    /** Atrás cierra la pantalla abierta; si no hay nada que cerrar, manda la app a segundo plano. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    inner class Bridge {
        /** Pide a Android que no frene la app en segundo plano (ahorro de batería de fábrica). */
        @JavascriptInterface
        fun batteryOk(): Boolean = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)

        /** Datos del teléfono para decidir si necesita el modo gama baja (memoria, versión de Android, procesador). */
        @JavascriptInterface
        fun deviceInfo(): String {
            return try {
                val mi = android.app.ActivityManager.MemoryInfo()
                (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
                val soc = (if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else "") + " " + Build.HARDWARE + " " + Build.BOARD
                JSONObject().put("model", (try { android.provider.Settings.Global.getString(contentResolver, "device_name") } catch (e: Exception) { null }) ?: Build.MODEL).put("ramMb", mi.totalMem / 1048576L).put("sdk", Build.VERSION.SDK_INT).put("cores", Runtime.getRuntime().availableProcessors())
                    .put("lowRam", mi.lowMemory || (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).isLowRamDevice).put("soc", soc.lowercase()).toString()
            } catch (e: Exception) { "{}" }
        }

        @JavascriptInterface
        fun allowBackground() {
            runOnUiThread {
                try {
                    if (!batteryOk()) startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) {}
                }
            }
        }

        /**
         * Escanea la música del teléfono (MediaStore). Devuelve el JSON con las canciones, o "perm" si falta el permiso
         * (con ask=true lo pide; la página recibe la respuesta en window.__scanPerm).
         */
        @JavascriptInterface
        fun scanMusic(ask: Boolean): String {
            if (!hasAudioPerm()) {
                if (ask) runOnUiThread { requestPermissions(arrayOf(audioPerm), 2) }
                return "perm"
            }
            val arr = JSONArray()
            val proj = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.MIME_TYPE
            )
            try {
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000", null,
                    "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val artist = c.getString(2) ?: ""
                        arr.put(JSONObject()
                            .put("id", c.getLong(0)).put("title", c.getString(1) ?: "Sin título")
                            .put("artist", if (artist == "<unknown>") "" else artist)
                            .put("album", c.getString(3)?.takeIf { it != "<unknown>" } ?: "")
                            .put("duration", c.getLong(4) / 1000).put("albumId", c.getLong(5)).put("added", c.getLong(6)).put("mime", c.getString(7) ?: ""))
                    }
                }
            } catch (e: Exception) { return "[]" }
            return arr.toString()
        }

        /** Volumen multimedia del teléfono, de 0 a 100. */
        @JavascriptInterface
        fun getVolume(): Int {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
        }

        @JavascriptInterface
        fun setVolume(pct: Int) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (pct.coerceIn(0, 100) * max + 50) / 100, 0)
        }

        /** Peticiones HTTP sin restricciones CORS (YouTube Music, KuGou, Apple, etc.). */
        @JavascriptInterface
        fun request(id: Int, method: String, url: String, headers: String, body: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = method
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    h.keys().forEach { k -> c.setRequestProperty(k, h.getString(k)) }
                    if (body.isNotEmpty()) {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    status = c.responseCode
                    val stream = if (status >= 400) c.errorStream else c.inputStream
                    text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga una imagen y la devuelve como "tipo|base64" (para usarla en WebGL sin CORS). */
        @JavascriptInterface
        fun requestBytes(id: Int, url: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    status = c.responseCode
                    if (status < 400) {
                        val mime = c.contentType?.substringBefore(';') ?: "image/jpeg"
                        val bytes = c.inputStream.use { it.readBytes() }
                        text = mime + "|" + Base64.encodeToString(bytes, Base64.NO_WRAP)
                    }
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga un archivo de música a la carpeta privada de la app y avisa del progreso. */
        @JavascriptInterface
        fun download(id: Int, url: String, file: String) {
            cancelled.remove(id)
            Thread {
                val name = File(file).name
                val part = File(dlDir, "$name.part")
                var ok = false; var msg = ""; var size = 0L
                try {
                    if (!url.startsWith("https://")) throw Exception("Solo se permiten enlaces https")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    if (c.responseCode >= 400) throw Exception("El servidor respondió " + c.responseCode)
                    val total = c.contentLengthLong
                    var done = 0L; var lastPct = -1; var lastAt = 0L
                    c.inputStream.use { ins -> part.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            if (cancelled.contains(id)) throw Exception("Cancelada")
                            val n = ins.read(buf); if (n < 0) break
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt(); val now = System.currentTimeMillis()
                                if (pct != lastPct && now - lastAt > 200) { lastPct = pct; lastAt = now; runOnUiThread { web.evaluateJavascript("window.__dlProgress&&window.__dlProgress($id,$pct)", null) } }
                            }
                        }
                    } }
                    if (done < 1024) throw Exception("Archivo vacío")
                    if (!part.renameTo(File(dlDir, name))) throw Exception("No pude guardar el archivo")
                    ok = true; size = done
                } catch (e: Exception) {
                    part.delete(); msg = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript(if (ok) "window.__dlDone($id,true,$size)" else "window.__dlDone($id,false,${JSONObject.quote(msg)})", null)
                }
            }.start()
        }

        /** Guarda un archivo de texto (copia de seguridad) en Descargas/Spotifree. Devuelve la ruta o "error". */
        @JavascriptInterface
        fun saveFile(name: String, text: String): String {
            return try {
                val safe = File(name).name
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = android.content.ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safe); put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Spotifree")
                    }
                    val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return "error"
                    contentResolver.openOutputStream(u)?.use { it.write(text.toByteArray()) }
                    "Descargas/Spotifree/$safe"
                } else { val d = File(getExternalFilesDir(null), safe); d.writeText(text); d.absolutePath }
            } catch (e: Exception) { "error" }
        }

        /** Guarda una imagen PNG (en base64) en Imágenes/Spotifree. Devuelve la ruta o "error". */
        @JavascriptInterface
        fun saveImage(name: String, b64: String): String {
            return try {
                val safe = File(name).name
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = android.content.ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safe); put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Spotifree")
                    }
                    val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return "error"
                    contentResolver.openOutputStream(u)?.use { it.write(bytes) }
                    "Imágenes/Spotifree/$safe"
                } else { val d = File(getExternalFilesDir(null), safe); d.writeBytes(bytes); d.absolutePath }
            } catch (e: Exception) { "error" }
        }

        /** Texto que otra app compartió con Spotifree (un enlace de YouTube, por ejemplo). */
        @JavascriptInterface
        fun takeShare(): String { val s = pendingShare ?: ""; pendingShare = null; return s }

        /** Cancela una descarga en curso. */
        @JavascriptInterface
        fun dlCancel(id: Int) { cancelled.add(id) }

        /** Espacio usado por las descargas y espacio libre del teléfono, en bytes. */
        @JavascriptInterface
        fun storageInfo(): String = try {
            JSONObject().put("used", dlDir.listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L).put("free", dlDir.usableSpace).toString()
        } catch (e: Exception) { "{}" }

        @JavascriptInterface
        fun dlDelete(file: String) { File(dlDir, File(file).name).delete() }

        /** Abre un enlace https en el navegador (inicio de sesión de Spotify). */
        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {} }
        }

        /** Devuelve (una sola vez) la dirección spotifree://callback con la que Spotify volvió a la app. */
        @JavascriptInterface
        fun takeOauth(): String { val u = pendingOauth ?: ""; pendingOauth = null; return u }

        /** Pinta la barra de estado y la de navegación con el color de la canción, con transición suave. */
        @JavascriptInterface
        fun setBars(hex: String) {
            runOnUiThread {
                try {
                    // las barras son transparentes; solo se ajustan los iconos (claros u oscuros) según el color de fondo
                    val to = Color.parseColor(hex)
                    val lum = (0.299 * Color.red(to) + 0.587 * Color.green(to) + 0.114 * Color.blue(to)) / 255.0
                    if (Build.VERSION.SDK_INT >= 23) {
                        var f = window.decorView.systemUiVisibility
                        val light = lum > 0.62
                        f = if (light) f or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                        if (Build.VERSION.SDK_INT >= 26) f = if (light) f or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else f and android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                        window.decorView.systemUiVisibility = f
                    }
                } catch (e: Exception) {}
            }
        }

        /** Tasas de refresco que admite la pantalla con su resolución actual, por ejemplo "60,90,120". */
        @JavascriptInterface
        fun refreshRates(): String = try {
            @Suppress("DEPRECATION") val d = windowManager.defaultDisplay
            val cur = d.mode
            d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .map { Math.round(it.refreshRate) }.distinct().sorted().joinToString(",")
        } catch (e: Exception) { "60" }

        /** Pide a Android una tasa de refresco (0 = automática). */
        @JavascriptInterface
        fun setRefresh(hz: Int) {
            runOnUiThread {
                try {
                    val lp = window.attributes
                    if (hz <= 0) { lp.preferredDisplayModeId = 0; lp.preferredRefreshRate = 0f }
                    else {
                        @Suppress("DEPRECATION") val d = windowManager.defaultDisplay
                        val cur = d.mode
                        val m = d.supportedModes.firstOrNull { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight && Math.abs(it.refreshRate - hz) < 1.5f }
                        if (m != null) lp.preferredDisplayModeId = m.modeId
                        lp.preferredRefreshRate = hz.toFloat()
                    }
                    window.attributes = lp
                } catch (e: Exception) {}
            }
        }

        /** Pide el bloqueo del teléfono (huella, PIN, patrón). La página recibe 1 = ok, 0 = cancelado, 2 = el teléfono no tiene bloqueo. */
        @JavascriptInterface
        fun authenticate() {
            runOnUiThread {
                try {
                    val km = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                    val it = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Spotifree", "Confirma que eres tú") else null
                    if (it == null) web.evaluateJavascript("window.__auth&&window.__auth(2)", null)
                    else startActivityForResult(it, 78)
                } catch (e: Exception) { web.evaluateJavascript("window.__auth&&window.__auth(2)", null) }
            }
        }

        @JavascriptInterface
        fun insets(): String = "$insT,$insB"

        /** La página avisa qué suena y en qué punto va; Android actualiza notificación y pantalla de bloqueo. */
        @JavascriptInterface
        fun media(title: String, artist: String, playing: Boolean, posMs: Long, durMs: Long, cover: String) {
            runOnUiThread {
                val i = Intent(this@MainActivity, PlayerService::class.java)
                    .putExtra("title", title).putExtra("artist", artist).putExtra("playing", playing)
                    .putExtra("pos", posMs).putExtra("dur", durMs).putExtra("cover", cover)
                try {
                    if (PlayerService.running) startService(i) else startForegroundService(i)
                } catch (e: Exception) {
                    // sin permiso para iniciar el servicio en segundo plano: la música sigue sonando igual
                }
            }
        }
    }
}
