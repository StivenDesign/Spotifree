'use strict';
/* ===== Núcleo: utilidades, estado, motor de reproducción (YouTube + archivos locales) ===== */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const hue = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};
const lowEnd = (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 3;
const CFG = Object.assign({ prov: 'auto', eq: 0, motion: true, amb: true, kind: 'songs', perf: lowEnd, glass: 70, haptic: true }, store.get('sf_cfg', {}));
const saveCfg = () => store.set('sf_cfg', CFG);

let toastTimer, toastHide;
function hideToast() { const t = $('toast'); t.classList.remove('show'); clearTimeout(toastHide); toastHide = setTimeout(() => { if (!t.classList.contains('show')) t.hidden = true; }, 450); }
function toast(msg, undo) {
  const t = $('toast'); clearTimeout(toastHide); t.hidden = false; void t.offsetWidth; t.classList.add('show');
  $('toastMsg').textContent = msg;
  const u = $('toastUndo'); u.hidden = !undo;
  u.onclick = () => { if (undo) undo(); hideToast(); };
  clearTimeout(toastTimer); toastTimer = setTimeout(hideToast, undo ? 5000 : 2800);
}

/* ---------- acceso a datos: servidor local o puente nativo (Android) ---------- */
async function apiGet(name, params) {
  if (window.ClientAPI) return window.ClientAPI.handle(name, params);
  const r = await fetch('/api/' + name + '?' + new URLSearchParams(params));
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
}
// Imagen servida desde un origen seguro para poder usarla en WebGL y leer sus colores.
async function safeImage(url) {
  let src = url;
  if (!/^(blob:|data:)/.test(url)) src = window.ClientAPI ? (await window.ClientAPI.handle('img', { u: url })).data : '/api/img?u=' + encodeURIComponent(url);
  return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('imagen')); im.src = src; });
}

const PROVIDERS = [['auto', 'Auto'], ['betterlyrics', 'Better Lyrics'], ['kugou', 'KuGou'], ['apple', 'Apple Music'], ['lrclib', 'LRCLIB']];
const AUTO_ORDER = ['betterlyrics', 'apple', 'kugou', 'lrclib'];
const NB = 24;

const S = {
  queue: [], i: -1, playing: false, player: null, ready: false, pending: null, loadTok: 0,
  results: [], lyrics: null, active: -2, offset: 0, token: 0, seeking: false,
  bpm: 100, fft: null, fftAt: 0, bass: 0, energy: 0, glDirty: true,
  npOpen: false, lyrOpen: false, video: false,
};
const bands = new Float32Array(NB), target = new Float32Array(NB);
const tid = (t) => (t.dl ? 'D' + t.did : t.local ? 'L' + t.lid : t.videoId || ('Q' + (t.title || '') + (t.artist || '')));
const haptic = (ms = 8) => { if (CFG.haptic && navigator.vibrate) { try { navigator.vibrate(ms); } catch {} } };

/* ---------- motor: una sola interfaz para YouTube y para archivos locales ---------- */
const E = {
  kind: 'yt',
  audio: Object.assign(new Audio(), { preload: 'auto' }),
  time() { return this.kind === 'yt' ? ((S.ready && S.player.getCurrentTime && S.player.getCurrentTime()) || 0) : (this.audio.currentTime || 0); },
  dur() { return this.kind === 'yt' ? ((S.ready && S.player.getDuration && S.player.getDuration()) || 0) : (isFinite(this.audio.duration) ? this.audio.duration : 0); },
  seek(t) { if (this.kind === 'yt') { if (S.ready) S.player.seekTo(t, true); } else this.audio.currentTime = t; },
  vol(v) { if (S.ready) S.player.setVolume(v); this.audio.volume = v / 100; },
  toggle() {
    if (this.kind === 'yt') { if (S.ready) S.playing ? S.player.pauseVideo() : S.player.playVideo(); }
    else { resumeAudioCtx(); this.audio.paused ? this.audio.play().catch(() => {}) : this.audio.pause(); }
  },
};
['play', 'playing', 'pause'].forEach((ev) => E.audio.addEventListener(ev, () => { if (E.kind !== 'local') return; S.playing = !E.audio.paused; paintPlay(); }));
E.audio.addEventListener('ended', () => { if (E.kind === 'local') next(); });
E.audio.addEventListener('error', () => { if (E.kind === 'local') { toast('No se pudo reproducir este archivo'); } });

window.onYouTubeIframeAPIReady = () => {
  S.player = new YT.Player('yt', {
    width: 200, height: 113, playerVars: { origin: location.origin, playsinline: 1, controls: 0, disablekb: 1, rel: 0, iv_load_policy: 3 },
    events: {
      onReady: () => { S.ready = true; S.player.setVolume(+$('vol').value); if (S.pending) { S.player.loadVideoById(S.pending); S.pending = null; } },
      onStateChange: (e) => {
        if (E.kind !== 'yt') return;
        S.playing = e.data === YT.PlayerState.PLAYING || e.data === YT.PlayerState.BUFFERING;
        if (e.data === YT.PlayerState.ENDED) next();
        paintPlay();
      },
      onError: () => { toast('Esta canción no se puede reproducir aquí. Paso a la siguiente.'); setTimeout(next, 1500); },
    },
  });
};
// el reproductor de YouTube se carga solo cuando hace falta (o con el teléfono en reposo) para que la app abra rápido
let ytLoading = false;
function ensureYT() {
  if (ytLoading) return; ytLoading = true;
  const tag = document.createElement('script'); tag.src = 'https://www.youtube.com/iframe_api'; tag.onerror = () => { ytLoading = false; }; document.head.append(tag);
}
(window.requestIdleCallback || ((f) => setTimeout(f, 2500)))(ensureYT, { timeout: 4000 });

function paintPlay() {
  document.body.classList.toggle('is-playing', S.playing);
  const t = S.queue[S.i];
  document.title = S.playing && t ? `${t.title} · Spotifree` : 'Spotifree';
  S.glDirty = true;
  if (typeof syncMotion === 'function') syncMotion();
  syncNative(true);
}
// notificación y controles del sistema (pantalla de bloqueo, auriculares) en Android
let nat = { id: '', playing: null, dur: 0 };
function syncNative(force) {
  if (!window.Native || !Native.media) return;
  const t = S.queue[S.i]; if (!t) return;
  const dur = E.dur(), id = tid(t);
  if (!force && nat.id === id && nat.playing === S.playing && (nat.dur || !dur)) return;
  nat = { id, playing: S.playing, dur };
  try { Native.media(t.title, t.artist || '', S.playing, Math.round(E.time() * 1000), Math.round(dur * 1000)); } catch {}
}

function play(list, idx, fromImg, opts) {
  S.queue = list.slice(); S.radioSeed = (opts && opts.radio) || null;
  load(idx);
  if (fromImg && typeof flyCover === 'function') flyCover(fromImg, S.queue[idx].cover);
}
async function load(i) {
  if (i < 0 || i >= S.queue.length) return;
  S.i = i; const t = S.queue[i], my = ++S.loadTok;
  S.bpm = 82 + (hue(tid(t)) % 48);
  if (!t.local && !t.videoId) {
    paintTrack(t);
    try {
      const d = await apiGet('search', { q: (t.artist + ' ' + t.title).trim(), type: 'songs' });
      if (my !== S.loadTok) return;
      const hit = d.results && d.results[0];
      if (!hit) { toast('No encontré «' + t.title + '» en YouTube Music'); return setTimeout(next, 1200); }
      t.videoId = hit.videoId; if (!t.cover) t.cover = hit.cover; if (!t.duration) t.duration = hit.duration;
    } catch (e) { return toast('No pude buscar la canción: ' + e.message); }
  }
  paintTrack(t);
  if (t.local) {
    E.kind = 'local';
    try { if (S.ready) S.player.pauseVideo(); } catch {}
    if (S.video) setVideoMode(false);
    const url = t.dl ? t.url : await libraryURL(t); if (my !== S.loadTok || !url) return;
    await ensureAnalyser(); if (my !== S.loadTok) return;
    E.audio.src = url; E.vol(+$('vol').value);
    try { await resumeAudioCtx(); await E.audio.play(); } catch {}
  } else {
    E.kind = 'yt'; E.audio.pause(); ensureYT();
    E.vol(+$('vol').value);
    if (S.ready) S.player.loadVideoById(t.videoId); else S.pending = t.videoId;
  }
  onTrackLoad(t); loadLyrics(t);
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist, album: t.album || '', artwork: t.cover ? [{ src: t.cover, sizes: '512x512' }] : [] });
      navigator.mediaSession.setActionHandler('play', () => E.toggle()); navigator.mediaSession.setActionHandler('pause', () => E.toggle());
      navigator.mediaSession.setActionHandler('nexttrack', next); navigator.mediaSession.setActionHandler('previoustrack', prev);
    } catch {}
  }
}
const toggle = () => E.toggle();
// comandos que llegan desde la notificación, la pantalla de bloqueo y los auriculares de Android
window.__media = (c, arg) => {
  if (c === 'next') next(); else if (c === 'prev') prev();
  else if (c === 'play') { if (!S.playing) toggle(); } else if (c === 'pause') { if (S.playing) toggle(); }
  else if (c === 'seek') E.seek(Math.max(0, (+arg || 0) / 1000));
};
const next = async () => {
  if (!S.queue.length) return;
  if (S.i >= S.queue.length - 1 && S.radioSeed && window.ClientAPI) {         // radio infinita: pide más canciones parecidas
    try {
      const d = await apiGet('radio', { videoId: S.radioSeed }); const have = new Set(S.queue.map(tid));
      const more = d.tracks.filter((x) => !have.has(tid(x))); if (more.length) { S.queue.push(...more); S.radioSeed = more[more.length - 1].videoId; if (typeof renderQueue === 'function') renderQueue(); }
    } catch {}
  }
  load((S.i + 1) % S.queue.length);
};
const prev = () => { if (!S.queue.length) return; if (E.time() > 4) E.seek(0); else load((S.i - 1 + S.queue.length) % S.queue.length); };
