'use strict';
/* ===== Vistas: Inicio, Novedades, Radio, Biblioteca, Buscar, páginas de lista, cola y menús ===== */
const GENRES = ['Éxitos', 'Charts', 'Latinoamérica', 'Pop latino', 'Pop', 'Reguetón', 'Hip hop', 'Rock', 'Electrónica', 'Latino', 'Indie', 'Baladas', 'Lo-fi', 'Salsa', 'Regional mexicano', 'K-pop', 'Jazz', 'Clásica', 'Metal', 'R&B', 'Cumbia', 'Vallenato', 'Bachata', 'Corridos tumbados', 'Trap', 'Country', 'Reggae', 'Punk', 'Soul', 'Blues', 'House'];
// un cantante representativo por género: su foto sale en el botón, teñida con el color del botón
const GENRE_ARTIST = { 'Éxitos': 'Drake', 'Latinoamérica': 'Feid', 'Pop latino': 'Sebastián Yatra', 'Pop': 'Dua Lipa', 'Reguetón': 'Bad Bunny', 'Hip hop': 'Kendrick Lamar', 'Rock': 'Foo Fighters', 'Electrónica': 'Calvin Harris', 'Latino': 'Shakira', 'Indie': 'Arctic Monkeys', 'Baladas': 'Luis Miguel', 'Lo-fi': 'Joji', 'Salsa': 'Marc Anthony', 'Regional mexicano': 'Peso Pluma', 'K-pop': 'BTS', 'Jazz': 'Miles Davis', 'Clásica': 'Ludwig van Beethoven', 'Metal': 'Metallica', 'R&B': 'The Weeknd', 'Cumbia': 'Los Ángeles Azules', 'Vallenato': 'Carlos Vives', 'Bachata': 'Romeo Santos', 'Corridos tumbados': 'Natanael Cano', 'Trap': 'Travis Scott', 'Country': 'Morgan Wallen', 'Reggae': 'Bob Marley', 'Punk': 'Green Day', 'Soul': 'Adele', 'Blues': 'B.B. King', 'House': 'David Guetta' };
const genreColor = (n) => `hsl(${hue('g' + n)} 68% 46%)`;
// pone la foto del cantante dentro del botón (teñida con el color del botón); si no llega, el botón queda solo con su color
function genrePhoto(btn, img, name) {
  const a = GENRE_ARTIST[name]; if (!a || typeof artistInfo !== 'function') return;
  artistInfo(a).then((i) => { if (i && i.picture) { img.onload = () => { img.classList.add('ld'); btn.classList.add('has-ph'); }; img.src = i.picture; } }).catch(() => {});
}
const STATIONS = ['Pop', 'Reguetón', 'Hip hop', 'Rock', 'Electrónica', 'Latino', 'Indie', 'Lo-fi', 'Salsa', 'Baladas', 'Regional mexicano', 'K-pop', 'Cumbia', 'Vallenato', 'Bachata', 'Trap', 'Jazz', 'R&B'];
const ARTISTS = ['Bad Bunny', 'Karol G', 'Rosalía', 'The Weeknd', 'Dua Lipa', 'Taylor Swift', 'Peso Pluma', 'Shakira', 'Feid', 'Billie Eilish'];

/* ---------- datos propios: me gusta y listas ---------- */
const slim = (t) => {
  const o = { title: t.title, artist: t.artist || '', album: t.album || '', duration: t.duration || 0, cover: t.cover || '' };
  if (t.src) o.src = t.src;
  if (t.vid) o.vid = true;
  if (t.dlUrl) Object.assign(o, { dlUrl: t.dlUrl, dlSrc: t.dlSrc, license: t.license || '' });
  if (t.stream && t.url) Object.assign(o, { stream: true, free: t.dlOk !== false, dlOk: t.dlOk, url: t.url, license: t.license || '' });
  if (t.sc) Object.assign(o, { sc: true, scId: t.scId, scTr: t.scTr });
  if (t.dl) Object.assign(o, { local: true, dl: true, did: t.did, url: t.url }); else if (t.videoId) o.videoId = t.videoId;
  return o;
};
let LIKES = store.get('sf_likes', []);
let LISTS = store.get('sf_lists', []);
const saveLikes = () => store.set('sf_likes', LIKES);
const saveLists = () => store.set('sf_lists', LISTS);
const isLiked = (t) => !!t && LIKES.some((x) => tid(x) === tid(t));
function toggleLike(t) {
  if (!t) return;
  if (t.local && !t.dl) return toast('Me gusta funciona con canciones de YouTube y con tus descargas');
  const was = isLiked(t);
  LIKES = was ? LIKES.filter((x) => tid(x) !== tid(t)) : [slim(t), ...LIKES];
  saveLikes(); paintLike(true); refreshLibViews(); haptic(10);
  toast(was ? 'Quitada de Me gusta' : 'Añadida a Me gusta');
}
function paintLike(pop) {
  const on = isLiked(S.queue[S.i]);
  document.querySelectorAll('.like-btn').forEach((b) => { b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
  if (pop) { const h = document.querySelector('.heart'); h.classList.remove('pop'); void h.offsetWidth; h.classList.add('pop'); }
}
function newList(name, tracks = []) { const l = { id: 'l' + Date.now() + Math.random().toString(36).slice(2, 5), name, tracks: tracks.map(slim) }; LISTS.unshift(l); saveLists(); refreshLibViews(); return l; }
function addToList(l, t) {
  if (l.tracks.some((x) => tid(x) === tid(t))) return toast('Ya está en «' + l.name + '»');
  l.tracks.push(slim(t)); saveLists(); refreshLibViews(); toast('Añadida a «' + l.name + '»');
}
function askText(title, placeholder, initial, cb) {
  const w = document.createElement('div'); w.className = 'cfg';
  w.innerHTML = `<form class="glass"><h3>${esc(title)}</h3><label><input autocomplete="off" placeholder="${esc(placeholder)}" value="${esc(initial || '')}"></label><div class="btns"><button type="button" class="c">Cancelar</button><button class="ok" type="submit">Guardar</button></div></form>`;
  document.body.append(w); const inp = w.querySelector('input'); setTimeout(() => inp.focus(), 50);
  w.querySelector('.c').onclick = () => w.remove();
  w.querySelector('form').onsubmit = (e) => { e.preventDefault(); const v = inp.value.trim(); w.remove(); if (v) cb(v); };
}

/* ---------- piezas comunes ---------- */
document.addEventListener('load', (e) => { if (e.target.tagName === 'IMG') e.target.classList.add('ld'); }, true);
const grad = (s) => `linear-gradient(135deg,hsl(${hue(s)} 62% 42%),hsl(${(hue(s) + 50) % 360} 60% 22%))`;
// las portadas se piden todas juntas apenas llegan los datos, para que aparezcan de golpe
const PRE = new Set();
function prefetchImgs(urls) { let n = 0; for (const u of urls) { if (!u || PRE.has(u) || /^(data|blob):/.test(u)) continue; PRE.add(u); if (PRE.size > 800) PRE.clear(); const im = new Image(); im.decoding = 'async'; im.src = u; if (++n >= 80) break; } }
function card({ title, sub, img, round, big, onclick }) {
  const b = document.createElement('button'); b.className = 'rcard' + (round ? ' round' : '') + (big ? ' big' : '');
  b.innerHTML = `<div class="im">${img ? `<img src="${esc(img)}" alt="" decoding="async">` : ''}${big ? `<div class="ov"><b>${esc(title)}</b><small>${esc(sub || '')}</small></div>` : ''}</div>${big ? '' : `<b>${esc(title)}</b><small>${esc(sub || '')}</small>`}`;
  if (!img) { const im = b.firstChild; im.style.background = grad(title); im.innerHTML = `<span style="display:grid;place-items:center;height:100%;font-size:46px;font-weight:800;opacity:.85">${esc((title[0] || '♪').toUpperCase())}</span>`; }
  b.onclick = () => onclick(b);
  return b;
}
const SRC_NAME = { am: 'APPLE MUSIC', dz: 'DEEZER', sc: 'SOUNDCLOUD', yd: 'YOUTUBE', au: 'AUDIUS' };
const BARS_HTML = '<span class="bars"><b></b><b></b><b></b><b></b></span>';
function trackRow(t, list, idx, o = {}) {
  const cur = S.queue[S.i], now = cur && tid(cur) === tid(t);
  const r = document.createElement('div'); r.className = 'row rip' + (now ? ' cur' : ''); r.tabIndex = 0; r.setAttribute('role', 'button'); r.style.setProperty('--i', Math.min(idx, 12));
  const badge = t.dl ? '<span class="badge">DESCARGADA</span>' : t.local ? '<span class="badge">LOCAL</span>' : t.sp ? '<span class="badge">SPOTIFY</span>' : t.free ? `<span class="badge">LIBRE · ${esc(String(t.src || '').toUpperCase())}</span>` : t.src && SRC_NAME[t.src] ? `<span class="badge">${SRC_NAME[t.src]}</span>` : '';
  const subTxt = o.ap ? `${esc(t.artist || '')}` : `${badge}${esc(t.artist || '')}${t.album && !o.noAlbum ? ' · ' + esc(t.album) : ''}`;
  r.innerHTML = `<img class="cv" src="${esc(t.cover || makeCover(t.title + t.artist))}" alt="" decoding="async"><div class="tx"><b>${esc(t.title)}${t.explicit ? '<span class="exp">E</span>' : ''}</b><small>${subTxt}</small></div>${t.duration && !o.ap ? `<span class="dur">${fmt(t.duration)}</span>` : ''}${!t.local && !t.dl ? `<button class="dlb${dlOk(t) ? ' free' : ''}" aria-label="Descargar"><svg class="ic s"><use href="#i-dl"/></svg></button>` : ''}<button class="more" aria-label="Más opciones"><svg class="ic"><use href="#i-dots"/></svg></button>`;
  { const im = r.querySelector('.cv'); if (im) im.onerror = () => { im.onerror = null; im.src = makeCover(t.title + t.artist); }; }
  r.dataset.tid = tid(t);
  if (now) r.querySelector('.more').insertAdjacentHTML('beforebegin', BARS_HTML);
  r.onclick = (e) => {
    if (e.target.closest('.more')) { e.stopPropagation(); return trackMenu(t, o); }
    if (e.target.closest('.dlb')) { e.stopPropagation(); return downloadTrack(t); }
    r.classList.remove('tap'); void r.offsetWidth; r.classList.add('tap'); setTimeout(() => r.classList.remove('tap'), 700);
    if (r.closest('#list,#suggSongs')) pushHist({ t: 's', title: t.title, sub: t.artist || '', cover: t.cover, track: slim(t) });
    haptic(8); play(list, idx, r.querySelector('.cv'), o.radio ? { radio: t.videoId } : undefined);
  };
  r.onkeydown = (e) => { if (e.key === 'Enter') r.onclick(e); };
  return r;
}
function fillList(box, list, o) { prefetchImgs(list.map((t) => t.cover)); box.innerHTML = ''; list.forEach((t, i) => box.append(trackRow(t, list, i, o))); }
const skel = (n = 4) => '<div class="ld-spin"><i class="spin"></i></div>' + '<div class="skel"></div>'.repeat(n);
const songsOf = (items) => items.filter((x) => x.kind === 'song');

/* ---------- menú de una canción ---------- */
function trackMenu(t, o = {}) {
  const liked = isLiked(t);
  openMenu({ title: t.title, sub: t.artist, album: t.album, cover: t.cover }, [
    { icon: 'queue', label: 'Reproducir a continuación', run: () => { if (S.i < 0) return play([t], 0); S.queue.splice(S.i + 1, 0, t); toast('Sonará a continuación'); renderQueue(); } },
    { icon: 'plus', label: 'Añadir a la cola', run: () => { if (S.i < 0) return play([t], 0); S.queue.push(t); toast('Añadida a la cola'); renderQueue(); } },
    { icon: 'heart', label: liked ? 'Quitar de Me gusta' : 'Me gusta', run: () => toggleLike(t) },
    { icon: 'lib', label: 'Añadir a una lista…', keep: true, run: () => listPicker(t) },
    { icon: 'spark', label: 'Compartir como tarjeta', run: () => shareCard(t) },
    t.videoId ? { icon: 'radio', label: 'Crear estación', run: () => startRadio(t) } : null,
    !t.local ? { icon: 'dl', label: dlOk(t) ? 'Descargar' : 'Descargar…', run: () => downloadTrack(t) } : null,
    !t.local ? { icon: 'chart', label: 'Disponibilidad', run: () => availMenu(t) } : null,
    o.remove ? { icon: 'trash', label: o.removeLabel || 'Quitar de esta lista', run: o.remove } : null,
    o.np ? { icon: 'quote', label: 'Compartir letra', run: openLyrShare } : null,
    o.np ? { icon: 'shuffle', label: 'Aleatorio: ' + (CFG.shuffle ? 'activado' : 'apagado'), run: () => $('btnShuffle').click() } : null,
    o.np ? { icon: 'repeat', label: 'Repetir: ' + ['apagado', 'toda la lista', 'esta canción'][CFG.repeat || 0], run: () => $('btnRepeat').click() } : null,
    o.np && t.vid ? { icon: 'video', label: S.video ? 'Quitar el video' : 'Ver el video', run: () => setVideoMode(!S.video) } : null,
    o.np ? { icon: 'film', label: 'Canvas (portada animada)', run: () => canvasAction() } : null,
    o.np ? { icon: 'moon', label: 'Temporizador de reposo', run: sleepMenu } : null,
    o.np ? { icon: 'play', label: 'Modo coche', run: () => openCar() } : null,
    o.np ? { icon: 'chart', label: 'Velocidad: ' + (CFG.rate || 1) + '×', run: speedMenu } : null,
    o.np ? { icon: 'sliders', label: 'Ecualizador de audio', run: () => { openSheet('eqs'); paintEq(); } } : null,
    t.dl ? { icon: 'trash', label: 'Eliminar descarga', run: () => deleteDownload(t) } : null,
    t.local && !t.dl && !t.dev ? { icon: 'trash', label: 'Quitar de Mi música', run: () => removeTrack(t) } : null,
  ]);
}
function listPicker(t) {
  openMenu({ title: 'Añadir a una lista', sub: t.title, cover: t.cover }, [
    { icon: 'plus', label: 'Nueva lista…', run: () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { addToList(newList(n), t); }) },
    ...LISTS.map((l) => ({ icon: 'lib', label: `${l.name} · ${l.tracks.length}`, run: () => addToList(l, t) })),
  ]);
}
async function startRadio(seed) {
  if (!seed || !seed.videoId) return;
  toast('Creando radio…');
  try {
    const d = await apiGet('radio', { videoId: seed.videoId });
    const list = [seed, ...d.tracks.filter((x) => x.videoId !== seed.videoId)];
    play(list, 0, null, { radio: list[list.length - 1].videoId }); S.radioName = seed.title; paintRadioNow();
  } catch (e) { toast('No pude crear la radio: ' + e.message); }
}

/* ---------- Inicio ---------- */
let homeChip = 'all', homeData = store.get('sf_home', null);
function greeting() {
  const h = new Date().getHours(), base = h < 6 ? 'Buenas noches' : h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
  const n = (typeof ACC !== 'undefined' && ACC.name) || ''; return n ? `${base}, ${n}` : base;
}
function recents() { return store.get('ondas_recent', []); }
function addRecent(t) {
  if (CFG.noHist || (t.local && !t.dl)) return;
  const rec = recents().filter((x) => tid(x) !== tid(t)), s = slim(t); s.at = Date.now(); rec.unshift(s); store.set('ondas_recent', rec.slice(0, 14));
}
// álbumes y playlists que abriste: se mezclan con las canciones en "Reproducciones recientes"
function addRecentColl(c) {
  if (CFG.noHist || !c || !c.id || c.isArtist) return;
  const l = store.get('sf_rcoll', []).filter((x) => x.id !== c.id); l.unshift({ id: c.id, title: c.title, sub: String(c.sub || '').split(' • ').find((p) => p && !/^(Álbum|Sencillo|EP|Playlist)$/i.test(p) && !/^\d{4}$/.test(p)) || '', cover: c.cover || '', at: Date.now() }); store.set('sf_rcoll', l.slice(0, 10));
}
function paintRecentMix(rec) {
  const box = $('recent'); box.innerHTML = '';
  const songs = rec.map((t, i) => ({ k: 's', t, at: t.at || 0, i })), cols = store.get('sf_rcoll', []).map((c) => ({ k: 'c', c, at: c.at || 0, i: 99 }));
  const items = [...songs, ...cols].sort((a, b) => (b.at - a.at) || (a.i - b.i)).slice(0, 14), list = items.filter((x) => x.k === 's').map((x) => x.t);
  prefetchImgs(items.map((x) => (x.t || x.c).cover));
  items.forEach((x) => {
    if (x.k === 's') { const t = x.t, b = card({ title: t.title, sub: t.artist, img: t.cover, onclick: (el) => { haptic(8); play(list, list.indexOf(t), el.querySelector('img')); } }); if (t.explicit) b.querySelector(':scope > b').insertAdjacentHTML('beforeend', '<span class="exp">E</span>'); box.append(b); }
    else box.append(card({ title: x.c.title, sub: x.c.sub, img: x.c.cover, onclick: () => { haptic(8); openColl({ id: x.c.id, title: x.c.title, sub: x.c.sub, cover: x.c.cover }); } }));
  });
}
function dlTracksSafe() { return typeof dlTracks === 'function' ? dlTracks() : []; }
// artistas que más escuchas (o los de tus recientes), con su foto
let myArtKey = '';
function paintMyArtists() {
  const count = {};
  (typeof STATS !== 'undefined' ? Object.values(STATS.plays) : []).forEach((p) => { const a = mainArtist(p.track.artist); if (a) count[a] = (count[a] || 0) + p.n; });
  recents().forEach((t) => { const a = mainArtist(t.artist); if (a && !count[a]) count[a] = 0.1; });
  store.get('sf_follow', []).forEach((a) => { count[a] = (count[a] || 0) + 1000; });
  const names = Object.entries(count).sort((x, y) => y[1] - x[1]).slice(0, 10).map((e) => e[0]), key = names.join('|');
  $('shMyArt').hidden = !(names.length && homeChip === 'all');
  if (key === myArtKey) return; myArtKey = key;
  const box = $('myArtists'); box.innerHTML = '';
  names.forEach((n) => { const c = card({ title: n, sub: 'Artista', round: true, onclick: () => openArtist(n) }); box.append(c); decorateArtistCard(c, n); });
}
function refreshHome() {
  const rec = recents(), mine = LIB, dls = dlTracksSafe();
  const q = [];
  q.push({ title: 'Canciones que te gustan', img: LIKES[0] && LIKES[0].cover, grad: 'likes', go: () => openColl({ title: 'Canciones que te gustan', sub: LIKES.length + ' canciones', tracks: LIKES, cover: LIKES[0] && LIKES[0].cover, key: 'likes' }) });
  q.push({ title: 'Mis descargas', img: dls[0] && dls[0].cover, go: () => openColl({ title: 'Mis descargas', sub: dls.length + ' canciones', tracks: dlTracksSafe(), cover: dls[0] && dls[0].cover, key: 'dl' }) });
  q.push({ title: 'Mi música', img: mine[0] && mine[0].cover, go: () => openColl({ title: 'Mi música', sub: LIB.length + ' canciones', tracks: LIB, cover: LIB[0] && LIB[0].cover, key: 'mine' }) });
  rec.slice(0, rec[0] && rec[0].videoId ? 2 : 3).forEach((t, i) => q.push({ title: t.title, img: t.cover, go: () => play(rec, i) }));
  if (rec[0] && rec[0].videoId && window.ClientAPI) q.push({ title: 'Radio de ' + rec[0].title, img: rec[0].cover, go: () => startRadio(rec[0]) });
  const quick = $('quick'); quick.innerHTML = '';
  q.forEach((x) => {
    const b = document.createElement('button'); b.className = 'q';
    b.innerHTML = `${x.img ? `<img src="${esc(x.img)}" alt="">` : `<img alt="" src="${makeCover(x.title)}">`}<span>${esc(x.title)}</span>`;
    b.onclick = () => { haptic(6); x.go(); }; quick.append(b);
  });
  const rail = (box, list, playList, big) => { box.innerHTML = ''; list.forEach((t, i) => box.append(card({ title: t.title, sub: t.artist, img: t.cover, big, onclick: (b) => { haptic(8); play(playList || list, i, b.querySelector('img')); } }))); };
  paintRecentMix(rec); rail($('homeMine'), mine); rail($('homeDl'), dls);
  paintMyArtists();
  const top = typeof topTracks === 'function' ? topTracks(10).filter((p) => p.n >= 2).map((p) => p.track) : [];
  rail($('homeTop'), top);
  const all = homeChip === 'all';
  $('quick').hidden = true; if (typeof paintSpHome === 'function') paintSpHome();
  $('shRecent').hidden = !(rec.length && (all || homeChip === 'recent'));
  $('shTop').hidden = !(top.length >= 3 && all);
  $('shMine').hidden = !(mine.length && homeChip === 'mine');
  $('shDl').hidden = !(dls.length && homeChip === 'dl');
  $('ytShelves').hidden = !all; $('artists').parentElement.hidden = !all;
  $('shEmpty').hidden = !(all && !rec.length && !LIKES.length && !mine.length && !dls.length && !homeData);
}
$('hChips').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return; homeChip = b.dataset.chip;
  $('hChips').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); haptic(5); refreshHome();
});
// la primera fila es la «Top selecciones para ti»: tarjetas grandes verticales
function featureFirst(box, title) {
  const sec = box.querySelector('.shelf'); if (!sec) return;
  const h = sec.querySelector('h2'); if (h && title) h.textContent = title;
  sec.classList.add('feature');
  sec.querySelectorAll('.rcard:not(.round):not(.big)').forEach((c) => {   // texto encima de la portada con desenfoque progresivo
    const im = c.querySelector('.im'), t = c.querySelector(':scope > b'), u = c.querySelector(':scope > small'); if (!im || !t) return;
    const o = document.createElement('div'); o.className = 'fov'; o.append(t); if (u) o.append(u); im.append(o);
  });
}
function shelfHTML(box, sections, max = 7) {
  box.innerHTML = '';
  prefetchImgs(sections.slice(0, max).flatMap((s) => s.items.slice(0, 14).map((it) => it.cover)));
  sections.slice(0, max).forEach((s, i) => {
    const sec = document.createElement('section'); sec.className = 'shelf';
    sec.innerHTML = `<h2>${esc(s.title || 'Para ti')}</h2><div class="hscroll"></div>`;
    const rail = sec.querySelector('.hscroll'), songs = songsOf(s.items);
    s.items.slice(0, 14).forEach((it) => rail.append(card({
      title: it.title, sub: String(it.kind === 'song' ? it.artist : it.sub || '').replace(/Apple Music/gi, '𝑆𝑝𝑜𝑡𝑖𝑓𝑟𝑒𝑒'), img: it.cover, round: it.kind === 'artist',
      onclick: (b) => { haptic(8); if (it.kind === 'song') play(songs, songs.indexOf(it), b.querySelector('img')); else openColl({ id: it.id, title: it.title, sub: it.sub || '', cover: it.cover, isArtist: it.kind === 'artist' }); },
    })));
    sec.style.animationDelay = i * 70 + 'ms'; box.append(sec);
  });
}
async function loadHome(force) {
  if (!window.ClientAPI) { $('ytShelves').innerHTML = '<p class="empty-t">Las secciones de YouTube Music están disponibles en la app de Android.</p>'; return; }
  const fresh = homeData && Date.now() - homeData.t < 6 * 3600e3;
  if (homeData) { shelfHTML($('ytShelves'), homeData.sections); featureFirst($('ytShelves'), 'Top selecciones para ti'); } else $('ytShelves').innerHTML = `<div class="shelf"><h2>Para ti</h2>${skel(3)}</div>`;
  if (fresh && !force) return;
  try {
    const [d, ch] = await Promise.all([apiGet('home', {}), apiGet('charts', {}).catch(() => ({ sections: [] }))]);
    // listas oficiales (éxitos del momento) primero
    const charts = (ch.sections || []).filter((s) => s.items.some((x) => x.kind === 'song')).slice(0, 2).map((s) => ({ title: 'Éxitos oficiales' + (s.title ? ' · ' + s.title : ''), items: s.items }));
    d.sections = [...charts, ...d.sections];
    if (d.sections.length) { homeData = { t: Date.now(), sections: d.sections.slice(0, 9).map((s) => ({ title: s.title, items: s.items.slice(0, 14) })) }; store.set('sf_home', homeData); shelfHTML($('ytShelves'), homeData.sections); featureFirst($('ytShelves'), 'Top selecciones para ti'); }
    else if (!homeData) $('ytShelves').innerHTML = '';
    refreshHome();
    loadSpHome();
  } catch (e) { if (!homeData) $('ytShelves').innerHTML = `<p class="empty-t">No pude cargar tu inicio (${esc(e.message)}). Prueba a buscar algo.</p>`; }
}
function initArtists() {
  const box = $('artists'); box.innerHTML = '';
  ARTISTS.forEach((n) => { const c = card({ title: n, sub: 'Artista', round: true, onclick: () => openArtist(n) }); box.append(c); decorateArtistCard(c, n); });
}
async function openArtist(name) {
  haptic(6);
  try {   // página completa del artista (YouTube Music): canciones top, álbumes, sencillos, videos, similares…
    const [ch, info] = await Promise.all([apiGet('artistid', { name: mainArtist(name) }), artistInfo(name).catch(() => null)]);
    if (ch && ch.id) return openColl({ id: ch.id, title: (info && info.name) || ch.name || name, sub: info && info.fans ? Number(info.fans).toLocaleString('es') + ' seguidores' : '', cover: (info && info.picture) || ch.picture, isArtist: true });
  } catch {}
 const info = await artistInfo(name).catch(() => null);
  openColl({ title: (info && info.name) || name, sub: info && info.fans ? Number(info.fans).toLocaleString('es') + ' seguidores' : 'Canciones populares', cover: info && info.picture, tracks: null, loading: true, isArtist: true });
  try { const d = await apiGet('search', { q: name, type: 'songs' }); fillCollTracks({ title: (info && info.name) || name, sub: info && info.fans ? Number(info.fans).toLocaleString('es') + ' seguidores' : 'Canciones populares', cover: (info && info.picture) || (d.results[0] && d.results[0].cover), tracks: d.results, isArtist: true }); }
  catch (e) { $('collList').innerHTML = `<p class="empty-t">No pude buscar: ${esc(e.message)}</p>`; }
}

/* ---------- Novedades ---------- */
let newsData = store.get('sf_news', null), newsBusy = false;
function paintNews() {
  const box = $('newsBody'); box.innerHTML = '';
  if (!newsData) return;
  const seen = new Set(), albums = [], songs = [];
  newsData.sections.forEach((sec) => sec.items.forEach((it) => {
    const k = (it.id || it.videoId || it.title) + '';
    if (seen.has(k)) return; seen.add(k);
    if (it.kind === 'song') songs.push(it); else if (it.kind === 'album' || it.kind === 'playlist') albums.push(it);
  }));
  // «NUEVO ÁLBUM» + tarjeta grande, en carrusel
  if (albums.length) {
    const rail = document.createElement('div'); rail.className = 'nw-cards';
    albums.slice(0, 8).forEach((al) => {
      const c = document.createElement('button'); c.className = 'nw-card';
      c.innerHTML = `<small>${al.kind === 'album' ? 'NUEVO ÁLBUM' : 'LISTA'}</small><b>${esc(al.title)}</b><span>${esc(al.sub || '')}</span><div class="im"><img src="${esc(al.cover || '')}" alt="" decoding="async"></div>`;
      c.onclick = () => { haptic(8); openColl({ id: al.id, title: al.title, sub: al.sub || '', cover: al.cover }); }; rail.append(c);
    });
    box.append(rail);
  }
  // canciones nuevas destacadas: columnas de 4 filas que se deslizan de lado
  if (songs.length) {
    const h = document.createElement('h2'); h.className = 'nw-h'; h.textContent = 'Canciones nuevas destacadas'; box.append(h);
    const grid = document.createElement('div'); grid.className = 'nw-songs';
    songs.slice(0, 24).forEach((t, i) => {
      const r = document.createElement('div'); r.className = 'nw-row'; r.tabIndex = 0; r.setAttribute('role', 'button');
      r.innerHTML = `<img src="${esc(t.cover || makeCover(t.title))}" alt="" decoding="async"><div class="tx"><b>${esc(t.title)}</b><small>${esc(t.artist || '')}</small></div><button class="more" aria-label="Más opciones"><svg class="ic"><use href="#i-dots"/></svg></button>`;
      r.onclick = (e) => { if (e.target.closest('.more')) { e.stopPropagation(); return trackMenu(t); } haptic(6); play(songs, i); };
      grid.append(r);
    });
    box.append(grid);
  }
  const rest = newsData.sections.filter((s) => !s.items.every((x) => x.kind === 'song' || x.kind === 'album' || x.kind === 'playlist' ? false : false));
  const wrap = document.createElement('div'); box.append(wrap); shelfHTML(wrap, newsData.sections.slice(1), 8);
}
async function loadNews(force) {
  if (!window.ClientAPI) { $('newsBody').innerHTML = '<p class="empty-t">Las novedades están disponibles en la app de Android.</p>'; return; }
  if (newsBusy) return; const fresh = newsData && Date.now() - newsData.t < 6 * 3600e3;
  if (newsData) paintNews(); else $('newsBody').innerHTML = skel(5);
  if (fresh && !force) return;
  newsBusy = true; $('newsRefresh').classList.add('spin');
  try {
    const d = await apiGet('news', {});
    newsData = { t: Date.now(), sections: d.sections.slice(0, 10).map((s) => ({ title: s.title, items: s.items.slice(0, 14) })) }; store.set('sf_news', newsData); paintNews();
  } catch (e) { if (!newsData) $('newsBody').innerHTML = `<p class="empty-t">No pude cargar las novedades (${esc(e.message)}).</p>`; else toast('No pude actualizar'); }
  newsBusy = false; $('newsRefresh').classList.remove('spin');
}

/* ---------- Radio ---------- */
function paintRadioNow() {
  const t = S.queue[S.i], box = $('radioNow');
  if (!t || !t.videoId) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="radio-now glass"><img src="${esc(t.cover)}" alt=""><div style="flex:1;min-width:0"><b>${S.radioSeed ? 'Radio en marcha' : 'Radio de esta canción'}</b><small>${esc(t.title)} · ${esc(t.artist)}</small></div><button class="pill glass solid" id="rnGo">${S.radioSeed ? 'Reiniciar' : 'Iniciar'}</button></div>`;
  $('rnGo').onclick = () => startRadio(t);
}
async function stationFrom(q) {
  toast('Sintonizando…');
  try {
    const d = await apiGet('search', { q, type: 'songs' });
    if (!d.results.length) return toast('No encontré canciones');
    if (window.ClientAPI) startRadio(d.results[0]); else play(d.results, 0);
  } catch (e) { toast('No pude sintonizar: ' + e.message); }
}
function initRadio() {
  const box = $('stations'); box.innerHTML = '';
  // cuadrícula de 3 columnas con las primeras estaciones
  STATIONS.slice(0, 9).forEach((n) => {
    const b = document.createElement('button'); b.className = 'st2';
    b.innerHTML = `<span class="nm" style="color:hsl(${hue('g' + n)} 78% 46%)">${esc(n)}</span><small>radio</small>`;
    b.onclick = () => { haptic(8); stationFrom(n + ' hits'); }; box.append(b);
  });
  // «Al aire ahora»: todas las estaciones como tarjetas grandes con la foto de un cantante teñida
  const air = $('onAir'); air.innerHTML = '';
  STATIONS.forEach((n) => {
    const b = document.createElement('button'); b.className = 'st'; const c = genreColor(n); b.style.background = `linear-gradient(135deg,${c},hsl(${hue('g' + n)} 60% 30%))`;
    b.innerHTML = `<span>${esc(n)}</span><small>Radio sin fin</small><svg class="ic s"><use href="#i-radio"/></svg><i class="tilt" style="background:${c}"><img alt=""></i>`;
    genrePhoto(b, b.querySelector('img'), n);
    b.onclick = () => { haptic(8); stationFrom(n + ' hits'); }; air.append(b);
  });
  const ra = $('radioArtists'); ra.innerHTML = '';
  ARTISTS.forEach((n) => { const c = card({ title: n, sub: 'Radio', round: true, onclick: () => { haptic(8); stationFrom(n); } }); ra.append(c); decorateArtistCard(c, n); });
}

/* ---------- Biblioteca ---------- */
let libFilter = 'all', libEdit = false;
const libHidden = () => store.get('sf_libhide', []);
function listCover(tracks) { return tracks[0] && tracks[0].cover; }
// todas las canciones propias sin repetir: me gusta, descargas, tu música y teléfono
function libAll() {
  const seen = new Set(), out = [];
  [...LIKES, ...dlTracksSafe(), ...LIB, ...(typeof devTracks === 'function' ? devTracks() : [])].forEach((t) => { const k = tid(t); if (!seen.has(k)) { seen.add(k); out.push(t); } });
  return out;
}
function renderLib() {
  $('libChips').hidden = libFilter === 'all'; { const e = $('libEdit'); if (e) { e.textContent = libEdit ? 'Hecho' : 'Editar'; e.hidden = libFilter !== 'all'; } }
  const box = $('libBody'); box.innerHTML = '';
  const dls = dlTracksSafe(), f = libFilter;
  const tile = (icon, title, sub, color, go) => {
    const b = document.createElement('button'); b.className = 'glass'; b.innerHTML = `<div class="ico" style="background:${color}"><svg class="ic s"><use href="#i-${icon}"/></svg></div><div><span>${esc(title)}</span><small>${esc(sub)}</small></div>`; b.onclick = () => { haptic(6); go(); }; return b;
  };
  const all = libAll();
  if (f !== 'all') {   // volver a la lista principal
    const bk = document.createElement('button'); bk.className = 'lib-back'; bk.innerHTML = '<svg class="ic s"><use href="#i-back"/></svg><span>Biblioteca</span>';
    bk.onclick = () => { libFilter = 'all'; syncLibChips(); renderLib(); haptic(5); }; box.append(bk);
  }
  if (f === 'all') {
    const go = (k) => () => { libFilter = k; syncLibChips(); renderLib(); haptic(5); };
    const rows = [
      ['queue', 'Playlists', go('lists')], ['mic', 'Artistas', go('artists')], ['album', 'Álbumes', go('albums')], ['note', 'Canciones', go('songs')],
      ['heart', 'Me gusta', go('likes')], ['dl', 'Descargas', go('dl')], ['note', 'Mi música', go('mine')], ['phone', 'Del teléfono', go('device')],
      ['chart', 'Tu resumen', () => { renderStats(); openSheet('stats'); }], ['sliders', 'Ecualizador', () => { openSheet('eqs'); paintEq(); }],
    ];
    const rc = recents()[0];   // lo último que escuchaste, fijado arriba como en Apple Music
    if (rc && !libEdit) { const p = document.createElement('button'); p.className = 'lib-pin'; p.innerHTML = `<img src="${esc(rc.cover || makeCover(rc.title))}" alt=""><b>${esc(rc.title)}</b>`; p.onclick = () => { haptic(6); play([rc], 0); }; box.append(p); }
    const ul = document.createElement('div'); ul.className = 'lib-apple' + (libEdit ? ' editing' : ''); const hid = libHidden();
    rows.forEach(([ic, label, fn]) => {
      const off = hid.includes(label); if (off && !libEdit) return;
      const b = document.createElement('button'); b.className = off ? 'off' : ''; b.innerHTML = `${libEdit ? `<i class="chk${off ? '' : ' on'}"></i>` : ''}<svg class="ic s"><use href="#i-${ic}"/></svg><span>${esc(label)}</span>`;
      b.onclick = libEdit ? () => { const h = libHidden(), k = h.indexOf(label); if (k >= 0) h.splice(k, 1); else h.push(label); store.set('sf_libhide', h); haptic(5); renderLib(); } : fn; ul.append(b);
    });
    box.append(ul);
    if (all.length) {   // las últimas canciones que guardaste (me gusta, descargas, tu música)
      const h = document.createElement('h3'); h.className = 'lib-h'; h.textContent = 'Agregadas recientemente'; box.append(h);
      const g = document.createElement('div'); g.className = 'lib-recent';
      all.slice(0, 6).forEach((t, i) => {
        const c = document.createElement('button'); c.innerHTML = `<img src="${esc(t.cover || makeCover(t.title))}" alt=""><b>${esc(t.title)}</b><small>${esc(t.artist || '')}</small>`;
        c.onclick = () => { haptic(6); play(all, i); }; g.append(c);
      });
      box.append(g);
    }
  }
  const groupList = (keyFn, kind) => {
    const m = new Map(); all.forEach((t) => { const k = keyFn(t); if (!k) return; if (!m.has(k)) m.set(k, []); m.get(k).push(t); });
    if (!m.size) return box.insertAdjacentHTML('beforeend', `<p class="empty-t">Aún no hay ${kind}. Dale me gusta a canciones, descárgalas o añade música de tu teléfono.</p>`);
    const ul = document.createElement('div'); ul.className = 'lib-apple plain';
    [...m.entries()].sort((x, y) => x[0].localeCompare(y[0], 'es')).forEach(([k, tr]) => {
      const b = document.createElement('button'); b.innerHTML = `<img class="gcv" src="${esc(tr[0].cover || makeCover(k))}" alt=""><span>${esc(k)}<small>${tr.length} ${tr.length === 1 ? 'canción' : 'canciones'}</small></span>`;
      b.onclick = () => { haptic(6); openColl({ title: k, sub: tr.length + ' canciones', tracks: tr, cover: tr[0].cover, key: kind + ':' + k }); }; ul.append(b);
    });
    box.append(ul);
  };
  if (f === 'artists') groupList((t) => (typeof mainArtist === 'function' ? mainArtist(t.artist || '') : t.artist) || '', 'artistas');
  if (f === 'albums') groupList((t) => t.album || '', 'álbumes');
  if (f === 'all' || f === 'lists') {
    if (f === 'lists') { const nb = document.createElement('button'); nb.className = 'pill glass'; nb.textContent = 'Nueva lista'; nb.onclick = () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { newList(n); toast('Lista creada'); }); box.append(nb); }
    if (LISTS.length) {
      const h = document.createElement('div'); h.className = 'sec-h'; h.style.padding = '10px 0 4px'; h.textContent = 'Tus listas'; box.append(h);
      LISTS.forEach((l, i) => {
        const r = document.createElement('div'); r.className = 'row rip'; r.tabIndex = 0; r.setAttribute('role', 'button'); r.style.setProperty('--i', i);
        r.innerHTML = `<img class="cv" src="${esc(listCover(l.tracks) || makeCover(l.name))}" alt=""><div class="tx"><b>${esc(l.name)}</b><small>Lista · ${l.tracks.length} ${l.tracks.length === 1 ? 'canción' : 'canciones'}</small></div><button class="more" aria-label="Más"><svg class="ic"><use href="#i-dots"/></svg></button>`;
        r.onclick = (e) => { if (e.target.closest('.more')) { e.stopPropagation(); return listMenu(l); } haptic(6); openColl({ title: l.name, sub: l.tracks.length + ' canciones', tracks: l.tracks, cover: listCover(l.tracks), key: 'list:' + l.id }); };
        box.append(r);
      });
    } else if (f === 'lists') box.insertAdjacentHTML('beforeend', '<p class="empty-t">Aún no tienes listas. Crea una o añade canciones desde el menú ⋯.</p>');
  }
  const showTracks = (list, empty, o) => { if (!list.length) box.insertAdjacentHTML('beforeend', `<p class="empty-t">${empty}</p>`); else { const l = document.createElement('div'); l.className = 'list'; l.style.padding = '0'; box.append(l); fillList(l, list, o); } };
  if (f === 'likes') showTracks(LIKES, 'Toca el corazón en una canción y aparecerá aquí.', { remove: null });
  if (f === 'dl') showTracks(dls, 'Todavía no descargaste nada. Usa el botón Descargar del reproductor.', {});
  if (f === 'device') paintDevice(box);
  if (f === 'songs') showTracks(all, 'Aún no hay canciones. Dale me gusta, descarga música o añade archivos de tu teléfono.', {});
  if (f === 'mine') showTracks(LIB, 'Añade música de tu teléfono con el botón +.', {});
  if (f === 'all' && !LIKES.length && !LISTS.length && !dls.length && !LIB.length) box.insertAdjacentHTML('beforeend', '<p class="empty-t">Tu biblioteca está vacía. Dale me gusta a canciones, descarga música libre o añade archivos de tu teléfono.</p>');
}
// música del teléfono: escanear, filtrar y tocar (se muestran por tandas para que no se trabe con miles de canciones)
let devQ = '', devShow = 150;
function paintDevice(box) {
  const head = document.createElement('div'); head.className = 'dl-row';
  head.innerHTML = `<div class="tx"><b>Música del teléfono</b><small>${DEV.length ? DEV.length + ' canciones' : 'Aún no se ha escaneado'}</small></div><button class="pill glass" id="devScanBtn" data-act="scan-device">${DEV.length ? 'Escanear de nuevo' : 'Escanear ahora'}</button>`;
  box.append(head);
  if (!devCanScan()) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">El escaneo funciona en la app de Android.</p>'); return; }
  if (!DEV.length) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">Toca «Escanear ahora» y dame permiso para encontrar la música guardada en tu teléfono.</p>'); return; }
  const f = document.createElement('label'); f.className = 'search glass'; f.innerHTML = '<svg class="ic s"><use href="#i-search"/></svg><input type="search" placeholder="Filtrar en tu teléfono" autocomplete="off" autocapitalize="off">';
  const inp = f.querySelector('input'); inp.value = devQ; box.append(f);
  const act = document.createElement('div'); act.className = 'row-btns'; act.style.margin = '4px 0 10px';
  const mk = (t, fn) => { const b = document.createElement('button'); b.className = 'pill glass'; b.textContent = t; b.onclick = fn; return b; };
  const list = document.createElement('div'); list.className = 'list'; list.style.padding = '0';
  const draw = () => {
    const n = normTxt(devQ), all = devTracks().filter((t) => !n || normTxt(t.title + ' ' + t.artist + ' ' + t.album).includes(n));
    list.innerHTML = ''; const part = all.slice(0, devShow); fillList(list, part, {});
    if (all.length > part.length) { const m = mk(`Mostrar más (${all.length - part.length})`, () => { devShow += 200; draw(); }); m.style.margin = '10px auto'; m.style.display = 'block'; list.append(m); }
    if (!all.length) list.innerHTML = '<p class="empty-t">Nada con ese nombre.</p>';
    act.innerHTML = ''; if (all.length) { act.append(mk('Reproducir todo', () => play(all, 0)), mk('Aleatorio', () => { const c = CFG.shuffle; CFG.shuffle = true; play(all, Math.floor(Math.random() * all.length)); CFG.shuffle = c; })); }
  };
  inp.addEventListener('input', () => { devQ = inp.value; devShow = 150; draw(); });
  box.append(act, list); draw();
}
function listMenu(l) {
  openMenu({ title: l.name, sub: l.tracks.length + ' canciones', cover: listCover(l.tracks) }, [
    { icon: 'plus', label: 'Cambiar nombre', run: () => askText('Cambiar nombre', 'Nombre', l.name, (n) => { l.name = n; saveLists(); refreshLibViews(); }) },
    { icon: 'trash', label: 'Quitar canciones repetidas', run: () => { const seen = new Set(), n = l.tracks.length; l.tracks = l.tracks.filter((x) => { const k = tid(x); if (seen.has(k)) return false; seen.add(k); return true; }); saveLists(); refreshLibViews(); toast(n === l.tracks.length ? 'No había canciones repetidas' : 'Quité ' + (n - l.tracks.length) + ' repetidas'); } },
    { icon: 'trash', label: 'Eliminar lista', run: () => { LISTS = LISTS.filter((x) => x !== l); saveLists(); refreshLibViews(); toast('Lista eliminada'); } },
  ]);
}
{ const sc = document.getElementById('libScroll'), mi = document.getElementById('libMini'); if (sc && mi) sc.addEventListener('scroll', () => mi.classList.toggle('on', sc.scrollTop > 60), { passive: true }); }
function syncLibChips() { $('libChips').hidden = libFilter === 'all'; $('libChips').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.f === libFilter)); }
$('libChips').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; libFilter = b.dataset.f; syncLibChips(); haptic(5); renderLib(); });
function refreshLibViews() { renderLib(); refreshHome(); if ($('coll').classList.contains('open') && COLL.key) rebuildColl(); }

/* ---------- Buscar ---------- */
let recentQ = store.get('sf_qs', []);
function renderCats() {
  const box = $('cats'); box.innerHTML = '';
  GENRES.forEach((n) => { const b = document.createElement('button'); b.className = 'cat'; b.style.background = genreColor(n); b.innerHTML = `<img class="ph" alt=""><span class="t">${esc(n)}</span>`; genrePhoto(b, b.querySelector('img'), n); b.onclick = () => { haptic(6); $('q').value = n; search(n); }; box.append(b); });
}
// historial rico de búsqueda: artistas, canciones, álbumes y textos que buscaste
let qHist = store.get('sf_qh', null);
if (!qHist) { qHist = recentQ.map((q) => ({ t: 'q', title: q })); store.set('sf_qh', qHist); }
function pushHist(e) {
  if (CFG.noHist) return;
  qHist = [e, ...qHist.filter((x) => !(x.t === e.t && x.title === e.title))].slice(0, 14); store.set('sf_qh', qHist); renderRecentQ();
}
function renderRecentQ() {
  $('shRecentQ').hidden = !qHist.length; const box = $('recentQ'); box.className = 'hist-list'; box.innerHTML = '';
  qHist.forEach((h, i) => {
    let r;
    if (h.t === 'q') { r = apRow('', false, h.title, false, 'Búsqueda', () => { $('q').value = h.title; search(h.title); }); r.querySelector('.cv').outerHTML = '<span class="cv qic"><svg class="ic"><use href="#i-search"/></svg></span>'; }
    else if (h.t === 'a') r = apRow(h.cover, true, h.title, false, 'Artista', () => openColl({ id: h.id, title: h.title, sub: h.sub || '', cover: h.cover, isArtist: true }));
    else if (h.t === 'al') r = apRow(h.cover, false, h.title, false, 'Álbum · ' + (h.sub || ''), () => openColl({ id: h.id, title: h.title, sub: h.sub || '', cover: h.cover }));
    else r = apRow(h.cover, false, h.title, !!(h.track && h.track.explicit), 'Canción · ' + (h.sub || ''), () => { if (h.track) play([h.track], 0); });
    r.style.setProperty('--i', i); box.append(r);
  });
}
function renderKinds() { if (!['songs', 'videos', 'artists', 'albums'].includes(CFG.kind)) CFG.kind = 'songs'; $('kinds').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.kind === CFG.kind)); $('list').classList.toggle('as-songs', CFG.kind !== 'videos'); $('list').classList.toggle('ap', CFG.kind !== 'videos'); }
$('kinds').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; CFG.kind = b.dataset.kind; saveCfg(); renderKinds(); haptic(5); if (S.lastQ) search(S.lastQ); });
$('searchForm').addEventListener('submit', (e) => { e.preventDefault(); $('q').blur(); search($('q').value.trim()); });
$('q').addEventListener('input', () => { const has = !!$('q').value; $('qClear').hidden = !has; if (!has) showSearchHome(); });
$('qClear').onclick = () => { $('q').value = ''; $('qClear').hidden = true; showSearchHome(); $('q').focus(); };
function showSearchHome() { S.lastQ = ''; $('searchHome').hidden = false; $('searchRes').hidden = true; paintSfx(); }
/* «Bad Bunny en Spotifree»: el texto buscado y, en gris, dónde se busca */
function paintSfx() {
  const q = $('q'), s = $('qSfx'); if (!s) return;
  const show = !!S.lastQ && q.value.trim() === S.lastQ && document.activeElement !== q;
  s.hidden = !show; if (!show) return;
  const cs = getComputedStyle(q), c = paintSfx.c || (paintSfx.c = document.createElement('canvas').getContext('2d'));
  c.font = cs.font; const w = c.measureText(q.value).width;
  s.textContent = ' en Spotifree'; s.style.left = (q.offsetLeft + parseFloat(cs.paddingLeft || 0) + Math.min(w, q.clientWidth - 90)) + 'px';
}
$('q').addEventListener('focus', paintSfx); $('q').addEventListener('blur', () => setTimeout(paintSfx, 50));
{ const vs = $('v-search'), q = $('q');   // al tocar el buscador: el título se pliega, la barra sube y entran los recientes
  q.addEventListener('focus', () => { vs.classList.add('focus'); if (!S.lastQ && !q.value) { $('searchHome').hidden = false; $('searchRes').hidden = true; } vs.querySelectorAll('.hist-list .row').forEach((r) => { r.style.animation = 'none'; void r.offsetWidth; r.style.animation = ''; }); });
  q.addEventListener('blur', () => setTimeout(() => { if (document.activeElement !== q && !q.value && !S.lastQ) vs.classList.remove('focus'); }, 120)); }
$('qBack').addEventListener('click', () => { if (!$('q').value && !S.lastQ && $('v-search').classList.contains('focus')) { $('q').blur(); $('v-search').classList.remove('focus'); return; } if ($('q').value || S.lastQ) { $('q').value = ''; $('qClear').hidden = true; showSearchHome(); $('q').blur(); } else goTab('home'); });
let searchTok = 0;
const SRC_LABEL = { yt: 'YouTube Music', yd: 'YouTube (API)', sp: 'Spotify', am: 'Apple Music', dz: 'Deezer', au: 'Audius', sc: 'SoundCloud' };
const SRC_ORDER = ['sp', 'am', 'dz', 'yt', 'yd', 'au', 'sc'];
function srcAvail() {
  const ap = store.get('ondas_apple', {});
  return { yt: true, sp: spOn(), am: !!window.ClientAPI, dz: !!window.ClientAPI, yd: !!(window.ClientAPI && CFG.ytKey), sc: !!(window.ClientAPI && CFG.scId), au: !!window.ClientAPI, _ap: ap };
}
async function iaTracks(q) {
  const d = await apiGet('ia', { q, free: '1' }), albums = (d.results || []).slice(0, 2);
  const parts = await Promise.allSettled(albums.map((a) => apiGet('iafiles', { id: a.id })));
  return parts.flatMap((p) => (p.status === 'fulfilled' ? p.value.tracks || [] : [])).slice(0, 14);
}
async function search(q) {
  if (!q) return;
  clearTimeout(SUG.t); SUG.tok++; $('sugg').hidden = true; S.lastQ = q; showArtistHit(q); $('qClear').hidden = false; $('searchHome').hidden = true; $('searchRes').hidden = false; renderKinds();
  if (NAV.tab !== 'search') goTab('search', { silent: true });
  if (!CFG.noHist) { recentQ = [q, ...recentQ.filter((x) => x !== q)].slice(0, 10); store.set('sf_qs', recentQ); pushHist({ t: 'q', title: q }); }
  $('list').innerHTML = skel(5); $('searchScroll').scrollTo({ top: 0 });
  S.ext = null; apiGet('ytmx', { q }).then((x) => { if (S.lastQ === q) { S.ext = x; renderList(); } }).catch(() => { if (S.lastQ === q) { S.ext = { artists: [], albums: [] }; renderList(); } });
  renderSrcs();
  runSearch(q, CFG.kind === 'videos' ? 'yt' : (CFG.src || 'both'), true); setTimeout(paintSfx, 60);
}
/* todas las fuentes a la vez: cada una pinta sus resultados en cuanto llega; si la elegida no tiene nada, se busca en las demás */
function runSearch(q, sel, canFallback) {
  const my = ++searchTok, kind = CFG.kind === 'videos' ? 'videos' : 'songs', av = srcAvail(), ap = av._ap;
  const ids = (sel === 'both' ? Object.keys(SRC_LABEL).filter(srcOn) : [sel]).filter((k) => av[k]); if (!ids.length) ids.push('yt');
  const job = {
    yt: () => apiGet('search', { q, type: kind }), sp: () => spSearchTracks(q), dz: () => apiGet('deezer', { q }), sc: () => apiGet('sc', { q, cid: CFG.scId }),
    am: () => (ap.dev ? apiGet('amapi', { q, dev: ap.dev, sf: ap.storefront || 'us' }).catch(() => apiGet('itunes', { q })) : apiGet('itunes', { q })),
    yd: () => apiGet('ytapi', { q, key: CFG.ytKey }), au: () => apiGet('audius', { q }),
  };
  const lists = {}, failed = []; let pending = ids.length, lastErr = null;
  const paint = () => {
    const order = SRC_ORDER.filter((k) => lists[k] && lists[k].length);
    let res = order.length === 1 ? lists[order[0]] : mergeMany(order.map((k) => lists[k]));
    res = rankOfficial(res); if (typeof devMatches === 'function' && kind !== 'videos') res = [...devMatches(q), ...res];
    S.results = res; if (res.length) renderList();
  };
  ids.forEach((k) => job[k]().then((r) => { lists[k] = Array.isArray(r) ? r : (r.results || []); }).catch((e) => { failed.push(k); lastErr = e; lists[k] = []; }).finally(() => {
    if (my !== searchTok) return; pending--;
    if (lists[k] && lists[k].length) paint();
    if (pending) return;
    const total = Object.values(lists).reduce((n, l) => n + l.length, 0);
    if (!total) {
      if (canFallback && sel !== 'both') { toast('No la encontré en ' + (SRC_LABEL[sel] || 'ese proveedor') + '. Busco en los demás…'); return runSearch(q, 'both', false); }
      $('list').innerHTML = failed.length === ids.length
        ? `<p class="empty-t">${navigator.onLine === false ? 'Sin conexión. Solo puedes oír tu música descargada y la del teléfono.' : 'No pude buscar: ' + esc((lastErr && lastErr.message) || 'error de conexión')}</p>`
        : '<p class="empty-t">Sin resultados. Prueba con otro nombre.</p>';
      return;
    }
    const bad = failed.filter((x) => x !== 'yt'); if (bad.length && sel !== 'both') toast('No respondió: ' + bad.map((x) => SRC_LABEL[x]).join(', '));
  }));
}
function apRow(img, round, title, exp, sub, onclick) {
  const r = document.createElement('div'); r.className = 'row rip ap-row'; r.tabIndex = 0; r.setAttribute('role', 'button');
  r.innerHTML = `<img class="cv${round ? ' rnd' : ''}" src="${esc(img || makeCover(title))}" alt="" decoding="async"><div class="tx"><b>${esc(title)}${exp ? '<span class="exp">E</span>' : ''}</b><small>${esc(sub)}</small></div>`;
  const im = r.querySelector('.cv'); im.onerror = () => { im.onerror = null; im.src = makeCover(title); };
  r.onclick = () => { haptic(8); onclick(); }; r.onkeydown = (e) => { if (e.key === 'Enter') onclick(); };
  return r;
}
const artistRow = (a) => apRow(a.picture, true, a.name, false, 'Artista' + (a.fans ? ' · ' + a.fans : ''), () => { pushHist({ t: 'a', title: a.name, id: a.id, sub: a.fans || '', cover: a.picture }); openColl({ id: a.id, title: a.name, sub: a.fans || '', cover: a.picture, isArtist: true }); });
const albumRow = (al) => apRow(al.cover, false, al.title, al.explicit, (al.type || 'Álbum') + ' · ' + al.artist + (al.year ? ' · ' + al.year : ''), () => { pushHist({ t: 'al', title: al.title, id: al.id, sub: al.artist, cover: al.cover }); openColl({ id: al.id, title: al.title, sub: al.artist + (al.year ? ' • ' + al.year : ''), cover: al.cover }); });
function renderList() {
  const box = $('list'), k = CFG.kind, ex = S.ext;
  if (k === 'videos') { if (!S.results.length) { box.innerHTML = '<p class="empty-t">Sin resultados. Prueba con otro nombre.</p>'; return; } fillList(box, S.results, { radio: false }); return; }
  if (k === 'artists' || k === 'albums') {
    if (!ex) { box.innerHTML = skel(5); return; }
    const l = k === 'artists' ? ex.artists : ex.albums; box.innerHTML = '';
    if (!l.length) { box.innerHTML = '<p class="empty-t">Sin resultados. Prueba con otro nombre.</p>'; return; }
    prefetchImgs(l.map((x) => x.picture || x.cover)); l.forEach((x) => box.append(k === 'artists' ? artistRow(x) : albumRow(x))); return;
  }
  const songs = S.results || [];
  if (!songs.length && !(ex && (ex.artists.length || ex.albums.length))) { box.innerHTML = ex ? '<p class="empty-t">Sin resultados. Prueba con otro nombre.</p>' : skel(5); return; }
  prefetchImgs(songs.map((t) => t.cover)); box.innerHTML = '';
  const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, ''), nq = norm(S.lastQ);
  // el perfil de un artista solo sale entre los mejores resultados si de verdad hay canciones suyas ahí (así "Dinastía" no te muestra a un cantante cualquiera con ese nombre; ese perfil queda en la pestaña Artistas)
  const hits = (a) => songs.slice(0, 10).filter((t) => norm(String(t.artist || '').split(/,|&| x |\/| feat\.?| ft\.?/i)[0]) === norm(a.name)).length;
  const art = ex && ex.artists.find((a) => nq && (norm(a.name).includes(nq) || nq.includes(norm(a.name))) && hits(a) >= Math.min(2, Math.max(1, songs.length))), albs = ex ? ex.albums.slice(0, 4) : [];
  let si = 0; const song = () => songs[si] ? trackRow(songs[si], songs, si++, { ap: true, radio: false }) : null;
  const seq = [song, art && (() => artistRow(art)), song, ...albs.slice(0, 2).map((a) => () => albumRow(a)), song, song, ...albs.slice(2).map((a) => () => albumRow(a))].filter(Boolean);
  seq.forEach((f) => { const n = f(); if (n) box.append(n); });
  while (si < songs.length) box.append(song());
}

/* ---------- página de álbum, lista o artista ---------- */
const COLL = { stack: [], cur: null, key: null };
function openColl(c) {
  if ($('coll').classList.contains('open') && COLL.cur) COLL.stack.push(COLL.cur);
  COLL.cur = c; COLL.key = c.key || null; paintColl(c); addRecentColl(c);
  openSheet('coll'); $('collBody').scrollTop = 0;
  if (c.id) loadCollRemote(c);
}
function closeColl() { if (COLL.stack.length) { COLL.cur = COLL.stack.pop(); COLL.key = COLL.cur.key || null; paintColl(COLL.cur); return; } COLL.cur = null; collMotionClear(); closeSheet('coll'); }
// perfil de artista: foto a pantalla completa que se difumina hacia el negro, con el nombre encima
// color de fondo del álbum sacado de la portada (como Apple Music); si no se puede leer, uno según el nombre
function albumTint(c) {
  const el = $('coll'), fb = `hsl(${hue(c.title || '')} 38% 22%)`; el.style.setProperty('--ab', fb);
  if (!c.cover || /^data:/.test(c.cover)) return;
  const im = new Image(); im.crossOrigin = 'anonymous';
  im.onload = () => { try {
    const cv = document.createElement('canvas'); cv.width = cv.height = 12; const x = cv.getContext('2d'); x.drawImage(im, 0, 0, 12, 12);
    const d = x.getImageData(0, 0, 12, 12).data; let r = 0, g = 0, b = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) { const m = Math.max(d[i], d[i + 1], d[i + 2]), s = m - Math.min(d[i], d[i + 1], d[i + 2]); const w = 1 + s / 40; r += d[i] * w; g += d[i + 1] * w; b += d[i + 2] * w; n += w; }
    if (COLL.cur === c) el.style.setProperty('--ab', `rgb(${Math.round(r / n * .42)},${Math.round(g / n * .42)},${Math.round(b / n * .42)})`);
  } catch {} };
  im.src = c.cover;
}
function paintAlbumMeta(c, sub) {
  const on = $('collBody').querySelector('.coll-hero').classList.contains('alb'), m = $('collMeta'), d = $('collDesc');
  const parts = String(sub || '').split(' • ').map((s) => s.trim()).filter(Boolean), yr = parts.find((s) => /^\d{4}$/.test(s)), n = (c.tracks || []).length;
  m.hidden = !on; m.textContent = [yr, n ? n + ' canciones' : ''].filter(Boolean).join(' • ');
  d.hidden = !on || !c.desc; d.classList.add('clamp'); d.innerHTML = c.desc ? esc(c.desc) + ' <button class="more-t">MÁS</button>' : '';
  const bt = d.querySelector('.more-t'); if (bt) bt.onclick = () => { d.classList.remove('clamp'); bt.remove(); };
  $('collSave').hidden = !on;
}
function heroArt(c) {
  const h = document.querySelector('#collBody .coll-hero'), bg = $('collBg'), on = !!c.isArtist && !!c.cover;
  const tt = $('collTitle'); tt.className = ''; tt.classList.remove('alogo'); if (on && typeof logoArtist === 'function') logoArtist(tt, c.title);
  const alb = !on && !!c.id && /^(MPRE|OLAK)/.test(String(c.id)); h.classList.toggle('alb', alb); $('coll').classList.toggle('is-alb', alb); $('collList').classList.toggle('numbered', on || alb);
  if (alb) albumTint(c); else $('coll').style.removeProperty('--ab');
  h.classList.toggle('art', on); 
  bg.style.backgroundImage = c.cover && !c.cover.startsWith('data:image/svg') ? `url("${String(c.cover).replace(/"/g, '%22')}")` : '';
}
// carátula animada de álbum a pantalla completa arriba de la página (si Apple tiene la ilustración animada)
function collMotionClear() {
  const h = document.querySelector('#collBody .coll-hero'); if (!h) return;
  h.classList.remove('mot', 'tall', 'genm'); h.querySelectorAll('.coll-gen').forEach((n) => n.remove()); const v = h.querySelector('.coll-motion'); if (v) { try { v.pause(); } catch {} v.removeAttribute('src'); v.remove(); }
}
async function collMotion(c, d) {
  collMotionClear();
  if (CFG.dataSaver) return;
  if (!c.id || !/^MPRE/.test(c.id) || !CFG.animArt || (typeof qualNow === 'function' && ['low', 'potato'].includes(qualNow())) || document.body.classList.contains('lite')) return;
  const parts = String(d.sub || c.sub || '').split(' • ').map((s) => s.trim()), artist = parts.find((s, i) => i > 0 && !/^\d{4}$/.test(s)) || '';
  try {
    const m = await apiGet('albummotion', { title: d.title || c.title, artist });
    const mv = m.tall || m.video; if (COLL.cur !== c) return;
    if (!mv) return genMotion(c, d);
    const tall = !!m.tall;
    const h = document.querySelector('#collBody .coll-hero'), v = document.createElement('video');
    v.className = 'coll-motion'; v.muted = true; v.loop = true; v.playsInline = true; v.setAttribute('playsinline', '');
    v.onloadeddata = () => { if (COLL.cur !== c) return; h.classList.add('mot'); v.classList.add('on'); v.play().catch(() => {}); };
    if (tall) h.classList.add('tall'); h.prepend(v); attachHls(v, mv).catch(() => v.remove());
  } catch { if (COLL.cur === c) genMotion(c, d); }
}
// sin ilustración animada de Apple: movimiento hecho por la app (zoom lento, deriva y un destello de luz sobre la portada)
function genMotion(c, d) {
  const h = document.querySelector('#collBody .coll-hero'); if (!h || COLL.cur !== c || h.querySelector('.coll-motion,.coll-gen')) return;
  let src = (d && d.cover) || c.cover || ''; if (!src || /^data:/.test(src)) return;
  src = src.replace(/=w\d+-h\d+[^"']*$/, '=w1200-h1200-l90-rj');
  const g = document.createElement('div'); g.className = 'coll-gen'; g.style.backgroundImage = `url("${src.replace(/"/g, '%22')}")`;
  const im = new Image(); im.onload = () => { if (COLL.cur !== c) return; h.classList.add('mot', 'genm'); g.classList.add('on'); }; im.src = src;
  h.prepend(g);
}
function paintColl(c) {
  collMotionClear();
  $('collTitle').textContent = c.title || ''; $('collSub').textContent = c.sub || '';
  if (c.isArtist) { styleArtist($('collTitle'), c.title); $('collTitle').style.fontSize = '34px'; } else { clearArtistStyle($('collTitle')); $('collTitle').style.fontSize = ''; }
  const cov = $('collCover'); cov.src = c.cover || makeCover(c.title || ''); cov.style.display = ''; cov.classList.toggle('round', !!c.isArtist);
  heroArt(c);
  $('collBg').style.setProperty('--c1', `hsl(${hue(c.title || '')} 55% 38%)`); $('coll').style.setProperty('--c1', `hsl(${hue(c.title || '')} 55% 38%)`);
  document.querySelectorAll('#collBody .coll-more-rails').forEach((n) => n.remove());
  if (c.loading || (c.id && !c.tracks)) $('collList').innerHTML = skel(6); else fillCollTracks(c);
  $('collConc').hidden = !c.isArtist; $('collStar').hidden = !c.isArtist; if (c.isArtist) paintStar();
  $('collMore').hidden = !c.isArtist && (!c.key || !c.key.startsWith('list:'));
  $('collAdd').hidden = !c.key || !c.key.startsWith('list:');
}
function fillCollTracks(c) {
  COLL.cur = Object.assign(COLL.cur || {}, c); const tracks = c.tracks || [];
  $('collTitle').textContent = c.title || ''; $('collSub').textContent = c.sub ? c.sub : tracks.length + ' canciones';
  if (c.cover) $('collCover').src = c.cover;
  heroArt(c); paintAlbumMeta(c, c.rawSub || c.sub);
  const isList = c.key && c.key.startsWith('list:'), lst = isList && LISTS.find((l) => 'list:' + l.id === c.key);
  const box = $('collList'); box.innerHTML = '';
  if (!tracks.length) { box.innerHTML = `<p class="empty-t">No hay canciones todavía.</p>${lst ? '<div class="empty-add"><button class="pill" data-act="coll-add">+ Añadir música</button></div>' : ''}`; return; }
  let rowsBox = box;
  if (c.isArtist) {
    const lt = document.createElement('div'); lt.id = 'artLatest'; box.append(lt);
    const ph = document.createElement('h3'); ph.className = 'pop-h'; ph.innerHTML = 'Top canciones <svg class="ic s"><use href="#i-chev"/></svg>'; box.append(ph);
    rowsBox = document.createElement('div'); rowsBox.className = 'top-pages'; box.append(rowsBox);
  }
  tracks.forEach((t, i) => rowsBox.append(trackRow(t, tracks, i, { noAlbum: !!c.id && !c.sections, remove: lst ? () => { lst.tracks = lst.tracks.filter((x) => tid(x) !== tid(t)); saveLists(); refreshLibViews(); } : c.key === 'likes' ? () => toggleLike(t) : null, removeLabel: c.key === 'likes' ? 'Quitar de Me gusta' : undefined })));
}
function rebuildColl() {
  const c = COLL.cur; if (!c) return;
  if (c.key === 'likes') c.tracks = LIKES; else if (c.key === 'dl') c.tracks = dlTracksSafe(); else if (c.key === 'mine') c.tracks = LIB;
  else if (c.key && c.key.startsWith('list:')) { const l = LISTS.find((x) => 'list:' + x.id === c.key); if (l) { c.tracks = l.tracks; c.title = l.name; } else return closeColl(); }
  fillCollTracks(c);
}
async function loadCollRemote(c) {
  try {
    const d = await apiGet('collection', { id: c.id });
    if (COLL.cur !== c) return;
    c.rawSub = d.sub; c.tracks = d.tracks; c.sections = d.sections; c.desc = d.desc; collMotion(c, d); if (!c.cover && d.cover) c.cover = d.cover;
    fillCollTracks({ title: d.title || c.title, sub: c.sub || d.sub, cover: c.cover || d.cover, tracks: d.tracks, sections: d.sections, isArtist: c.isArtist });
    if (c.isArtist) paintLatest(d.sections || []);
    if (d.sections && d.sections.length) {
      const wrap = document.createElement('div'); wrap.className = 'coll-more-rails'; $('collBody').append(wrap);
      shelfHTML(wrap, d.sections, 12);
    }
    if (c.isArtist && d.desc) {   // «Información»
      const w = document.querySelector('#collBody .coll-more-rails') || (() => { const x = document.createElement('div'); x.className = 'coll-more-rails'; $('collBody').append(x); return x; })();
      const box = document.createElement('section'); box.className = 'art-info'; const long = d.desc.length > 220;
      box.innerHTML = `<h2>Información</h2><p class="${long ? 'clamp' : ''}">${esc(d.desc)}</p>${long ? '<button class="more-t">MÁS</button>' : ''}`;
      const bt = box.querySelector('.more-t'); if (bt) bt.onclick = () => { box.querySelector('p').classList.remove('clamp'); bt.remove(); };
      w.append(box);
    }
  } catch (e) { $('collList').innerHTML = `<p class="empty-t">No pude abrir esta página (${esc(e.message)}).</p>`; }
}
function paintStar() {
  const c = COLL.cur, b = $('collStar'); if (!c || !b) return;
  const on = store.get('sf_follow', []).includes(mainArtist(c.title)); b.classList.toggle('on', on);
}
/* «último lanzamiento»: el primer álbum o sencillo de la página del artista, con botón Agregar (lo guarda como lista) */
function paintLatest(sections) {
  const box = $('artLatest'); if (!box) return;
  const s = sections.find((x) => /álbum|album|sencillo|single|lanzamiento/i.test(x.title || '') && x.items && x.items.length); if (!s) return;
  const it = s.items[0]; if (!it || !it.id) return;
  box.className = 'art-latest';
  box.innerHTML = `<button class="al-cv"><img src="${esc(it.cover || makeCover(it.title))}" alt=""></button><div class="al-tx"><small>${esc(it.sub || 'ÚLTIMO LANZAMIENTO')}</small><b>${esc(it.title)}</b><button class="al-add"><svg class="ic s"><use href="#i-plus"/></svg>Agregar</button></div>`;
  box.querySelector('.al-cv').onclick = () => openColl({ id: it.id, title: it.title, sub: it.sub || '', cover: it.cover });
  box.querySelector('b').onclick = box.querySelector('.al-cv').onclick;
  box.querySelector('.al-add').onclick = async (e) => {
    const bt = e.currentTarget; bt.disabled = true;
    try { const d = await apiGet('collection', { id: it.id }); if (!(d.tracks || []).length) throw new Error('vacío'); newList(it.title, d.tracks); refreshLibViews(); toast('Agregado a tu biblioteca'); bt.innerHTML = '✓ Agregado'; }
    catch { toast('No pude agregarlo'); bt.disabled = false; }
  };
}
function collTracks() { return (COLL.cur && COLL.cur.tracks) || []; }

/* ---------- cola ---------- */
function renderQueue() {
  if (S.queOpen) renderQueV();
  const box = $('queList'); if (!box || $('que').hidden) return;
  box.innerHTML = '';
  S.queue.forEach((t, i) => {
    const r = trackRow(t, S.queue, i, { noAlbum: true });
    r.onclick = (e) => { if (e.target.closest('.more')) { e.stopPropagation(); return trackMenu(t, { remove: () => { S.queue.splice(i, 1); if (i < S.i) S.i--; renderQueue(); } }); } haptic(6); load(i); renderQueue(); };
    box.append(r);
  });
  const cur = box.querySelector('.cur'); if (cur) cur.scrollIntoView({ block: 'center' });
}
function openQueue() { if (S.queOpen) return closeQueV(); if (S.npOpen) return openQueV(); openSheet('que'); renderQueue(); }
/* ---- cola dentro del reproductor (estilo Apple Music) ---- */
function openQueV() {
  if (S.lyrOpen) closeLyr();
  S.queOpen = true; document.body.classList.add('que-open'); $('btnQue').classList.add('on');
  requestAnimationFrame(() => { lyrLayout(); $('queV').classList.add('open'); renderQueV(); }); haptic(6);
}
function closeQueV() { S.queOpen = false; document.body.classList.remove('que-open'); const b = $('btnQue'); if (b) b.classList.remove('on'); $('queV').classList.remove('open'); positionVideo(); }
function qvRow(t, i, cur, up) {
  const r = trackRow(t, S.queue, i, { noAlbum: true });
  r.onclick = (e) => { if (e.target.closest('.qv-grip')) return; haptic(6); load(i); renderQueue(); };
  if (up) {
    const g = document.createElement('button'); g.className = 'qv-grip'; g.setAttribute('aria-label', 'Mover'); g.innerHTML = '<svg class="ic"><use href="#i-grip"/></svg>';
    g.addEventListener('pointerdown', (e) => qvDrag(e, r, i)); r.append(g);
  }
  return r;
}
function qvDrag(e, row, from) {
  e.preventDefault(); e.stopPropagation(); const box = $('qvList'), rows = [...box.querySelectorAll('.row.up')]; if (!rows.length) return;
  const y0 = e.clientY; let to = from; row.classList.add('drag'); try { e.target.setPointerCapture(e.pointerId); } catch (_) {}
  const mid = rows.map((r) => { const b = r.getBoundingClientRect(); return b.top + b.height / 2; });
  const mv = (ev) => { const dy = ev.clientY - y0; row.style.transform = `translateY(${dy}px)`; const y = mid[from - S.i - 1] + dy; let k = 0; mid.forEach((m, j) => { if (y > m) k = j; }); to = S.i + 1 + k; };
  const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up);
    if (to !== from) { const [t] = S.queue.splice(from, 1); S.queue.splice(to, 0, t); haptic(8); } renderQueV(); };
  window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
}
function renderQueV() {
  const box = $('qvList'); if (!box || !S.queOpen) return;
  const cur = S.queue[S.i]; if (cur) { $('qvT').textContent = cur.title; $('qvA').textContent = cur.artist || ''; $('qvCover').src = cur.cover || ''; }
  box.innerHTML = '';
  const hist = S.queue.slice(0, Math.max(0, S.i));
  const h = document.createElement('div'); h.className = 'qv-h'; h.innerHTML = '<b>Historial</b><button data-act="q-clear">Borrar</button>'; box.append(h);
  hist.forEach((t, i) => box.append(qvRow(t, i, false, false)));
  if (cur) { const r = qvRow(cur, S.i, true, false); r.classList.add('cur'); box.append(r); }
  const up = S.queue.slice(S.i + 1);
  const h2 = document.createElement('div'); h2.className = 'qv-h2'; h2.innerHTML = '<b>Seguir reproduciendo</b><small>' + (S.radioSeed ? 'Reproducir música similar automáticamente' : 'Lo que sigue en la cola') + '</small>'; box.append(h2);
  if (!up.length) { const e = document.createElement('p'); e.className = 'qv-empty'; e.textContent = 'No hay música en la fila'; box.append(e); }
  up.forEach((t, k) => { const r = qvRow(t, S.i + 1 + k, false, true); r.classList.add('up'); box.append(r); });
  $('qvInf').classList.toggle('on', !!S.radioSeed); $('qvShuf').classList.toggle('on', !!CFG.shuffle); $('qvRep').classList.toggle('on', !!CFG.repeat);
  $('qvRep').classList.toggle('one', CFG.repeat === 2);
  const c = box.querySelector('.cur'); if (c) box.scrollTop += c.getBoundingClientRect().top - box.getBoundingClientRect().top - h.offsetHeight - 4;
}

/* ---------- acciones de esta parte ---------- */
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  switch (b.dataset.act) {
    case 'close-coll': closeColl(); break;
    case 'coll-add': { const c = COLL.cur, l = c && LISTS.find((x) => 'list:' + x.id === c.key); if (l) openAddMusic(l); break; }
    case 'add-close': closeSheet('addm'); break;
    case 'mix-toggle': openMix(); break;
    case 'coll-save': { const c = COLL.cur, tr = collTracks(); if (!c || !tr.length) break; const ex = LISTS.find((l) => l.albumId === c.id); if (ex) { toast('Ya está en tu biblioteca'); break; } const l = newList(c.title, tr); l.albumId = c.id; saveLists(); haptic(10); toast('Álbum guardado en tu biblioteca'); break; }
    case 'coll-play': { const l = collTracks(); if (l.length) { haptic(10); play(l, 0); } break; }
    case 'coll-shuffle': { const l = collTracks().slice(); if (l.length) { for (let i = l.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [l[i], l[j]] = [l[j], l[i]]; } haptic(10); play(l, 0); } break; }
    case 'coll-star': { const c = COLL.cur; if (!c) break; const f = store.get('sf_follow', []), n = mainArtist(c.title), i = f.indexOf(n); if (i >= 0) f.splice(i, 1); else f.push(n); store.set('sf_follow', f); paintStar(); haptic(10); toast(i >= 0 ? 'Dejaste de seguir a ' + n : 'Sigues a ' + n); myArtKey = ''; paintMyArtists(); break; }
    case 'coll-conc': { const c = COLL.cur; if (!c) break; const u = 'https://www.google.com/search?q=' + encodeURIComponent(c.title + ' próximos conciertos'); if (window.Native && Native.openUrl) Native.openUrl(u); else window.open(u, '_blank'); break; }
    case 'coll-more': { const c = COLL.cur, l = c && LISTS.find((x) => 'list:' + x.id === c.key); if (l) listMenu(l); else if (c && c.isArtist) { const n = mainArtist(c.title), tr = collTracks(); openMenu({ title: c.title, sub: 'Artista', cover: c.cover }, [tr.length && { icon: 'radio', label: 'Radio del artista', run: () => startRadio(tr[0]) }, { icon: 'star', label: store.get('sf_follow', []).includes(n) ? 'Dejar de seguir' : 'Seguir', run: () => document.querySelector('[data-act=coll-star]').click() }]); } break; }
    case 'open-queue': openQueue(); break; case 'close-queue': if (S.queOpen) closeQueV(); else closeSheet('que'); break;
    case 'q-clear': if (S.i > 0) { S.queue.splice(0, S.i); S.i = 0; renderQueV(); } break;
    case 'q-inf': { const last = S.queue[S.queue.length - 1]; if (S.radioSeed) { S.radioSeed = null; toast('Música automática apagada'); } else if (last && last.videoId) { S.radioSeed = last.videoId; toast('Seguirá con música parecida'); } else toast('Esta canción no permite radio automática'); renderQueV(); break; }
    case 'news-refresh': loadNews(true); break;
    case 'page-menu': {
      const go = (sel) => () => document.querySelector(sel).click();
      openMenu({ title: 'Spotifree' }, [
        { icon: 'sliders', label: 'Ajustes e información', run: go('[data-act=open-set]') },
        { icon: 'user', label: 'Tu cuenta', run: go('[data-act=open-acc]') },
        NAV.tab === 'news' ? { icon: 'refresh', label: 'Actualizar novedades', run: () => loadNews(true) } : null,
        NAV.tab === 'lib' ? { icon: 'plus', label: 'Añadir música', run: go('[data-act=lib-add]') } : null,
      ]); break;
    }
    case 'lib-edit': libEdit = !libEdit; haptic(6); renderLib(); break;
    case 'lib-add': openMenu({ title: 'Añadir', sub: 'A tu biblioteca' }, [
      { icon: 'note', label: 'Música del teléfono', run: () => $('fileAudio').click() },
      { icon: 'dl', label: 'Descargar música libre', run: () => openDownloads('') },
      { icon: 'plus', label: 'Nueva lista', run: () => askText('Nueva lista', 'Nombre de la lista', '', (n) => { newList(n); toast('Lista creada'); }) },
    ]); break;
    case 'like': toggleLike(S.queue[S.i]); break;
    case 'track-menu': { const t = S.queue[S.i]; if (t) trackMenu(t, { np: true }); break; }
    case 'clear-q': recentQ = []; qHist = []; store.set('sf_qs', recentQ); store.set('sf_qh', qHist); renderRecentQ(); break;
  }
});

function onTabShow(name) {
  if (name === 'news') loadNews(); else if (name === 'radio') paintRadioNow(); else if (name === 'lib') renderLib(); else if (name === 'home') refreshHome();
}
function initViews() {
  initArtists(); initRadio(); renderCats(); renderRecentQ(); renderKinds(); refreshHome(); renderLib(); paintLike();
  $('tabbar').style.setProperty('--i', 0);
  loadHome();
}
// compatibilidad con el resto del código
const renderRecent = refreshHome;
document.addEventListener('error', (e) => { const im = e.target; if (im.tagName === 'IMG' && !im._fb && !/^data:/.test(im.src)) { im._fb = 1; const was = im.getAttribute('src'); im.src = makeCover(im.alt || im.src); im.classList.add('ld'); if (typeof restoreCover === 'function') restoreCover(im, was); } }, true);

/* ---------- añadir música a una lista ---------- */
let ADD = { l: null, tok: 0, t: 0 };
function addRow(t) {
  const l = ADD.l, has = () => l.tracks.some((x) => tid(x) === tid(t));
  const r = document.createElement('div'); r.className = 'row add-row';
  r.innerHTML = `<img class="cv" src="${esc(t.cover || makeCover(t.title + t.artist))}" alt="" decoding="async"><div class="tx"><b>${esc(t.title)}</b><small>${esc(t.artist || '')}${t.album ? ' · ' + esc(t.album) : ''}</small></div><button class="addbtn" aria-label="Añadir"></button>`;
  const btn = r.querySelector('.addbtn'), paint = () => { btn.innerHTML = `<svg class="ic s"><use href="#i-${has() ? 'check' : 'plus'}"/></svg>`; btn.classList.toggle('on', has()); };
  paint();
  r.onclick = () => { if (!has()) { l.tracks.push(slim(t)); saveLists(); refreshLibViews(); if (typeof rebuildColl === 'function') rebuildColl(); haptic(8); } paint(); };
  return r;
}
function fillAdd(list, head) { $('addH').textContent = head; $('addH').hidden = !head; const box = $('addList'); box.innerHTML = ''; if (!list.length) { box.innerHTML = '<p class="empty-t">Sin resultados.</p>'; return; } list.forEach((t) => box.append(addRow(t))); }
function addBase() { const seen = new Set(), out = []; [...LIKES, ...(typeof LIB !== 'undefined' ? LIB : []), ...recents()].forEach((t) => { const k = tid(t); if (!seen.has(k)) { seen.add(k); out.push(t); } }); return out; }
function openAddMusic(l) {
  ADD.l = l; $('addTitle').textContent = 'Añadir a «' + l.name + '»'; $('addQ').value = '';
  const base = addBase().filter((t) => !l.tracks.some((x) => tid(x) === tid(t))).slice(0, 40);
  fillAdd(base, base.length ? 'Tus Me gusta y recientes' : ''); if (!base.length) $('addList').innerHTML = '<p class="empty-t">Escribe arriba el nombre de una canción o artista.</p>';
  openSheet('addm');
}
$('addForm').addEventListener('submit', (e) => { e.preventDefault(); $('addQ').blur(); });
$('addQ').addEventListener('input', () => {
  clearTimeout(ADD.t); const q = $('addQ').value.trim(), my = ++ADD.tok;
  if (!q) return openAddMusic(ADD.l);
  const lc = q.toLowerCase(), loc = addBase().filter((t) => (t.title + ' ' + t.artist).toLowerCase().includes(lc)).slice(0, 6);
  fillAdd(loc, loc.length ? 'En tu música' : '');
  ADD.t = setTimeout(async () => {
    try { const d = await apiGet('search', { q, type: 'songs' }); if (my !== ADD.tok) return; const have = new Set(loc.map(tid)); fillAdd([...loc, ...(d.results || []).filter((t) => !have.has(tid(t)))].slice(0, 30), 'Resultados'); }
    catch { if (my === ADD.tok && !loc.length) $('addList').innerHTML = '<p class="empty-t">No pude buscar ahora.</p>'; }
  }, 280);
});

/* ---------- sugerencias al escribir en el buscador ---------- */
let SUG = { t: 0, tok: 0, cache: {} };
function boldRest(s, q) { const i = s.toLowerCase().startsWith(q.toLowerCase()) ? q.length : 0; return `${esc(s.slice(0, i))}<b>${esc(s.slice(i))}</b>`; }
$('q').addEventListener('input', () => {
  clearTimeout(SUG.t); const q = $('q').value.trim(), my = ++SUG.tok;
  if (!q) { $('sugg').hidden = true; return; }
  SUG.t = setTimeout(async () => {
    $('searchHome').hidden = true; $('searchRes').hidden = true; $('sugg').hidden = false;
    const paintList = (arr) => { if (my !== SUG.tok) return; const lc = q.toLowerCase(), items = [q, ...arr.filter((x) => x.toLowerCase() !== lc)].slice(0, 7);
      $('suggList').innerHTML = items.map((s) => `<button class="sug" data-q="${esc(s)}"><svg class="ic s"><use href="#i-search"/></svg><span>${boldRest(s, q)}</span></button>`).join(''); };
    paintList(SUG.cache[q] || []);
    apiGet('suggest', { q }).then((d) => { SUG.cache[q] = d.list || []; paintList(SUG.cache[q]); }).catch(() => {});
    apiGet('search', { q, type: 'songs' }).then((d) => {
      if (my !== SUG.tok) return; const list = (d.results || []).slice(0, 4); $('suggH').hidden = !list.length;
      const box = $('suggSongs'); box.innerHTML = ''; list.forEach((t, i) => box.append(trackRow(t, list, i, { noAlbum: false })));
    }).catch(() => {});
  }, 170);
});
$('suggList').addEventListener('click', (e) => { const b = e.target.closest('.sug'); if (!b) return; $('q').value = b.dataset.q; haptic(5); search(b.dataset.q); });
