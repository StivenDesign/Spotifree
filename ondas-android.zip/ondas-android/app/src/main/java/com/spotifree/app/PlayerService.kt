package com.spotifree.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Controles nativos de Android: notificación multimedia, pantalla de bloqueo y auriculares.
 * Mantiene viva la reproducción con la pantalla apagada. Los botones se reenvían a la página
 * por medio de [onCommand].
 */
class PlayerService : Service() {
    companion object {
        @Volatile var running = false
        var onCommand: ((String, Long) -> Unit)? = null
        private const val CH = "spotifree_playback"
    }

    private var session: MediaSession? = null
    private var wake: PowerManager.WakeLock? = null
    private var art: Bitmap? = null
    private var artFor = ""
    private val ui = Handler(Looper.getMainLooper())
    private var last: List<Any> = emptyList()

    /** Descarga (o decodifica) la portada sin bloquear la pantalla y vuelve a pintar la notificación cuando llega. */
    private fun loadArt(cover: String) {
        if (cover == artFor) return
        artFor = cover
        if (cover.isEmpty()) { art = null; return }
        Thread {
            val bmp: Bitmap? = try {
                val raw: Bitmap? = if (cover.startsWith("data:")) {
                    val b = Base64.decode(cover.substringAfter(","), Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(b, 0, b.size)
                } else {
                    val c = URL(cover).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    c.inputStream.use { BitmapFactory.decodeStream(it) }
                }
                if (raw != null && raw.width > 600) Bitmap.createScaledBitmap(raw, 600, 600 * raw.height / raw.width, true) else raw
            } catch (e: Exception) { null }
            ui.post {
                if (artFor == cover) {
                    art = bmp
                    if (last.size == 5) update(last[0] as String, last[1] as String, last[2] as Boolean, last[3] as Long, last[4] as Long)
                }
            }
        }.start()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Reproducción", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "Spotifree").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = send("play", 0)
                override fun onPause() = send("pause", 0)
                override fun onSkipToNext() = send("next", 0)
                override fun onSkipToPrevious() = send("prev", 0)
                override fun onSeekTo(pos: Long) = send("seek", pos)
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action ?: ""
        if (act == "play" || act == "pause" || act == "next" || act == "prev") {
            send(act, 0)
            return START_NOT_STICKY
        }
        loadArt(intent?.getStringExtra("cover") ?: "")
        update(
            intent?.getStringExtra("title") ?: "Spotifree",
            intent?.getStringExtra("artist") ?: "",
            intent?.getBooleanExtra("playing", false) ?: false,
            intent?.getLongExtra("pos", 0L) ?: 0L,
            intent?.getLongExtra("dur", 0L) ?: 0L
        )
        return START_NOT_STICKY
    }

    private fun send(cmd: String, arg: Long) { onCommand?.invoke(cmd, arg) }

    private fun action(icon: Int, label: String, act: String, code: Int): Notification.Action =
        Notification.Action.Builder(
            Icon.createWithResource(this, icon), label,
            PendingIntent.getService(this, code, Intent(this, PlayerService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE)
        ).build()

    private fun update(title: String, artist: String, playing: Boolean, pos: Long, dur: Long) {
        last = listOf(title, artist, playing, pos, dur)
        val meta = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
        if (dur > 0) meta.putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
        art?.let { meta.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it).putBitmap(MediaMetadata.METADATA_KEY_ART, it) }
        session?.setMetadata(meta.build())
        session?.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
                )
                .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, pos, if (playing) 1f else 0f)
                .build()
        )

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(artist)
            .setLargeIcon(art)
            .setContentIntent(open)
            .setOngoing(playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(android.R.drawable.ic_media_previous, "Anterior", "prev", 1))
            .addAction(
                if (playing) action(android.R.drawable.ic_media_pause, "Pausar", "pause", 2)
                else action(android.R.drawable.ic_media_play, "Reproducir", "play", 2)
            )
            .addAction(action(android.R.drawable.ic_media_next, "Siguiente", "next", 3))
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notification)
        }

        // con la pantalla apagada, el procesador sigue despierto solo mientras suena
        if (playing) {
            if (wake == null) wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "spotifree:playback")
            if (wake?.isHeld != true) wake?.acquire(4 * 60 * 60 * 1000L)
        } else if (wake?.isHeld == true) {
            wake?.release()
        }
    }

    /** Al quitar la app de recientes se acaba todo: notificación, reproducción y proceso. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        try { stopForeground(true) } catch (e: Exception) {}
        stopSelf()
        android.os.Process.killProcess(android.os.Process.myPid())
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        if (wake?.isHeld == true) wake?.release()
        session?.release()
        super.onDestroy()
    }
}
