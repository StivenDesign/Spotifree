plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.spotifree.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.spotifree.app"
        minSdk = 24
        targetSdk = 34
        // sube con cada compilación de GitHub para que Android deje actualizar encima de la anterior
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.7 Beta"
    }
    // misma firma en todas las compilaciones: así cada APK se instala como actualización sin desinstalar
    signingConfigs {
        create("fija") {
            storeFile = file("debug.keystore")
            storePassword = "spotifree"
            keyAlias = "spotifree"
            keyPassword = "spotifree"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fija") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.webkit:webkit:1.11.0")
}
