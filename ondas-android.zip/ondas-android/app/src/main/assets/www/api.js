// Versión para Android de las rutas /api del servidor: las peticiones salen por el puente nativo (sin CORS).
(function () {
  const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  /* ---------- puente nativo ---------- */
  const pending = {};
  let counter = 0;
  window.__nativeDone = (id, status, body) => {
    const p = pending[id];
    if (!p) return;
    delete pending[id];
    p(status, body);
  };
  function getJSON(url, { method = 'GET', headers = {}, body = '' } = {}) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => {
        if (status <= 0) return reject(new Error(text || 'Sin conexión'));
        if (status >= 400) return reject(new Error(new URL(url).host + ' respondió ' + status));
        try { resolve(JSON.parse(text)); } catch { reject(new Error('Respuesta no válida de ' + new URL(url).host)); }
      };
      Native.request(id, method, url, JSON.stringify({ 'User-Agent': UA, ...headers }), body);
    });
  }

  function getText(url, headers = {}) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => (status <= 0 || status >= 400 ? reject(new Error(new URL(url).host + ' respondió ' + status)) : resolve(text));
      Native.request(id, 'GET', url, JSON.stringify({ 'User-Agent': UA, ...headers }), '');
    });
  }
  // Descarga una imagen como data: URL (sin CORS) para usarla en WebGL.
  function getImageData(url) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => {
        if (status <= 0 || status >= 400) return reject(new Error('Imagen no disponible'));
        const i = text.indexOf('|');
        resolve('data:' + text.slice(0, i) + ';base64,' + text.slice(i + 1));
      };
      Native.requestBytes(id, url);
    });
  }
  // Portada en movimiento: video animado que Apple Music publica en la página pública del álbum.
  async function appleMotion(albumId) {
    if (!/^\d+$/.test(albumId)) throw new Error('Álbum no válido');
    const html = await getText(`https://music.apple.com/us/album/${albumId}`, { 'Accept-Language': 'en-US,en;q=0.9' });
    const m = html.match(/"(?:motionDetailSquare|motionSquareVideo1x1)"\s*:\s*\{\s*"video"\s*:\s*"([^"]+)"/);
    return { video: m ? m[1].replace(/\\\//g, '/').replace(/\\u0026/g, '&') : '' };
  }

  /* ---------- utilidades ---------- */
  const decodeEntities = (s) =>
    s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'");
  function parseTime(s) {
    if (!s) return 0;
    s = String(s).trim();
    if (s.endsWith('s')) return parseFloat(s);
    return s.split(':').map(parseFloat).reduce((a, v) => a * 60 + v, 0);
  }
  const parseDuration = (s) => (s ? String(s).split(':').map(Number).reduce((a, v) => a * 60 + v, 0) : 0);
  const enc = encodeURIComponent;

  /* ---------- YouTube Music ---------- */
  const YTM_CONTEXT = { client: { clientName: 'WEB_REMIX', clientVersion: '1.20250210.03.00', hl: 'es', gl: 'US' } };
  const SONGS_FILTER = 'EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D';
  const VIDEOS_FILTER = 'EgWKAQIQAWoKEAkQBRAKEAMQBA%3D%3D';
  function bestThumb(thumbs = []) {
    const t = thumbs[thumbs.length - 1];
    return t ? t.url.replace(/=w\d+-h\d+[^"]*$/, '=w800-h800-l90-rj').replace(/=s\d+/, '=s800') : '';
  }
  async function ytmSearch(q, type) {
    const videos = type === 'videos';
    const data = await getJSON('https://music.youtube.com/youtubei/v1/search?prettyPrint=false', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://music.youtube.com', Referer: 'https://music.youtube.com/' },
      body: JSON.stringify({ context: YTM_CONTEXT, query: q, params: videos ? VIDEOS_FILTER : SONGS_FILTER }),
    });
    const shelves = [];
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      if (n.musicShelfRenderer) shelves.push(n.musicShelfRenderer);
      for (const k in n) walk(n[k]);
    };
    walk(data.contents);
    const out = [];
    for (const shelf of shelves) {
      for (const item of shelf.contents || []) {
        const r = item.musicResponsiveListItemRenderer;
        if (!r) continue;
        const videoId =
          r.playlistItemData?.videoId ||
          r.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
        if (!videoId) continue;
        const cols = r.flexColumns || [];
        const title = cols[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.[0]?.text || '';
        const runs = (cols[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || []).map((x) => x.text);
        const parts = runs.join('').split(' • ').map((s) => s.trim()).filter(Boolean);
        const clean = parts[0] && /^(canción|song|video)$/i.test(parts[0]) ? parts.slice(1) : parts;
        const durStr = clean.find((s) => /^\d+:\d{2}(:\d{2})?$/.test(s)) || '';
        out.push({
          videoId, title,
          artist: clean[0] || '',
          album: !videos && clean[1] && clean[1] !== durStr ? clean[1] : '',
          duration: parseDuration(durStr),
          cover: bestThumb(r.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails),
        });
      }
    }
    return out;
  }

  /* Elige el resultado que de verdad es esa canción: mismo título, mismo artista y duración parecida. Si ninguno encaja, no devuelve nada. */
  const nrmM = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/\b(feat|ft|with|con)\b.*$/, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
  const VER = /\b(remix|live|en vivo|instrumental|karaoke|acoustic|acustica|sped|slowed|cover|version)\b/;
  function matchScore(want, got) {
    const wt = nrmM(want.title), gt = nrmM(got.title), wa = nrmM(want.artist), ga = nrmM(got.artist);
    let s = 0;
    if (wt && gt === wt) s += 4; else if (wt && gt && (gt.includes(wt) || wt.includes(gt))) s += 1; else return -1;
    if (wa) { const first = wa.split(' y | e | and | x ')[0].trim(); if (ga.includes(first) || first.includes(ga) || wa.split(' ').some((w) => w.length > 3 && ga.includes(w))) s += 4; else return -1; }
    if (VER.test(gt) && !VER.test(wt)) s -= 4;
    if (want.duration && got.duration && Math.abs(want.duration - got.duration) <= 5) s += 2; else if (want.duration && got.duration && Math.abs(want.duration - got.duration) > 25) s -= 3;
    if (want.album && got.album && nrmM(want.album) === nrmM(got.album)) s += 2;
    return s;
  }
  function bestMatch(list, want) {
    let best = null, bs = 3;
    for (const g of list) { const s = matchScore(want, g); if (s > bs) { bs = s; best = g; } }
    return best;
  }
  async function hiresCover(title, artist, duration, album) {
    const d = await getJSON(`https://itunes.apple.com/search?media=music&entity=song&limit=12&term=${enc(artist + ' ' + title)}`);
    const hit = bestMatch((d.results || []).map((r) => ({ r, title: r.trackName, artist: r.artistName, album: r.collectionName, duration: Math.round((r.trackTimeMillis || 0) / 1000) })), { title, artist, duration, album })?.r;
    if (!hit) return { cover: '' };
    return { cover: hit.artworkUrl100.replace('100x100bb', '1400x1400bb'), appleId: String(hit.trackId), albumId: hit.collectionId ? String(hit.collectionId) : '' };
  }

  /* ---------- letras ---------- */
  function parseLRC(text) {
    const lines = [];
    for (const raw of text.split(/\r?\n/)) {
      const m = raw.match(/^((?:\[\d+:\d+(?:[.:]\d+)?\])+)(.*)$/);
      if (!m) continue;
      const txt = m[2].replace(/<\d+:\d+(?:\.\d+)?>/g, '').trim();
      for (const t of m[1].matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)) {
        lines.push({ time: parseInt(t[1], 10) * 60 + parseFloat(t[2].replace(':', '.')), text: txt });
      }
    }
    return lines.sort((a, b) => a.time - b.time);
  }
  function parseTTML(ttml) {
    const lines = [];
    for (const p of ttml.matchAll(/<p\b([^>]*)>([\s\S]*?)<\/p>/g)) {
      const begin = /begin="([^"]+)"/.exec(p[1]);
      const end = /end="([^"]+)"/.exec(p[1]);
      const agent = (/ttm:agent="([^"]+)"/.exec(p[1]) || [])[1] || '';
      if (!begin) continue;
      const words = [];
      for (const s of p[2].matchAll(/<span\b([^>]*)>([\s\S]*?)<\/span>/g)) {
        const sb = /begin="([^"]+)"/.exec(s[1]);
        if (!sb) continue;
        const txt = decodeEntities(s[2].replace(/<[^>]+>/g, ''));
        if (txt.trim() === '') continue;
        words.push({ t: parseTime(sb[1]), text: txt });
      }
      const text = decodeEntities(p[2].replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
      lines.push({ time: parseTime(begin[1]), end: end ? parseTime(end[1]) : undefined, text, agent, words: words.length > 1 ? words : undefined });
    }
    return lines;
  }

  // Quita (feat. …), [Remastered], "- Remix"… para que los buscadores encuentren la canción
  function cleanTitle(t) {
    return String(t || '').replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/\s[-–—]\s.*$/, ' ').replace(/\b(feat|ft)\.?\s.*$/i, ' ').replace(/\s+/g, ' ').trim() || String(t || '');
  }
  const providers = {
    async betterlyrics({ title, artist, duration }) {
      const d = await getJSON(`https://lyrics-api.boidu.dev/getLyrics?s=${enc(title)}&a=${enc(artist)}${duration ? '&d=' + duration : ''}`);
      const ttml = d.ttml || d.lyrics || '';
      if (!ttml) throw new Error('Sin letra en Better Lyrics');
      const lines = parseTTML(ttml);
      if (!lines.length) throw new Error('Respuesta de Better Lyrics sin líneas');
      return { provider: 'betterlyrics', synced: true, lines };
    },
    async kugou({ title, artist, duration }) {
      const q = `${artist} ${title}`;
      const s = await getJSON(`https://mobilecdn.kugou.com/api/v3/search/song?format=json&page=1&pagesize=5&keyword=${enc(q)}`);
      const song = s.data?.info?.[0];
      if (!song) throw new Error('KuGou no encontró la canción');
      const c = await getJSON(`https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=${enc(q)}&duration=${(duration || song.duration || 0) * 1000}&hash=${song.hash}`);
      const cand = c.candidates?.[0];
      if (!cand) throw new Error('KuGou no tiene letra');
      const d = await getJSON(`https://lyrics.kugou.com/download?ver=1&client=pc&id=${cand.id}&accesskey=${cand.accesskey}&fmt=lrc&charset=utf8`);
      const bytes = Uint8Array.from(atob(d.content || ''), (ch) => ch.charCodeAt(0));
      const lrc = new TextDecoder('utf-8').decode(bytes);
      const lines = parseLRC(lrc).filter((l) => !/^\s*(ti|ar|al|by|offset)\s*:/i.test(l.text));
      if (!lines.length) throw new Error('KuGou devolvió letra vacía');
      return { provider: 'kugou', synced: true, lines };
    },
    // Apple Music: pega tus tokens en Ajustes de la app (se guardan solo en este teléfono).
    async apple({ title, artist, appleId, duration }) {
      let cfg = {};
      try { cfg = JSON.parse(localStorage.getItem('ondas_apple') || '{}'); } catch {}
      if (!cfg.dev || !cfg.user) throw new Error('Faltan los tokens de Apple Music');
      const sf = cfg.storefront || 'us';
      const headers = { Authorization: 'Bearer ' + cfg.dev, 'Music-User-Token': cfg.user, Origin: 'https://music.apple.com' };
      let id = appleId;
      if (!id) {
        const s = await getJSON(`https://amp-api.music.apple.com/v1/catalog/${sf}/search?types=songs&limit=8&term=${enc(artist + ' ' + title)}`, { headers });
        id = bestMatch((s.results?.songs?.data || []).map((x) => ({ id: x.id, title: x.attributes?.name, artist: x.attributes?.artistName, duration: Math.round((x.attributes?.durationInMillis || 0) / 1000) })), { title, artist, duration })?.id;
      }
      if (!id) throw new Error('Apple Music no encontró la canción');
      const d = await getJSON(`https://amp-api.music.apple.com/v1/catalog/${sf}/songs/${id}/syllable-lyrics`, { headers });
      const ttml = d.data?.[0]?.attributes?.ttml;
      if (!ttml) throw new Error('Apple Music sin letra para esta canción');
      return { provider: 'apple', synced: true, lines: parseTTML(ttml) };
    },
    // NetEase (música 163): letras sincronizadas, sin cuenta ni clave
    async netease({ title, artist, duration }) {
      const H = { Referer: 'https://music.163.com/', Cookie: 'appver=2.0.2' };
      const s = await getJSON(`https://music.163.com/api/search/get/web?csrf_token=&s=${enc(artist + ' ' + title)}&type=1&offset=0&total=true&limit=10`, { headers: H });
      const song = bestMatch((s.result?.songs || []).map((x) => ({ x, title: x.name, artist: (x.artists || []).map((a) => a.name).join(' '), duration: Math.round((x.duration || 0) / 1000) })), { title, artist, duration })?.x;
      if (!song) throw new Error('NetEase no encontró la canción');
      const d = await getJSON(`https://music.163.com/api/song/lyric?id=${song.id}&lv=1&kv=1&tv=-1`, { headers: H });
      const lines = parseLRC(d.lrc?.lyric || '').filter((l) => l.text && !/^\s*(作词|作曲|编曲|制作|ti|ar|al|by|offset)\s*[:：]/i.test(l.text));
      if (!lines.length) throw new Error('NetEase sin letra sincronizada');
      return { provider: 'netease', synced: true, lines };
    },
    // QQ Música: letras sincronizadas
    async qq({ title, artist, duration }) {
      const H = { Referer: 'https://y.qq.com/', Origin: 'https://y.qq.com' };
      const s = await getJSON(`https://c.y.qq.com/soso/fcgi-bin/client_search_cp?format=json&new_json=1&n=10&p=1&w=${enc(artist + ' ' + title)}`, { headers: H });
      const song = bestMatch((s.data?.song?.list || []).map((x) => ({ x, title: x.name, artist: (x.singer || []).map((a) => a.name).join(' '), duration: x.interval || 0 })), { title, artist, duration })?.x;
      if (!song) throw new Error('QQ Música no encontró la canción');
      const d = await getJSON(`https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid=${song.mid}&format=json&g_tk=5381`, { headers: H });
      if (!d.lyric) throw new Error('QQ Música sin letra');
      const lrc = new TextDecoder('utf-8').decode(Uint8Array.from(atob(d.lyric), (ch) => ch.charCodeAt(0)));
      const lines = parseLRC(lrc.replace(/&apos;/g, "'").replace(/&amp;/g, '&')).filter((l) => l.text && !/^\s*(词|曲|ti|ar|al|by|offset)\s*[:：]/i.test(l.text));
      if (!lines.length) throw new Error('QQ Música sin letra sincronizada');
      return { provider: 'qq', synced: true, lines };
    },
    // Lyrics.ovh: solo texto (sin sincronizar), útil como último recurso
    async ovh({ title, artist }) {
      const d = await getJSON(`https://api.lyrics.ovh/v1/${enc(artist.split(/,|&| feat/i)[0].trim())}/${enc(title.replace(/\(.*?\)|\[.*?\]/g, '').trim())}`);
      const txt = String(d.lyrics || '').replace(/\r/g, '').trim();
      if (!txt) throw new Error('Lyrics.ovh sin letra');
      return { provider: 'ovh', synced: false, lines: txt.split('\n').map((text) => ({ time: 0, text })) };
    },
    async lrclib({ title, artist, duration }) {
      let d;
      try {
        d = await getJSON(`https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}${duration ? '&duration=' + duration : ''}`);
      } catch {
        const all = await getJSON(`https://lrclib.net/api/search?q=${enc(artist + ' ' + title)}`);
        d = bestMatch(all.map((x) => ({ x, title: x.trackName, artist: x.artistName, duration: Math.round(x.duration || 0), album: x.albumName })), { title, artist, duration })?.x;
      }
      if (!d) throw new Error('LRCLIB no encontró la canción');
      if (d.syncedLyrics) return { provider: 'lrclib', synced: true, lines: parseLRC(d.syncedLyrics) };
      if (d.plainLyrics) return { provider: 'lrclib', synced: false, lines: d.plainLyrics.split('\n').map((text) => ({ time: 0, text })) };
      throw new Error('LRCLIB sin letra');
    },

    // LRCLIB, búsqueda amplia: título limpio, solo resultados con letra sincronizada y duración parecida
    async lrclibx({ title, artist, duration }) {
      const t = cleanTitle(title), a = String(artist || '').split(/,|&| feat\.?| x /i)[0].trim();
      const urls = [`https://lrclib.net/api/search?track_name=${enc(t)}&artist_name=${enc(a)}`, `https://lrclib.net/api/search?q=${enc(t + ' ' + a)}`, `https://lrclib.net/api/search?q=${enc(t)}`];
      for (const u of urls) {
        let all = []; try { all = await getJSON(u); } catch { continue; }
        const cand = (all || []).filter((x) => x.syncedLyrics && (!duration || !x.duration || Math.abs(x.duration - duration) <= 6));
        const hit = bestMatch(cand.map((x) => ({ x, title: x.trackName, artist: x.artistName, duration: Math.round(x.duration || 0), album: x.albumName })), { title: t, artist: a, duration })?.x || (cand.length === 1 ? cand[0] : null);
        if (hit) { const lines = parseLRC(hit.syncedLyrics); if (lines.length) return { provider: 'lrclibx', synced: true, lines }; }
      }
      throw new Error('LRCLIB no tiene versión sincronizada');
    },
    // SimpMusic: comunidad que comparte letras sincronizadas por videoId de YouTube
    async simp({ videoId }) {
      if (!videoId) throw new Error('Solo para canciones de YouTube');
      const d = await getJSON(`https://api-lyrics.simpmusic.org/v1/${enc(videoId)}`);
      const arr = Array.isArray(d.data) ? d.data : d.data ? [d.data] : [];
      const hit = arr.find((x) => x.syncedLyrics) || null;
      if (!hit) throw new Error('SimpMusic sin letra sincronizada');
      const lines = parseLRC(hit.syncedLyrics);
      if (!lines.length) throw new Error('SimpMusic devolvió letra vacía');
      return { provider: 'simp', synced: true, lines };
    },
    // Subtítulos de YouTube (si el video los tiene): sincronizados por tiempo
    async ytcaps({ videoId }) {
      if (!videoId) throw new Error('Solo para canciones de YouTube');
      const d = await getJSON('https://www.youtube.com/youtubei/v1/player?prettyPrint=false', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': 'com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip' },
        body: JSON.stringify({ context: { client: { clientName: 'ANDROID', clientVersion: '20.10.38', androidSdkVersion: 34, hl: 'es', gl: 'US' } }, videoId, contentCheckOk: true, racyCheckOk: true }),
      });
      const tracks = d.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
      if (!tracks.length) throw new Error('El video no tiene subtítulos');
      const tr = tracks.find((x) => x.kind !== 'asr') || tracks[0];
      const j = await getJSON(tr.baseUrl.replace(/&fmt=[^&]*/, '') + '&fmt=json3');
      const lines = (j.events || []).filter((e) => e.segs && e.tStartMs != null).map((e) => ({ time: e.tStartMs / 1000, end: (e.tStartMs + (e.dDurationMs || 0)) / 1000, text: e.segs.map((x) => x.utf8).join('').replace(/\s+/g, ' ').trim() })).filter((l) => l.text && !/^[\[\(♪].*[\]\)♪]$/.test(l.text));
      if (lines.length < 4) throw new Error('Subtítulos insuficientes');
      return { provider: 'ytcaps', synced: true, lines };
    },
  };

  /* ---------- YouTube Music: inicio, novedades, colecciones y radio ---------- */
  const ytm = (ep, payload) =>
    getJSON(`https://music.youtube.com/youtubei/v1/${ep}?prettyPrint=false`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://music.youtube.com', Referer: 'https://music.youtube.com/' },
      body: JSON.stringify({ context: YTM_CONTEXT, ...payload }),
    });
  const runsText = (r) => (r?.runs || []).map((x) => x.text).join('');
  function parseTwoRow(r) {
    const nav = r.navigationEndpoint || {};
    const title = runsText(r.title), sub = runsText(r.subtitle);
    const cover = bestThumb(r.thumbnailRenderer?.musicThumbnailRenderer?.thumbnail?.thumbnails);
    const be = nav.browseEndpoint?.browseId, vid = nav.watchEndpoint?.videoId, pl = nav.watchEndpoint?.playlistId;
    if (vid) return { kind: 'song', videoId: vid, title, artist: sub.replace(/^(Canción|Song|Video)\s*•\s*/i, '').split(' • ')[0], cover, duration: 0 };
    if (!be) return pl ? { kind: 'playlist', id: 'VL' + pl, title, sub, cover } : null;
    const kind = be.startsWith('MPRE') ? 'album' : be.startsWith('UC') ? 'artist' : 'playlist';
    return { kind, id: be, title, sub, cover };
  }
  function parseListItem(r, fb = {}) {
    const videoId = r.playlistItemData?.videoId || r.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
    if (!videoId) return null;
    const cols = r.flexColumns || [];
    const title = runsText(cols[0]?.musicResponsiveListItemFlexColumnRenderer?.text);
    const runs = (cols[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || []).map((x) => x.text).filter((x) => x.trim() !== '•');
    const durTxt = runsText(r.fixedColumns?.[0]?.musicResponsiveListItemFixedColumnRenderer?.text) || runs.find((s) => /^\d+:\d{2}(:\d{2})?$/.test(s)) || '';
    const cover = bestThumb(r.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails) || fb.cover || '';
    const first = runs[0] && !/^\d+:\d{2}/.test(runs[0]) ? runs[0] : '';
    return { kind: 'song', videoId, title, artist: first || fb.artist || '', album: fb.album || '', duration: parseDuration(durTxt), cover };
  }
  function sectionsFrom(data, fb) {
    const out = [];
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      const sh = n.musicCarouselShelfRenderer || n.musicShelfRenderer || n.musicPlaylistShelfRenderer;
      if (sh) {
        const title = runsText(sh.header?.musicCarouselShelfBasicHeaderRenderer?.title) || runsText(sh.title) || '';
        const items = [];
        for (const c of sh.contents || []) {
          const it = c.musicTwoRowItemRenderer ? parseTwoRow(c.musicTwoRowItemRenderer) : c.musicResponsiveListItemRenderer ? parseListItem(c.musicResponsiveListItemRenderer, fb) : null;
          if (it) items.push(it);
        }
        if (items.length) out.push({ title, items });
        return;
      }
      for (const k in n) walk(n[k]);
    };
    walk(data.contents);
    return out;
  }
  function headerFrom(data) {
    const h = data.header || {};
    let node = h.musicDetailHeaderRenderer || h.musicImmersiveHeaderRenderer || h.musicVisualHeaderRenderer || null;
    if (!node) {
      const find = (n) => { if (!n || typeof n !== 'object') return null; if (n.musicResponsiveHeaderRenderer) return n.musicResponsiveHeaderRenderer; for (const k in n) { const r = find(n[k]); if (r) return r; } return null; };
      node = find(data.contents) || find(data.header);
    }
    node = node || {};
    let thumbs; const f = (n) => { if (thumbs || !n || typeof n !== 'object') return; if (Array.isArray(n.thumbnails)) { thumbs = n.thumbnails; return; } for (const k in n) f(n[k]); }; f(node);
    return { title: runsText(node.title), sub: runsText(node.subtitle) || runsText(node.straplineTextOne), cover: bestThumb(thumbs) };
  }
  async function ytmBrowse(id) { return sectionsFrom(await ytm('browse', { browseId: id })); }
  async function ytmNews() {
    const ids = ['FEmusic_new_releases_albums', 'FEmusic_explore'];
    const res = await Promise.allSettled(ids.map(ytmBrowse));
    const sections = res.flatMap((r) => (r.status === 'fulfilled' ? r.value : []));
    if (!sections.length) throw new Error('YouTube Music no devolvió novedades');
    return sections;
  }
  async function ytmCollection(id) {
    const data = await ytm('browse', { browseId: id });
    const h = headerFrom(data), parts = h.sub.split(' • ').map((s) => s.trim());
    const fb = { cover: h.cover, artist: parts.find((s, i) => i > 0 && !/^\d{4}$/.test(s)) || parts[0] || '', album: id.startsWith('MPRE') ? h.title : '' };
    const sections = sectionsFrom(data, fb);
    const tracks = []; const seen = new Set();
    for (const s of sections) for (const it of s.items) if (it.kind === 'song' && !seen.has(it.videoId)) { seen.add(it.videoId); tracks.push(it); }
    return { ...h, tracks, sections: sections.filter((s) => s.items.some((i) => i.kind !== 'song')) };
  }
  async function ytmRadio(videoId) {
    const d = await ytm('next', { videoId, playlistId: 'RDAMVM' + videoId, params: 'wAEB', isAudioOnly: true });
    const out = [], seen = new Set();
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      const r = n.playlistPanelVideoRenderer;
      if (r) {
        if (!seen.has(r.videoId)) {
          seen.add(r.videoId);
          const by = (r.longBylineText?.runs || []).map((x) => x.text).filter((x) => x.trim() !== '•');
          out.push({ kind: 'song', videoId: r.videoId, title: runsText(r.title), artist: by[0] || '', album: by[1] || '', duration: parseDuration(r.lengthText?.runs?.[0]?.text || ''), cover: bestThumb(r.thumbnail?.thumbnails) });
        }
        return;
      }
      for (const k in n) walk(n[k]);
    };
    walk(d.contents);
    return out;
  }

  /* ---------- foto del artista (Deezer, API pública) ---------- */
  const nrm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  async function artistInfo(name) {
    const d = await getJSON(`https://api.deezer.com/search/artist?q=${enc(name)}&limit=5`);
    const list = d.data || [], q = nrm(name);
    // solo se acepta el mismo nombre (o uno que lo contenga) para no mostrar la foto de otra persona
    const hit = list.find((x) => nrm(x.name) === q) || list.find((x) => { const n = nrm(x.name); return n && (n.includes(q) || q.includes(n)); });
    if (!hit) return {};
    const pic = hit.picture_xl || hit.picture_big || hit.picture_medium || '';
    return { name: hit.name, picture: /\/artist\/\//.test(pic) ? '' : pic, fans: hit.nb_fan || 0 };
  }

  /* ---------- fuentes de descarga con licencia libre ---------- */
  async function iaSearch(q, free) {
    let query = `(${q}) AND mediatype:audio`;
    if (free) query += ' AND (licenseurl:*creativecommons* OR licenseurl:*publicdomain*)';
    const d = await getJSON(`https://archive.org/advancedsearch.php?q=${enc(query)}&fl[]=identifier&fl[]=title&fl[]=creator&rows=25&sort[]=downloads+desc&output=json`);
    return (d.response?.docs || []).map((x) => ({
      kind: 'ia', id: x.identifier, title: x.title || x.identifier, artist: [].concat(x.creator || '')[0] || 'Internet Archive',
      cover: `https://archive.org/services/img/${x.identifier}`,
    }));
  }
  async function iaFiles(id) {
    const d = await getJSON(`https://archive.org/metadata/${enc(id)}`);
    const meta = d.metadata || {};
    const artist = [].concat(meta.creator || '')[0] || 'Internet Archive', album = [].concat(meta.title || '')[0] || id;
    const seen = new Set();
    return (d.files || []).filter((f) => /\.mp3$/i.test(f.name) && f.source !== 'derivative' || /VBR MP3/i.test(f.format || '')).filter((f) => !seen.has(f.name) && seen.add(f.name)).slice(0, 60).map((f) => ({
      kind: 'dl', title: (f.title || f.name.replace(/\.[^.]+$/, '')).replace(/^\d+\s*[-.]\s*/, ''), artist: f.creator || artist, album,
      duration: parseFloat(f.length) || 0, size: +f.size || 0, url: `https://archive.org/download/${enc(id)}/${f.name.split('/').map(enc).join('/')}`,
      cover: `https://archive.org/services/img/${id}`, license: meta.licenseurl || 'Internet Archive', src: 'Internet Archive', free: true, stream: true,
    }));
  }
  async function jamendoSearch(q, key) {
    if (!key) throw new Error('Falta el Client ID de Jamendo');
    const d = await getJSON(`https://api.jamendo.com/v3.0/tracks/?client_id=${enc(key)}&format=json&limit=30&namesearch=${enc(q)}&audiodownload_allowed=true&include=musicinfo&order=popularity_total`);
    if (d.headers && d.headers.status === 'failed') throw new Error(d.headers.error_message || 'Jamendo rechazó la petición');
    return (d.results || []).filter((r) => r.audiodownload).map((r) => ({
      kind: 'dl', title: r.name, artist: r.artist_name, album: r.album_name || '', duration: r.duration || 0, url: r.audiodownload,
      cover: r.image || '', license: r.license_ccurl || 'Creative Commons', src: 'Jamendo', free: true, stream: true,
    }));
  }
  /* ---------- YouTube Data API v3 (oficial, con tu propia clave) ---------- */
  const isoDur = (s) => { const m = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(s || ''); return m ? (+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0) : 0; };
  const htmlDec = (s) => String(s || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  async function ytDataSearch(q, key) {
    if (!key) throw new Error('Falta la clave de YouTube Data API (Ajustes)');
    const s = await getJSON(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10&maxResults=25&q=${enc(q)}&key=${enc(key)}`);
    if (s.error) throw new Error(s.error.message || 'YouTube Data API rechazó la petición');
    const items = (s.items || []).filter((i) => i.id && i.id.videoId), ids = items.map((i) => i.id.videoId), dur = {};
    if (ids.length) { try { const v = await getJSON(`https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=${ids.join(',')}&key=${enc(key)}`); (v.items || []).forEach((x) => { dur[x.id] = isoDur(x.contentDetails && x.contentDetails.duration); }); } catch {} }
    return items.map((i) => {
      let title = htmlDec(i.snippet.title), artist = htmlDec(i.snippet.channelTitle).replace(/ - Topic$/i, '').replace(/VEVO$/i, '').trim();
      const m = /^(.+?)\s[-–]\s(.+)$/.exec(title); if (m) { artist = m[1].trim(); title = m[2].trim(); }
      title = title.replace(/\s*[([](official|oficial|video|lyrics?|letra|audio|hd|4k)[^)\]]*[)\]]/gi, '').trim();
      const th = i.snippet.thumbnails || {};
      return { kind: 'song', src: 'yd', videoId: i.id.videoId, title, artist, album: '', duration: dur[i.id.videoId] || 0, cover: (th.high || th.medium || th.default || {}).url || '' };
    });
  }
  /* ---------- Apple Music API de catálogo (con tu token de desarrollador) ---------- */
  async function appleCatalogSearch(q, dev, sf) {
    if (!dev) throw new Error('Falta el token de desarrollador de Apple Music (Ajustes)');
    const d = await getJSON(`https://api.music.apple.com/v1/catalog/${enc(sf || 'us')}/search?types=songs&limit=25&term=${enc(q)}`, { headers: { Authorization: 'Bearer ' + dev, Origin: 'https://music.apple.com' } });
    return ((d.results && d.results.songs && d.results.songs.data) || []).map((x) => { const a = x.attributes || {};
      return { kind: 'song', src: 'am', appleId: x.id, isrc: a.isrc || '', title: a.name, artist: a.artistName || '', album: a.albumName || '', duration: Math.round((a.durationInMillis || 0) / 1000), cover: a.artwork ? a.artwork.url.replace('{w}', '600').replace('{h}', '600') : '' }; });
  }
  /* ---------- catálogos: Apple Music (iTunes), Deezer y SoundCloud ----------
     Aportan búsqueda con portada y álbum correctos; el sonido sale de YouTube Music (SoundCloud intenta su propio audio). */
  async function itunesSearch(q) {
    const d = await getJSON(`https://itunes.apple.com/search?media=music&entity=song&limit=25&term=${enc(q)}`);
    return (d.results || []).filter((r) => r.trackName).map((r) => ({ kind: 'song', src: 'am', title: r.trackName, artist: r.artistName || '', album: r.collectionName || '', duration: Math.round((r.trackTimeMillis || 0) / 1000), cover: (r.artworkUrl100 || '').replace('100x100bb', '600x600bb') }));
  }
  async function deezerSearch(q) {
    const d = await getJSON(`https://api.deezer.com/search?q=${enc(q)}&limit=25`);
    return (d.data || []).filter((r) => r.title).map((r) => ({ kind: 'song', src: 'dz', title: r.title_short || r.title, artist: r.artist?.name || '', album: r.album?.title || '', duration: r.duration || 0, cover: r.album?.cover_xl || r.album?.cover_big || '' }));
  }
  async function scSearch(q, cid) {
    if (!cid) throw new Error('Falta el Client ID de SoundCloud (Ajustes)');
    const d = await getJSON(`https://api-v2.soundcloud.com/search/tracks?q=${enc(q)}&client_id=${enc(cid)}&limit=25`);
    return (d.collection || []).filter((r) => r.title).map((r) => ({
      kind: 'song', src: 'sc', sc: true, scId: r.id, scTr: (r.media?.transcodings || []).find((t) => t.format?.protocol === 'progressive')?.url || '',
      title: r.title, artist: r.user?.username || '', album: '', duration: Math.round((r.duration || 0) / 1000), cover: (r.artwork_url || r.user?.avatar_url || '').replace('-large', '-t500x500'),
    }));
  }
  async function scStream(tr, cid) {
    if (!tr.startsWith('https://api-v2.soundcloud.com/')) throw new Error('Dirección no permitida');
    const d = await getJSON(`${tr}?client_id=${enc(cid)}`);
    if (!d.url) throw new Error('SoundCloud no dio el audio');
    return { url: d.url };
  }

  // peticiones web genéricas, solo hacia servicios permitidos (Spotify)
  async function safeHttp(p) {
    const u = new URL(p.url);
    if (!['api.spotify.com', 'accounts.spotify.com'].includes(u.host)) throw new Error('Dirección no permitida');
    return getJSON(p.url, { method: p.method || 'GET', headers: p.headers || {}, body: p.body || '' });
  }

  /* ---------- enrutador (mismos nombres que /api/* del servidor) ---------- */
  window.ClientAPI = {
    async handle(name, p) {
      if (name === 'search') return { results: await ytmSearch(p.q, p.type) };
      if (name === 'artist') return artistInfo(p.name || '');
      if (name === 'suggest') { const d = await getJSON(`https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=es&q=${enc(p.q)}`); return { list: (Array.isArray(d) && Array.isArray(d[1]) ? d[1] : []).slice(0, 8) }; }
      if (name === 'ytapi') return { results: await ytDataSearch(p.q, p.key) };
      if (name === 'amapi') return { results: await appleCatalogSearch(p.q, p.dev, p.sf) };
      if (name === 'itunes') return { results: await itunesSearch(p.q) };
      if (name === 'deezer') return { results: await deezerSearch(p.q) };
      if (name === 'sc') return { results: await scSearch(p.q, p.cid) };
      if (name === 'scstream') return scStream(p.tr || '', p.cid || '');
      if (name === 'home') return { sections: await ytmBrowse('FEmusic_home') };
      if (name === 'news') return { sections: await ytmNews() };
      if (name === 'charts') return { sections: await ytmBrowse('FEmusic_charts') };
      if (name === 'collection') return ytmCollection(p.id);
      if (name === 'radio') return { tracks: await ytmRadio(p.videoId) };
      if (name === 'ia') return { results: await iaSearch(p.q, p.free === '1') };
      if (name === 'iafiles') return { tracks: await iaFiles(p.id) };
      if (name === 'jamendo') return { results: await jamendoSearch(p.q, p.key) };
      if (name === 'http') return safeHttp(p);
      if (name === 'motion') return appleMotion(p.albumId || '');
      if (name === 'img') return { data: await getImageData(p.u) };
      if (name === 'cover') return hiresCover(p.title || '', p.artist || '', parseInt(p.duration || '0', 10), p.album || '');
      if (name === 'lyrics') {
        const fn = providers[p.provider];
        if (!fn) throw new Error('Proveedor desconocido');
        const q = { title: p.title || '', artist: p.artist || '', duration: parseInt(p.duration || '0', 10), appleId: p.appleId || '', videoId: /^[\w-]{11}$/.test(p.videoId || '') ? p.videoId : '' };
        try { return await fn(q); } catch (e) {
          const ct = cleanTitle(q.title);   // segundo intento con el título limpio
          if (ct && ct !== q.title && !/^(simp|ytcaps)$/.test(p.provider)) return fn({ ...q, title: ct });
          throw e;
        }
      }
      throw new Error('Ruta desconocida');
    },
  };
})();
