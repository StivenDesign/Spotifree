package com.spotifree.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

/** Widget de la pantalla de inicio: canción actual y botones anterior / reproducir / siguiente. */
class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val p = ctx.getSharedPreferences("widget", Context.MODE_PRIVATE)
        ids.forEach { mgr.updateAppWidget(it, build(ctx, p.getString("title", "Spotifree")!!, p.getString("artist", "Toca para abrir")!!, p.getBoolean("playing", false), null)) }
    }

    companion object {
        private fun svc(ctx: Context, act: String, code: Int) =
            PendingIntent.getService(ctx, 100 + code, Intent(ctx, PlayerService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        fun build(ctx: Context, title: String, artist: String, playing: Boolean, art: Bitmap?): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_player)
            v.setTextViewText(R.id.w_title, title.ifEmpty { "Spotifree" })
            v.setTextViewText(R.id.w_artist, artist)
            v.setImageViewResource(R.id.w_play, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            if (art != null) {
                val s = Bitmap.createScaledBitmap(art, 200, 200 * art.height / art.width.coerceAtLeast(1), true)
                v.setImageViewBitmap(R.id.w_art, s)
            }
            v.setOnClickPendingIntent(R.id.w_prev, svc(ctx, "prev", 1))
            v.setOnClickPendingIntent(R.id.w_play, svc(ctx, if (playing) "pause" else "play", 2))
            v.setOnClickPendingIntent(R.id.w_next, svc(ctx, "next", 3))
            val open = PendingIntent.getActivity(ctx, 99, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }

        /** Lo llama el servicio cada vez que cambia la canción o el estado. */
        fun push(ctx: Context, title: String, artist: String, playing: Boolean, art: Bitmap?) {
            try {
                ctx.getSharedPreferences("widget", Context.MODE_PRIVATE).edit().putString("title", title).putString("artist", artist).putBoolean("playing", playing).apply()
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidget::class.java))
                if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(ctx, title, artist, playing, art))
            } catch (e: Exception) {}
        }
    }
}
