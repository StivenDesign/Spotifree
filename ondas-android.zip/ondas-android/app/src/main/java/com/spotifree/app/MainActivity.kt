package com.spotifree.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingOauth: String? = null
    private val dlDir: File get() = File(filesDir, "dl").apply { mkdirs() }

    /** Lee solo `left` bytes: así se responden las peticiones con Range (buscar dentro de la canción). */
    private class Limited(s: InputStream, private var left: Long) : FilterInputStream(s) {
        override fun read(): Int { if (left <= 0) return -1; val r = super.read(); if (r >= 0) left--; return r }
        override fun read(b: ByteArray, o: Int, l: Int): Int {
            if (left <= 0) return -1
            val r = super.read(b, o, minOf(l.toLong(), left).toInt()); if (r > 0) left -= r; return r
        }
    }

    /** Sirve las canciones descargadas en https://appassets.androidplatform.net/dl/<archivo> con soporte de Range. */
    private fun serveDownload(req: WebResourceRequest): WebResourceResponse {
        val name = File(Uri.decode(req.url.path.orEmpty().removePrefix("/dl/"))).name
        val f = File(dlDir, name)
        if (!f.isFile) return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        val len = f.length()
        val mime = when (f.extension.lowercase()) { "m4a", "mp4" -> "audio/mp4"; "ogg", "opus" -> "audio/ogg"; "flac" -> "audio/flac"; "wav" -> "audio/wav"; else -> "audio/mpeg" }
        var start = 0L; var end = len - 1; var status = 200
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Access-Control-Allow-Origin" to "*")
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
        if (m != null) {
            val a = m.groupValues[1]; val b = m.groupValues[2]
            if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1) }
            else if (b.isNotEmpty()) start = maxOf(0L, len - b.toLong())
            if (start >= len) return WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$len"), ByteArrayInputStream(ByteArray(0)))
            status = 206; headers["Content-Range"] = "bytes $start-$end/$len"
        }
        headers["Content-Length"] = (end - start + 1).toString()
        val fis = FileInputStream(f); fis.channel.position(start)
        return WebResourceResponse(mime, null, status, if (status == 206) "Partial Content" else "OK", headers, Limited(fis, end - start + 1))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        volumeControlStream = AudioManager.STREAM_MUSIC     // los botones de volumen mueven el sonido multimedia
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#08080A"))
        setContentView(web)

        // Sirve los archivos de assets/www bajo https para que YouTube acepte el reproductor incrustado.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                if (request.url.host == "appassets.androidplatform.net" && request.url.path?.startsWith("/dl/") == true) serveDownload(request)
                else loader.shouldInterceptRequest(request.url)
        }
        // Selector de archivos: música local y videos de portada (canvas).
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                return try {
                    startActivityForResult(params.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        // Los botones de la notificación, la pantalla de bloqueo y los auriculares llegan a la página.
        PlayerService.onCommand = { cmd, arg ->
            runOnUiThread { web.evaluateJavascript("window.__media&&window.__media('$cmd',$arg)", null) }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        captureOauth(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private fun captureOauth(i: Intent?) {
        val d = i?.data ?: return
        if (d.scheme == "spotifree") pendingOauth = d.toString()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureOauth(intent)
        if (pendingOauth != null) web.evaluateJavascript("window.pollOauth&&window.pollOauth()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooser = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    // Al salir de la app el WebView sigue vivo: así la música no se corta.
    override fun onPause() { super.onPause(); web.resumeTimers() }
    override fun onStop() { super.onStop(); web.resumeTimers() }

    override fun onDestroy() {
        PlayerService.onCommand = null
        stopService(Intent(this, PlayerService::class.java))
        web.destroy()
        super.onDestroy()
    }

    /** Atrás cierra la pantalla abierta; si no hay nada que cerrar, manda la app a segundo plano. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    inner class Bridge {
        /** Volumen multimedia del teléfono, de 0 a 100. */
        @JavascriptInterface
        fun getVolume(): Int {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
        }

        @JavascriptInterface
        fun setVolume(pct: Int) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (pct.coerceIn(0, 100) * max + 50) / 100, 0)
        }

        /** Peticiones HTTP sin restricciones CORS (YouTube Music, KuGou, Apple, etc.). */
        @JavascriptInterface
        fun request(id: Int, method: String, url: String, headers: String, body: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = method
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    h.keys().forEach { k -> c.setRequestProperty(k, h.getString(k)) }
                    if (body.isNotEmpty()) {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    status = c.responseCode
                    val stream = if (status >= 400) c.errorStream else c.inputStream
                    text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga una imagen y la devuelve como "tipo|base64" (para usarla en WebGL sin CORS). */
        @JavascriptInterface
        fun requestBytes(id: Int, url: String) {
            Thread {
                var status = -1
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    status = c.responseCode
                    if (status < 400) {
                        val mime = c.contentType?.substringBefore(';') ?: "image/jpeg"
                        val bytes = c.inputStream.use { it.readBytes() }
                        text = mime + "|" + Base64.encodeToString(bytes, Base64.NO_WRAP)
                    }
                } catch (e: Exception) {
                    status = -1
                    text = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__nativeDone($id,$status,${JSONObject.quote(text)})", null)
                }
            }.start()
        }

        /** Descarga un archivo de música a la carpeta privada de la app y avisa del progreso. */
        @JavascriptInterface
        fun download(id: Int, url: String, file: String) {
            Thread {
                val name = File(file).name
                val part = File(dlDir, "$name.part")
                var ok = false; var msg = ""; var size = 0L
                try {
                    if (!url.startsWith("https://")) throw Exception("Solo se permiten enlaces https")
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                    if (c.responseCode >= 400) throw Exception("El servidor respondió " + c.responseCode)
                    val total = c.contentLengthLong
                    var done = 0L; var lastPct = -1; var lastAt = 0L
                    c.inputStream.use { ins -> part.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = ins.read(buf); if (n < 0) break
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt(); val now = System.currentTimeMillis()
                                if (pct != lastPct && now - lastAt > 200) { lastPct = pct; lastAt = now; runOnUiThread { web.evaluateJavascript("window.__dlProgress&&window.__dlProgress($id,$pct)", null) } }
                            }
                        }
                    } }
                    if (done < 1024) throw Exception("Archivo vacío")
                    if (!part.renameTo(File(dlDir, name))) throw Exception("No pude guardar el archivo")
                    ok = true; size = done
                } catch (e: Exception) {
                    part.delete(); msg = e.message ?: "Sin conexión"
                }
                runOnUiThread {
                    web.evaluateJavascript(if (ok) "window.__dlDone($id,true,$size)" else "window.__dlDone($id,false,${JSONObject.quote(msg)})", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun dlDelete(file: String) { File(dlDir, File(file).name).delete() }

        /** Abre un enlace https en el navegador (inicio de sesión de Spotify). */
        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {} }
        }

        /** Devuelve (una sola vez) la dirección spotifree://callback con la que Spotify volvió a la app. */
        @JavascriptInterface
        fun takeOauth(): String { val u = pendingOauth ?: ""; pendingOauth = null; return u }

        /** La página avisa qué suena y en qué punto va; Android actualiza notificación y pantalla de bloqueo. */
        @JavascriptInterface
        fun media(title: String, artist: String, playing: Boolean, posMs: Long, durMs: Long) {
            runOnUiThread {
                val i = Intent(this@MainActivity, PlayerService::class.java)
                    .putExtra("title", title).putExtra("artist", artist).putExtra("playing", playing)
                    .putExtra("pos", posMs).putExtra("dur", durMs)
                try {
                    if (PlayerService.running) startService(i) else startForegroundService(i)
                } catch (e: Exception) {
                    // sin permiso para iniciar el servicio en segundo plano: la música sigue sonando igual
                }
            }
        }
    }
}
