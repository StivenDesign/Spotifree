'use strict';
/* ===== Más funciones: tarjeta para compartir, modo coche, audio 8D y graves, ajustes por canción, resumen, agitar, compartir hacia la app ===== */
const curT = () => S.queue[S.i];

/* ---------- tarjeta para compartir (imagen PNG) ---------- */
function loadImg(url) {
  return new Promise((res) => {
    if (!url) return res(null);
    const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => res(im); im.onerror = () => res(null);
    im.src = /^https?:/.test(url) && !url.includes('appassets.androidplatform.net') ? proxyURL(url) : url;
  });
}
function avgColor(im) {
  try { const c = document.createElement('canvas'); c.width = c.height = 8; const x = c.getContext('2d'); x.drawImage(im, 0, 0, 8, 8); const d = x.getImageData(0, 0, 8, 8).data; let r = 0, g = 0, b = 0, n = 0; for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; } return [r / n | 0, g / n | 0, b / n | 0]; } catch { return [120, 30, 50]; }
}
function rrect(x, a, b, w, h, r) { x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); }
function wrapLines(x, text, maxW, maxLines) {
  const words = String(text).split(/\s+/), lines = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (x.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur);
  if (lines.length > maxLines) { lines.length = maxLines; lines[maxLines - 1] = lines[maxLines - 1].replace(/\s*\S*$/, '') + '…'; }
  return lines;
}
function cardBase(col) {
  const cv = document.createElement('canvas'); cv.width = 1080; cv.height = 1350; const x = cv.getContext('2d');
  const [r, g, b] = col, g1 = `rgb(${r * .75 | 0},${g * .75 | 0},${b * .75 | 0})`, g2 = `rgb(${r * .22 | 0},${g * .22 | 0},${b * .22 | 0})`;
  const gr = x.createLinearGradient(0, 0, 300, 1350); gr.addColorStop(0, g1); gr.addColorStop(1, g2); x.fillStyle = gr; x.fillRect(0, 0, 1080, 1350);
  return { cv, x };
}
function cardFooter(x) {
  x.textAlign = 'center'; x.fillStyle = 'rgba(255,255,255,.75)'; x.font = '700 38px Inter, system-ui, sans-serif'; x.fillText('Spotifree', 540, 1290);
}
async function trackCard(t) {
  const im = await loadImg(t.hdCover || t.cover), { cv, x } = cardBase(im ? avgColor(im) : [120, 30, 50]);
  x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = 70; x.shadowOffsetY = 30;
  x.save(); rrect(x, 190, 130, 700, 700, 36); x.fillStyle = '#222'; x.fill(); x.clip(); x.shadowColor = 'transparent';
  if (im) x.drawImage(im, 190, 130, 700, 700); x.restore();
  x.shadowColor = 'transparent'; x.textAlign = 'center'; x.fillStyle = '#fff';
  x.font = '800 62px Inter, system-ui, sans-serif'; wrapLines(x, t.title || '', 900, 2).forEach((l, i) => x.fillText(l, 540, 920 + i * 70));
  x.font = '600 42px Inter, system-ui, sans-serif'; x.fillStyle = 'rgba(255,255,255,.72)'; x.fillText((t.artist || '').slice(0, 44), 540, 1050);
  const cur = curT(), L = S.lyrics, line = cur && tid(cur) === tid(t) && L && L.synced && S.active >= 0 && L.lines[S.active] && L.lines[S.active].text;
  if (line) { x.fillStyle = '#fff'; x.font = 'italic 700 46px Inter, system-ui, sans-serif'; wrapLines(x, '“' + line.replace(/[()]/g, '') + '”', 900, 2).forEach((l, i) => x.fillText(l, 540, 1150 + i * 56)); }
  cardFooter(x); return cv;
}
async function statsCard() {
  const all = Object.values(STATS.plays), total = all.reduce((s, p) => s + p.n, 0), h = Math.floor(STATS.secs / 3600), m = Math.floor(STATS.secs % 3600 / 60);
  const top = topTracks(5).map((p) => p.track), art = {}; all.forEach((p) => { const a = mainArtist(p.track.artist) || 'Desconocido'; art[a] = (art[a] || 0) + p.n; });
  const topA = Object.entries(art).sort((a, b) => b[1] - a[1]).slice(0, 3), im = top[0] ? await loadImg(top[0].hdCover || top[0].cover) : null;
  const { cv, x } = cardBase(im ? avgColor(im) : [250, 45, 85]);
  x.textAlign = 'left'; x.fillStyle = '#fff'; x.font = '800 74px Inter, system-ui, sans-serif'; x.fillText('Mi resumen', 90, 160);
  x.font = '600 44px Inter, system-ui, sans-serif'; x.fillStyle = 'rgba(255,255,255,.78)'; x.fillText(`${h ? h + ' h ' : ''}${m} min escuchados · ${total} reproducciones`, 90, 232);
  x.fillStyle = '#fff'; x.font = '800 48px Inter, system-ui, sans-serif'; x.fillText('Canciones favoritas', 90, 360);
  x.font = '600 42px Inter, system-ui, sans-serif'; top.forEach((t, i) => { x.fillStyle = 'rgba(255,255,255,.95)'; x.fillText(`${i + 1}. ${(t.title || '').slice(0, 30)}`, 90, 430 + i * 74); x.fillStyle = 'rgba(255,255,255,.6)'; x.font = '500 32px Inter, system-ui, sans-serif'; x.fillText((t.artist || '').slice(0, 40), 130, 464 + i * 74); x.font = '600 42px Inter, system-ui, sans-serif'; });
  x.fillStyle = '#fff'; x.font = '800 48px Inter, system-ui, sans-serif'; x.fillText('Artistas favoritos', 90, 880);
  x.font = '600 44px Inter, system-ui, sans-serif'; topA.forEach(([a, n], i) => { x.fillStyle = 'rgba(255,255,255,.95)'; x.fillText(`${i + 1}. ${a.slice(0, 28)}`, 90, 950 + i * 70); x.fillStyle = 'rgba(255,255,255,.6)'; x.textAlign = 'right'; x.fillText(String(n), 990, 950 + i * 70); x.textAlign = 'left'; });
  cardFooter(x); return cv;
}
function saveCard(cv, name) {
  const b64 = cv.toDataURL('image/png').split(',')[1];
  if (window.Native && Native.saveImage) { const r = Native.saveImage(name, b64); return r && r !== 'error' ? toast('Guardada en ' + r) : toast('No pude guardar la imagen'); }
  const a = document.createElement('a'); a.href = 'data:image/png;base64,' + b64; a.download = name; a.click();
}
async function shareCard(t) { toast('Creando tarjeta…'); try { saveCard(await trackCard(t), 'spotifree-' + Date.now() + '.png'); } catch { toast('No pude crear la tarjeta'); } }

/* ---------- modo coche ---------- */
let carT = 0;
function paintCar() { const t = curT(); if (!t) return; if ($('carT').textContent !== t.title) { $('carT').textContent = t.title || '—'; $('carA').textContent = t.artist || ''; $('carArt').src = t.hdCover || t.cover || makeCover(t.title); } }
function openCar() { if (!S.queue.length) return toast('Primero pon una canción'); if (typeof closeSet === 'function') try { closeSet(); } catch {} $('carScr').hidden = false; paintCar(); clearInterval(carT); carT = setInterval(paintCar, 500); }
function closeCar() { $('carScr').hidden = true; clearInterval(carT); }

/* ---------- audio 8D y graves extra ---------- */
function applyFx() {
  if (!AN.filters) return;
  const g = AN.fxBase || CFG.eqg || [0, 0, 0, 0, 0], bb = CFG.bassBoost || 0;
  AN.filters.forEach((f, i) => { let v = g[i] || 0; if (i === 0) v += bb * 0.1; if (i === 1) v += bb * 0.03; try { f.gain.value = Math.max(-12, Math.min(14, v)); } catch {} });
}
const _setEqGains = setEqGains;
setEqGains = function (a) { AN.fxBase = null; _setEqGains(a); applyFx(); };
let panOn = false;
setInterval(() => {
  if (!AN.pan || !AN.ctx) return;
  if (CFG.fx8d && E.kind === 'local' && S.playing) { panOn = true; AN.pan.pan.setTargetAtTime(Math.sin(performance.now() / 1000 * 0.9) * 0.92, AN.ctx.currentTime, 0.07); }
  else if (panOn) { panOn = false; AN.pan.pan.setTargetAtTime(0, AN.ctx.currentTime, 0.1); }
}, 80);

/* ---------- ecualizador y volumen por canción o artista ---------- */
const EQM = store.get('sf_eqmap', {}), TVM = store.get('sf_tvol', {});
const kSong = (t) => 't:' + tid(t), kArt = (t) => 'a:' + mainArtist(t.artist || '');
function trackVol() { const t = curT(); return t && TVM[tid(t)] ? TVM[tid(t)] / 100 : 1; }
function paintTrackVol() { const v = Math.round(trackVol() * 100); if ($('tvRange')) { $('tvRange').value = v; $('tvRange').style.setProperty('--p', ((v - 30) / 70 * 100) + '%'); $('tvOut').textContent = v + '%'; } }
function applyTrackAudio(t) {
  const m = CFG.eqSong !== false && t && (EQM[kSong(t)] || (mainArtist(t.artist || '') && EQM[kArt(t)]));
  AN.fxBase = m ? m.slice() : null; applyFx();
  try { E.vol(outVol()); } catch {} paintTrackVol();
  if (t && CFG.offImg !== false) cacheCover(t.cover);
}
function saveEqFor(which) {
  const t = curT(); if (!t) return toast('Primero pon una canción');
  const g = (AN.fxBase || CFG.eqg || [0, 0, 0, 0, 0]).slice();
  EQM[which === 'a' ? kArt(t) : kSong(t)] = g; store.set('sf_eqmap', EQM);
  toast(which === 'a' ? 'Guardado para ' + (mainArtist(t.artist) || 'este artista') : 'Guardado para esta canción');
}
document.addEventListener('input', (e) => {
  if (e.target.id !== 'tvRange') return; const t = curT(); if (!t) return;
  const v = +e.target.value; if (v >= 100) delete TVM[tid(t)]; else TVM[tid(t)] = v;
  store.set('sf_tvol', TVM); paintTrackVol(); try { E.vol(outVol()); } catch {}
});

/* ---------- resumen: listas inteligentes y tarjeta ---------- */
const _renderStats = renderStats;
renderStats = function () {
  _renderStats();
  if (!Object.keys(STATS.plays).length) return;
  $('statsBody').insertAdjacentHTML('beforeend', '<h3>Crear listas</h3><div class="group glass"><button class="item btn" data-act="smart-top"><div><b>Las que más escuchas</b><small>Tus 30 canciones favoritas en una lista</small></div><svg class="ic s"><use href="#i-plus"/></svg></button><button class="item btn" data-act="smart-new"><div><b>Descubrimientos</b><small>Música parecida a tu favorita que aún no has puesto</small></div><svg class="ic s"><use href="#i-spark"/></svg></button><button class="item btn" data-act="stats-card"><div><b>Guardar mi resumen como imagen</b><small>Para compartirlo en tus redes</small></div><svg class="ic s"><use href="#i-spark"/></svg></button></div>');
};

/* ---------- botones nuevos ---------- */
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return; const a = b.dataset.act;
  if (a === 'car-open') openCar();
  else if (a === 'car-close') closeCar();
  else if (a === 'car-prev') prev();
  else if (a === 'car-next') next();
  else if (a === 'car-play') toggle();
  else if (a === 'eq-song') saveEqFor('s');
  else if (a === 'eq-artist') saveEqFor('a');
  else if (a === 'eq-forget') { const t = curT(); if (t) { delete EQM[kSong(t)]; delete EQM[kArt(t)]; store.set('sf_eqmap', EQM); applyTrackAudio(t); toast('Ajustes guardados olvidados'); } }
  else if (a === 'smart-top') { const tr = topTracks(30).map((p) => p.track); if (tr.length) { newList('Las que más escuchas', tr); toast('Lista creada en tu biblioteca'); } }
  else if (a === 'smart-new') {
    const top = topTracks(1)[0]; if (!top || !top.track.videoId) return toast('Escucha algo de YouTube Music primero');
    toast('Buscando descubrimientos…');
    try { const d = await apiGet('radio', { videoId: top.track.videoId }); const tr = d.tracks.filter((x) => !STATS.plays[tid(x)]).slice(0, 25); if (!tr.length) return toast('No encontré nada nuevo ahora'); newList('Descubrimientos', tr); toast('Lista «Descubrimientos» creada'); } catch { toast('No pude buscar ahora'); }
  }
  else if (a === 'stats-card') { toast('Creando imagen…'); try { saveCard(await statsCard(), 'spotifree-resumen-' + Date.now() + '.png'); } catch { toast('No pude crear la imagen'); } }
});

/* ---------- agitar el teléfono para saltar ---------- */
let shLast = 0, shCnt = 0;
window.addEventListener('devicemotion', (e) => {
  if (!CFG.shake || !S.queue.length) return;
  const a = e.accelerationIncludingGravity; if (!a) return;
  const m = Math.hypot(a.x || 0, a.y || 0, a.z || 0), now = Date.now();
  if (m > 26 && now - shLast > 250) { shCnt = now - shLast < 900 ? shCnt + 1 : 1; shLast = now; if (shCnt >= 2) { shCnt = 0; shLast = now + 1500; next(); haptic(15); toast('Siguiente canción'); } }
});

/* ---------- lo que otra app comparte con Spotifree (enlaces de YouTube) ---------- */
window.__share = () => {
  try {
    const txt = window.Native && Native.takeShare ? Native.takeShare() : ''; if (!txt) return;
    const m = String(txt).match(/(?:v=|youtu\.be\/|shorts\/|\/embed\/)([\w-]{11})/);
    if (!m) return toast('Solo puedo abrir enlaces de YouTube o YouTube Music');
    play([{ videoId: m[1], title: 'Canción compartida', artist: '', cover: `https://i.ytimg.com/vi/${m[1]}/hqdefault.jpg` }], 0); toast('Reproduciendo lo que compartiste');
  } catch {}
};
setTimeout(window.__share, 2500);

/* mismo ajuste en dos lugares (por ejemplo «Sin pérdida»): los dos interruptores se mantienen iguales */
document.addEventListener('change', (e) => {
  const k = e.target.dataset && e.target.dataset.cfg; if (!k || e.target.type !== 'checkbox') return;
  document.querySelectorAll(`input[data-cfg="${k}"]`).forEach((o) => { o.checked = e.target.checked; });
});

/* ---------- portadas sin internet: se guardan las de tus canciones y salen aunque no haya conexión ---------- */
const IMGC = 'sf-img-v1', imgKey = (u) => 'https://sf.cache/' + encodeURIComponent(u);
const PX = 'https://appassets.androidplatform.net/proxy/';
function origOf(src) {
  if (!src) return '';
  if (src.startsWith(PX)) { try { return decodeURIComponent(escape(atob(src.slice(PX.length).replace(/-/g, '+').replace(/_/g, '/')))); } catch { return ''; } }
  return /^https?:/.test(src) && !src.includes('appassets.androidplatform.net') ? src : '';
}
async function cacheCover(u) {
  if (!u || !origOf(u) || !('caches' in window)) return;
  try {
    const c = await caches.open(IMGC), k = imgKey(origOf(u)); if (await c.match(k)) return;
    const r = await fetch(/^https?:/.test(u) && !u.startsWith(PX) ? proxyURL(u) : u); if (r.ok) await c.put(k, r);
  } catch {}
}
async function restoreCover(im, was) {      // sin conexión: si la portada está guardada, se pone en lugar del dibujo genérico
  const o = origOf(was); if (!o || !('caches' in window)) return;
  try { const r = await (await caches.open(IMGC)).match(imgKey(o)); if (r) { im.src = URL.createObjectURL(await r.blob()); im.classList.remove('ld'); } } catch {}
}
async function prefetchCovers() {
  if (CFG.offImg === false || !navigator.onLine || !('caches' in window)) return;
  if (typeof netKind === 'function' && netKind() === 'cell' && CFG.dlWifi) return;
  const urls = new Set(); const add = (t) => { if (t && t.cover) urls.add(t.cover); };
  try { (typeof LIKES !== 'undefined' ? LIKES : []).forEach(add); LISTS.forEach((l) => l.tracks.forEach(add)); recents().forEach(add); S.queue.forEach(add); } catch {}
  const list = [...urls].filter((u) => origOf(u)).slice(0, 400); let i = 0;
  await Promise.all(Array.from({ length: 3 }, async () => { while (i < list.length) { await cacheCover(list[i++]); await new Promise((r) => setTimeout(r, 60)); } }));
  paintCacheSize();
}
setTimeout(prefetchCovers, 9000); setInterval(prefetchCovers, 3600000);
window.addEventListener('online', () => setTimeout(prefetchCovers, 2000));
