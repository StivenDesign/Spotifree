'use strict';
/* ===== Letras: varias fuentes, tira cerca de los botones y hoja completa ===== */
function renderSeg() {
  $('seg').innerHTML = '';
  PROVIDERS.forEach(([id, name]) => {
    const b = document.createElement('button'); b.textContent = name; b.className = CFG.prov === id ? 'on' : '';
    b.onclick = () => { CFG.prov = id; saveCfg(); renderSeg(); if (typeof syncSettingsUI === 'function') syncSettingsUI(); if (S.queue[S.i]) loadLyrics(S.queue[S.i]); };
    $('seg').append(b);
  });
}
function setStrip(cur, nxt, animate) {
  const c = $('stripCur'); c.textContent = cur; $('stripNxt').textContent = nxt || '';
  if (animate) { c.classList.remove('in'); void c.offsetWidth; c.classList.add('in'); }
}
const fetchProvider = (p, t) => apiGet('lyrics', { provider: p, title: t.title, artist: t.artist, duration: t.duration || 0, appleId: t.appleId || '' });

async function loadLyrics(t) {
  const my = ++S.token;
  S.lyrics = null; S.active = -2; $('lbody').innerHTML = ''; $('lsrc').textContent = '';
  $('lstate').textContent = 'Buscando letra…'; setStrip('Buscando letra…', '');
  const order = CFG.prov === 'auto' ? AUTO_ORDER : [CFG.prov];
  const errors = [];
  for (const p of order) {
    if (my !== S.token) return;
    try {
      const d = await fetchProvider(p, t);
      if (my !== S.token) return;
      S.lyrics = d; renderLyrics(); return;
    } catch (e) { errors.push(PROVIDERS.find((x) => x[0] === p)[1] + ': ' + e.message); }
  }
  if (my === S.token) {
    $('lstate').textContent = 'No encontré letra para esta canción.'; $('lsrc').textContent = errors.join(' · ');
    setStrip('Sin letra para esta canción', 'Prueba otra fuente desde Letra');
  }
}
function renderLyrics() {
  const L = S.lyrics, box = $('lbody'); box.innerHTML = ''; $('lstate').textContent = '';
  const name = PROVIDERS.find((x) => x[0] === L.provider)[1];
  $('lsrc').textContent = 'Letra de ' + name + (L.synced ? '' : ' · sin sincronizar');
  $('srcName').textContent = (S.queue[S.i] && S.queue[S.i].local ? 'Tu música' : 'YouTube Music') + ' · ' + name;
  L.lines.forEach((l) => {
    const d = document.createElement('div');
    d.className = 'ln' + (!L.synced ? ' plain' : '') + (l.text === '' ? ' gap' : '');
    d.textContent = l.text;
    if (L.synced) d.onclick = () => E.seek(Math.max(0, l.time - S.offset));
    l._el = d; box.append(d);
  });
  if (!L.synced) setStrip('Letra sin sincronizar', 'Toca para leerla completa'); else { S.active = -2; setStrip('♪', ''); }
}
function syncLyrics(cur) {
  const L = S.lyrics; if (!L || !L.synced) return;
  const now = cur + S.offset, n = L.lines.length; let a = -1;
  const k = S.active;
  if (k >= 0 && k < n && L.lines[k].time <= now && (k + 1 >= n || L.lines[k + 1].time > now)) return;   // sigue la misma línea: no recorre todo
  for (let i = 0; i < n; i++) { if (L.lines[i].time <= now) a = i; else break; }
  if (a === S.active) return;
  S.active = a;
  L.lines.forEach((l, i) => { l._el.classList.toggle('on', i === a); l._el.classList.toggle('past', i < a); });
  let nxt = ''; for (let k = a + 1; k < L.lines.length; k++) if (L.lines[k].text) { nxt = L.lines[k].text; break; }
  setStrip(a >= 0 ? (L.lines[a].text || '♪') : '♪', nxt, true);
  if (a >= 0 && S.lyrOpen) { const el = L.lines[a]._el, box = $('lbody'); box.scrollTo({ top: el.offsetTop - box.clientHeight * 0.34, behavior: 'smooth' }); }
}
renderSeg();
