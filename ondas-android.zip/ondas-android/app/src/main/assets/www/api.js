// Versión para Android de las rutas /api del servidor: las peticiones salen por el puente nativo (sin CORS).
(function () {
  const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  /* ---------- puente nativo ---------- */
  const pending = {};
  let counter = 0;
  window.__nativeDone = (id, status, body) => {
    const p = pending[id];
    if (!p) return;
    delete pending[id];
    p(status, body);
  };
  function getJSON(url, { method = 'GET', headers = {}, body = '' } = {}) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => {
        if (status <= 0) return reject(new Error(text || 'Sin conexión'));
        if (status >= 400) return reject(new Error(new URL(url).host + ' respondió ' + status));
        try { resolve(JSON.parse(text)); } catch { reject(new Error('Respuesta no válida de ' + new URL(url).host)); }
      };
      Native.request(id, method, url, JSON.stringify({ 'User-Agent': UA, ...headers }), body);
    });
  }

  function getText(url, headers = {}) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => (status <= 0 || status >= 400 ? reject(new Error(new URL(url).host + ' respondió ' + status)) : resolve(text));
      Native.request(id, 'GET', url, JSON.stringify({ 'User-Agent': UA, ...headers }), '');
    });
  }
  // Descarga una imagen como data: URL (sin CORS) para usarla en WebGL.
  function getImageData(url) {
    return new Promise((resolve, reject) => {
      const id = ++counter;
      pending[id] = (status, text) => {
        if (status <= 0 || status >= 400) return reject(new Error('Imagen no disponible'));
        const i = text.indexOf('|');
        resolve('data:' + text.slice(0, i) + ';base64,' + text.slice(i + 1));
      };
      Native.requestBytes(id, url);
    });
  }
  // Portada en movimiento: video animado que Apple Music publica en la página pública del álbum.
  async function appleMotion(albumId) {
    if (!/^\d+$/.test(albumId)) throw new Error('Álbum no válido');
    const html = await getText(`https://music.apple.com/us/album/${albumId}`, { 'Accept-Language': 'en-US,en;q=0.9' });
    const m = html.match(/"(?:motionDetailSquare|motionSquareVideo1x1)"\s*:\s*\{\s*"video"\s*:\s*"([^"]+)"/);
    return { video: m ? m[1].replace(/\\\//g, '/').replace(/\\u0026/g, '&') : '' };
  }

  /* ---------- utilidades ---------- */
  const decodeEntities = (s) =>
    s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'");
  function parseTime(s) {
    if (!s) return 0;
    s = String(s).trim();
    if (s.endsWith('s')) return parseFloat(s);
    return s.split(':').map(parseFloat).reduce((a, v) => a * 60 + v, 0);
  }
  const parseDuration = (s) => (s ? String(s).split(':').map(Number).reduce((a, v) => a * 60 + v, 0) : 0);
  const enc = encodeURIComponent;

  /* ---------- YouTube Music ---------- */
  const YTM_CONTEXT = { client: { clientName: 'WEB_REMIX', clientVersion: '1.20250210.03.00', hl: 'es', gl: 'US' } };
  const SONGS_FILTER = 'EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D';
  const VIDEOS_FILTER = 'EgWKAQIQAWoKEAkQBRAKEAMQBA%3D%3D';
  function bestThumb(thumbs = []) {
    const t = thumbs[thumbs.length - 1];
    return t ? t.url.replace(/=w\d+-h\d+[^"]*$/, '=w800-h800-l90-rj').replace(/=s\d+/, '=s800') : '';
  }
  async function ytmSearch(q, type) {
    const videos = type === 'videos';
    const data = await getJSON('https://music.youtube.com/youtubei/v1/search?prettyPrint=false', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://music.youtube.com', Referer: 'https://music.youtube.com/' },
      body: JSON.stringify({ context: YTM_CONTEXT, query: q, params: videos ? VIDEOS_FILTER : SONGS_FILTER }),
    });
    const shelves = [];
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      if (n.musicShelfRenderer) shelves.push(n.musicShelfRenderer);
      for (const k in n) walk(n[k]);
    };
    walk(data.contents);
    const out = [];
    for (const shelf of shelves) {
      for (const item of shelf.contents || []) {
        const r = item.musicResponsiveListItemRenderer;
        if (!r) continue;
        const videoId =
          r.playlistItemData?.videoId ||
          r.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
        if (!videoId) continue;
        const cols = r.flexColumns || [];
        const title = cols[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.[0]?.text || '';
        const runs = (cols[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || []).map((x) => x.text);
        const parts = runs.join('').split(' • ').map((s) => s.trim()).filter(Boolean);
        const clean = parts[0] && /^(canción|song|video)$/i.test(parts[0]) ? parts.slice(1) : parts;
        const durStr = clean.find((s) => /^\d+:\d{2}(:\d{2})?$/.test(s)) || '';
        out.push({
          videoId, title,
          artist: clean[0] || '',
          album: !videos && clean[1] && clean[1] !== durStr ? clean[1] : '',
          duration: parseDuration(durStr),
          cover: bestThumb(r.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails),
        });
      }
    }
    return out;
  }

  async function hiresCover(title, artist) {
    const d = await getJSON(`https://itunes.apple.com/search?media=music&entity=song&limit=1&term=${enc(artist + ' ' + title)}`);
    const hit = d.results?.[0];
    if (!hit) return { cover: '' };
    return { cover: hit.artworkUrl100.replace('100x100bb', '1400x1400bb'), appleId: String(hit.trackId), albumId: hit.collectionId ? String(hit.collectionId) : '' };
  }

  /* ---------- letras ---------- */
  function parseLRC(text) {
    const lines = [];
    for (const raw of text.split(/\r?\n/)) {
      const m = raw.match(/^((?:\[\d+:\d+(?:[.:]\d+)?\])+)(.*)$/);
      if (!m) continue;
      const txt = m[2].replace(/<\d+:\d+(?:\.\d+)?>/g, '').trim();
      for (const t of m[1].matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)) {
        lines.push({ time: parseInt(t[1], 10) * 60 + parseFloat(t[2].replace(':', '.')), text: txt });
      }
    }
    return lines.sort((a, b) => a.time - b.time);
  }
  function parseTTML(ttml) {
    const lines = [];
    for (const p of ttml.matchAll(/<p\b([^>]*)>([\s\S]*?)<\/p>/g)) {
      const begin = /begin="([^"]+)"/.exec(p[1]);
      const end = /end="([^"]+)"/.exec(p[1]);
      if (!begin) continue;
      const words = [];
      for (const s of p[2].matchAll(/<span\b([^>]*)>([\s\S]*?)<\/span>/g)) {
        const sb = /begin="([^"]+)"/.exec(s[1]);
        if (!sb) continue;
        const txt = decodeEntities(s[2].replace(/<[^>]+>/g, ''));
        if (txt.trim() === '') continue;
        words.push({ t: parseTime(sb[1]), text: txt });
      }
      const text = decodeEntities(p[2].replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
      lines.push({ time: parseTime(begin[1]), end: end ? parseTime(end[1]) : undefined, text, words: words.length > 1 ? words : undefined });
    }
    return lines;
  }

  const providers = {
    async betterlyrics({ title, artist, duration }) {
      const d = await getJSON(`https://lyrics-api.boidu.dev/getLyrics?s=${enc(title)}&a=${enc(artist)}${duration ? '&d=' + duration : ''}`);
      const ttml = d.ttml || d.lyrics || '';
      if (!ttml) throw new Error('Sin letra en Better Lyrics');
      const lines = parseTTML(ttml);
      if (!lines.length) throw new Error('Respuesta de Better Lyrics sin líneas');
      return { provider: 'betterlyrics', synced: true, lines };
    },
    async kugou({ title, artist, duration }) {
      const q = `${artist} ${title}`;
      const s = await getJSON(`https://mobilecdn.kugou.com/api/v3/search/song?format=json&page=1&pagesize=5&keyword=${enc(q)}`);
      const song = s.data?.info?.[0];
      if (!song) throw new Error('KuGou no encontró la canción');
      const c = await getJSON(`https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=${enc(q)}&duration=${(duration || song.duration || 0) * 1000}&hash=${song.hash}`);
      const cand = c.candidates?.[0];
      if (!cand) throw new Error('KuGou no tiene letra');
      const d = await getJSON(`https://lyrics.kugou.com/download?ver=1&client=pc&id=${cand.id}&accesskey=${cand.accesskey}&fmt=lrc&charset=utf8`);
      const bytes = Uint8Array.from(atob(d.content || ''), (ch) => ch.charCodeAt(0));
      const lrc = new TextDecoder('utf-8').decode(bytes);
      const lines = parseLRC(lrc).filter((l) => !/^\s*(ti|ar|al|by|offset)\s*:/i.test(l.text));
      if (!lines.length) throw new Error('KuGou devolvió letra vacía');
      return { provider: 'kugou', synced: true, lines };
    },
    // Apple Music: pega tus tokens en Ajustes de la app (se guardan solo en este teléfono).
    async apple({ title, artist, appleId }) {
      let cfg = {};
      try { cfg = JSON.parse(localStorage.getItem('ondas_apple') || '{}'); } catch {}
      if (!cfg.dev || !cfg.user) throw new Error('Faltan los tokens de Apple Music');
      const sf = cfg.storefront || 'us';
      const headers = { Authorization: 'Bearer ' + cfg.dev, 'Music-User-Token': cfg.user, Origin: 'https://music.apple.com' };
      let id = appleId;
      if (!id) {
        const s = await getJSON(`https://amp-api.music.apple.com/v1/catalog/${sf}/search?types=songs&limit=1&term=${enc(artist + ' ' + title)}`, { headers });
        id = s.results?.songs?.data?.[0]?.id;
      }
      if (!id) throw new Error('Apple Music no encontró la canción');
      const d = await getJSON(`https://amp-api.music.apple.com/v1/catalog/${sf}/songs/${id}/syllable-lyrics`, { headers });
      const ttml = d.data?.[0]?.attributes?.ttml;
      if (!ttml) throw new Error('Apple Music sin letra para esta canción');
      return { provider: 'apple', synced: true, lines: parseTTML(ttml) };
    },
    async lrclib({ title, artist, duration }) {
      let d;
      try {
        d = await getJSON(`https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}${duration ? '&duration=' + duration : ''}`);
      } catch {
        d = (await getJSON(`https://lrclib.net/api/search?q=${enc(artist + ' ' + title)}`))[0];
      }
      if (!d) throw new Error('LRCLIB no encontró la canción');
      if (d.syncedLyrics) return { provider: 'lrclib', synced: true, lines: parseLRC(d.syncedLyrics) };
      if (d.plainLyrics) return { provider: 'lrclib', synced: false, lines: d.plainLyrics.split('\n').map((text) => ({ time: 0, text })) };
      throw new Error('LRCLIB sin letra');
    },
  };

  /* ---------- YouTube Music: inicio, novedades, colecciones y radio ---------- */
  const ytm = (ep, payload) =>
    getJSON(`https://music.youtube.com/youtubei/v1/${ep}?prettyPrint=false`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: 'https://music.youtube.com', Referer: 'https://music.youtube.com/' },
      body: JSON.stringify({ context: YTM_CONTEXT, ...payload }),
    });
  const runsText = (r) => (r?.runs || []).map((x) => x.text).join('');
  function parseTwoRow(r) {
    const nav = r.navigationEndpoint || {};
    const title = runsText(r.title), sub = runsText(r.subtitle);
    const cover = bestThumb(r.thumbnailRenderer?.musicThumbnailRenderer?.thumbnail?.thumbnails);
    const be = nav.browseEndpoint?.browseId, vid = nav.watchEndpoint?.videoId, pl = nav.watchEndpoint?.playlistId;
    if (vid) return { kind: 'song', videoId: vid, title, artist: sub.replace(/^(Canción|Song|Video)\s*•\s*/i, '').split(' • ')[0], cover, duration: 0 };
    if (!be) return pl ? { kind: 'playlist', id: 'VL' + pl, title, sub, cover } : null;
    const kind = be.startsWith('MPRE') ? 'album' : be.startsWith('UC') ? 'artist' : 'playlist';
    return { kind, id: be, title, sub, cover };
  }
  function parseListItem(r, fb = {}) {
    const videoId = r.playlistItemData?.videoId || r.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
    if (!videoId) return null;
    const cols = r.flexColumns || [];
    const title = runsText(cols[0]?.musicResponsiveListItemFlexColumnRenderer?.text);
    const runs = (cols[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || []).map((x) => x.text).filter((x) => x.trim() !== '•');
    const durTxt = runsText(r.fixedColumns?.[0]?.musicResponsiveListItemFixedColumnRenderer?.text) || runs.find((s) => /^\d+:\d{2}(:\d{2})?$/.test(s)) || '';
    const cover = bestThumb(r.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails) || fb.cover || '';
    const first = runs[0] && !/^\d+:\d{2}/.test(runs[0]) ? runs[0] : '';
    return { kind: 'song', videoId, title, artist: first || fb.artist || '', album: fb.album || '', duration: parseDuration(durTxt), cover };
  }
  function sectionsFrom(data, fb) {
    const out = [];
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      const sh = n.musicCarouselShelfRenderer || n.musicShelfRenderer || n.musicPlaylistShelfRenderer;
      if (sh) {
        const title = runsText(sh.header?.musicCarouselShelfBasicHeaderRenderer?.title) || runsText(sh.title) || '';
        const items = [];
        for (const c of sh.contents || []) {
          const it = c.musicTwoRowItemRenderer ? parseTwoRow(c.musicTwoRowItemRenderer) : c.musicResponsiveListItemRenderer ? parseListItem(c.musicResponsiveListItemRenderer, fb) : null;
          if (it) items.push(it);
        }
        if (items.length) out.push({ title, items });
        return;
      }
      for (const k in n) walk(n[k]);
    };
    walk(data.contents);
    return out;
  }
  function headerFrom(data) {
    const h = data.header || {};
    let node = h.musicDetailHeaderRenderer || h.musicImmersiveHeaderRenderer || h.musicVisualHeaderRenderer || null;
    if (!node) {
      const find = (n) => { if (!n || typeof n !== 'object') return null; if (n.musicResponsiveHeaderRenderer) return n.musicResponsiveHeaderRenderer; for (const k in n) { const r = find(n[k]); if (r) return r; } return null; };
      node = find(data.contents) || find(data.header);
    }
    node = node || {};
    let thumbs; const f = (n) => { if (thumbs || !n || typeof n !== 'object') return; if (Array.isArray(n.thumbnails)) { thumbs = n.thumbnails; return; } for (const k in n) f(n[k]); }; f(node);
    return { title: runsText(node.title), sub: runsText(node.subtitle) || runsText(node.straplineTextOne), cover: bestThumb(thumbs) };
  }
  async function ytmBrowse(id) { return sectionsFrom(await ytm('browse', { browseId: id })); }
  async function ytmNews() {
    const ids = ['FEmusic_new_releases_albums', 'FEmusic_explore'];
    const res = await Promise.allSettled(ids.map(ytmBrowse));
    const sections = res.flatMap((r) => (r.status === 'fulfilled' ? r.value : []));
    if (!sections.length) throw new Error('YouTube Music no devolvió novedades');
    return sections;
  }
  async function ytmCollection(id) {
    const data = await ytm('browse', { browseId: id });
    const h = headerFrom(data), parts = h.sub.split(' • ').map((s) => s.trim());
    const fb = { cover: h.cover, artist: parts.find((s, i) => i > 0 && !/^\d{4}$/.test(s)) || parts[0] || '', album: id.startsWith('MPRE') ? h.title : '' };
    const sections = sectionsFrom(data, fb);
    const tracks = []; const seen = new Set();
    for (const s of sections) for (const it of s.items) if (it.kind === 'song' && !seen.has(it.videoId)) { seen.add(it.videoId); tracks.push(it); }
    return { ...h, tracks, sections: sections.filter((s) => s.items.some((i) => i.kind !== 'song')) };
  }
  async function ytmRadio(videoId) {
    const d = await ytm('next', { videoId, playlistId: 'RDAMVM' + videoId, params: 'wAEB', isAudioOnly: true });
    const out = [], seen = new Set();
    const walk = (n) => {
      if (!n || typeof n !== 'object') return;
      const r = n.playlistPanelVideoRenderer;
      if (r) {
        if (!seen.has(r.videoId)) {
          seen.add(r.videoId);
          const by = (r.longBylineText?.runs || []).map((x) => x.text).filter((x) => x.trim() !== '•');
          out.push({ kind: 'song', videoId: r.videoId, title: runsText(r.title), artist: by[0] || '', album: by[1] || '', duration: parseDuration(r.lengthText?.runs?.[0]?.text || ''), cover: bestThumb(r.thumbnail?.thumbnails) });
        }
        return;
      }
      for (const k in n) walk(n[k]);
    };
    walk(d.contents);
    return out;
  }

  /* ---------- foto del artista (Deezer, API pública) ---------- */
  const nrm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  async function artistInfo(name) {
    const d = await getJSON(`https://api.deezer.com/search/artist?q=${enc(name)}&limit=5`);
    const list = d.data || [], q = nrm(name);
    // solo se acepta el mismo nombre (o uno que lo contenga) para no mostrar la foto de otra persona
    const hit = list.find((x) => nrm(x.name) === q) || list.find((x) => { const n = nrm(x.name); return n && (n.includes(q) || q.includes(n)); });
    if (!hit) return {};
    const pic = hit.picture_xl || hit.picture_big || hit.picture_medium || '';
    return { name: hit.name, picture: /\/artist\/\//.test(pic) ? '' : pic, fans: hit.nb_fan || 0 };
  }

  /* ---------- fuentes de descarga con licencia libre ---------- */
  async function iaSearch(q, free) {
    let query = `(${q}) AND mediatype:audio`;
    if (free) query += ' AND (licenseurl:*creativecommons* OR licenseurl:*publicdomain*)';
    const d = await getJSON(`https://archive.org/advancedsearch.php?q=${enc(query)}&fl[]=identifier&fl[]=title&fl[]=creator&rows=25&sort[]=downloads+desc&output=json`);
    return (d.response?.docs || []).map((x) => ({
      kind: 'ia', id: x.identifier, title: x.title || x.identifier, artist: [].concat(x.creator || '')[0] || 'Internet Archive',
      cover: `https://archive.org/services/img/${x.identifier}`,
    }));
  }
  async function iaFiles(id) {
    const d = await getJSON(`https://archive.org/metadata/${enc(id)}`);
    const meta = d.metadata || {};
    const artist = [].concat(meta.creator || '')[0] || 'Internet Archive', album = [].concat(meta.title || '')[0] || id;
    const seen = new Set();
    return (d.files || []).filter((f) => /\.mp3$/i.test(f.name) && f.source !== 'derivative' || /VBR MP3/i.test(f.format || '')).filter((f) => !seen.has(f.name) && seen.add(f.name)).slice(0, 60).map((f) => ({
      kind: 'dl', title: (f.title || f.name.replace(/\.[^.]+$/, '')).replace(/^\d+\s*[-.]\s*/, ''), artist: f.creator || artist, album,
      duration: parseFloat(f.length) || 0, size: +f.size || 0, url: `https://archive.org/download/${enc(id)}/${f.name.split('/').map(enc).join('/')}`,
      cover: `https://archive.org/services/img/${id}`, license: meta.licenseurl || 'Internet Archive', src: 'Internet Archive',
    }));
  }
  async function jamendoSearch(q, key) {
    if (!key) throw new Error('Falta el Client ID de Jamendo');
    const d = await getJSON(`https://api.jamendo.com/v3.0/tracks/?client_id=${enc(key)}&format=json&limit=30&namesearch=${enc(q)}&audiodownload_allowed=true&include=musicinfo&order=popularity_total`);
    if (d.headers && d.headers.status === 'failed') throw new Error(d.headers.error_message || 'Jamendo rechazó la petición');
    return (d.results || []).filter((r) => r.audiodownload).map((r) => ({
      kind: 'dl', title: r.name, artist: r.artist_name, album: r.album_name || '', duration: r.duration || 0, url: r.audiodownload,
      cover: r.image || '', license: r.license_ccurl || 'Creative Commons', src: 'Jamendo',
    }));
  }
  // peticiones web genéricas, solo hacia servicios permitidos (Spotify)
  async function safeHttp(p) {
    const u = new URL(p.url);
    if (!['api.spotify.com', 'accounts.spotify.com'].includes(u.host)) throw new Error('Dirección no permitida');
    return getJSON(p.url, { method: p.method || 'GET', headers: p.headers || {}, body: p.body || '' });
  }

  /* ---------- enrutador (mismos nombres que /api/* del servidor) ---------- */
  window.ClientAPI = {
    async handle(name, p) {
      if (name === 'search') return { results: await ytmSearch(p.q, p.type) };
      if (name === 'artist') return artistInfo(p.name || '');
      if (name === 'home') return { sections: await ytmBrowse('FEmusic_home') };
      if (name === 'news') return { sections: await ytmNews() };
      if (name === 'collection') return ytmCollection(p.id);
      if (name === 'radio') return { tracks: await ytmRadio(p.videoId) };
      if (name === 'ia') return { results: await iaSearch(p.q, p.free === '1') };
      if (name === 'iafiles') return { tracks: await iaFiles(p.id) };
      if (name === 'jamendo') return { results: await jamendoSearch(p.q, p.key) };
      if (name === 'http') return safeHttp(p);
      if (name === 'motion') return appleMotion(p.albumId || '');
      if (name === 'img') return { data: await getImageData(p.u) };
      if (name === 'cover') return hiresCover(p.title || '', p.artist || '');
      if (name === 'lyrics') {
        const fn = providers[p.provider];
        if (!fn) throw new Error('Proveedor desconocido');
        return fn({ title: p.title || '', artist: p.artist || '', duration: parseInt(p.duration || '0', 10), appleId: p.appleId || '' });
      }
      throw new Error('Ruta desconocida');
    },
  };
})();
