'use strict';
/* ===== Ajustes e información ===== */
function syncSettingsUI() {
  $('setProv').value = CFG.prov; $('setEq').value = String(CFG.eq);
  $('setMotion').checked = CFG.motion; $('setAmb').checked = CFG.amb;
  document.body.classList.toggle('no-amb', !CFG.amb);
  $('setPerf').checked = !!CFG.perf; document.body.classList.toggle('perf', !!CFG.perf);
  S.glDirty = true;
}
(function initSettings() {
  PROVIDERS.forEach(([id, name]) => { const o = document.createElement('option'); o.value = id; o.textContent = name; $('setProv').append(o); });
  $('setProv').onchange = (e) => { CFG.prov = e.target.value; saveCfg(); renderSeg(); if (S.queue[S.i]) loadLyrics(S.queue[S.i]); };
  $('setEq').onchange = (e) => { CFG.eq = +e.target.value; saveCfg(); };
  $('setMotion').onchange = (e) => {
    CFG.motion = e.target.checked; saveCfg();
    const t = S.queue[S.i]; if (!t) return;
    if (CFG.motion) onTrackLoad(t); else { clearMotion(); $('gl').classList.remove('ready'); }
  };
  $('setPerf').onchange = (e) => { CFG.perf = e.target.checked; saveCfg(); syncSettingsUI(); toast(CFG.perf ? 'Modo ahorro activado' : 'Modo ahorro desactivado'); };
  $('setAmb').onchange = (e) => { CFG.amb = e.target.checked; saveCfg(); syncSettingsUI(); };
  $('appleGroup').hidden = !window.ClientAPI;
  syncSettingsUI();
})();

function openSet() {
  const s = $('set'); s.hidden = false; void s.offsetWidth; s.classList.add('open'); document.body.classList.add('set-open');
}
function closeSet() {
  const s = $('set'); s.classList.remove('open'); document.body.classList.remove('set-open'); setTimeout(() => { if (!s.classList.contains('open')) s.hidden = true; }, 620);
}

// acciones destructivas: se confirman tocando dos veces
const armed = new Map();
function confirmTap(btn, run) {
  const small = btn.querySelector('small'), old = small.textContent;
  if (armed.has(btn)) { clearTimeout(armed.get(btn)); armed.delete(btn); small.textContent = old; run(); return; }
  small.textContent = 'Toca otra vez para confirmar'; small.style.color = '#ff8a8a';
  armed.set(btn, setTimeout(() => { armed.delete(btn); small.textContent = old; small.style.color = ''; }, 3500));
}
function settingsAction(act, btn) {
  if (act === 'clear-lib') confirmTap(btn, clearLibrary);
  else if (act === 'clear-canvas') confirmTap(btn, async () => { await canvasClear(); const t = S.queue[S.i]; if (t) { t._hasCanvas = false; $('artImg').src = t.cover; onTrackLoad(t); } toast('Canvas borrados'); });
  else if (act === 'clear-recent') confirmTap(btn, () => { store.set('ondas_recent', []); renderRecent(); toast('Recientes borrados'); });
}

/* ---- tokens de Apple Music (solo Android; en PC se usan variables de entorno) ---- */
function openCfg() {
  const v = store.get('ondas_apple', {});
  $('ap-dev').value = v.dev || ''; $('ap-user').value = v.user || ''; $('ap-sf').value = v.storefront || '';
  $('cfg').hidden = false;
}
$('cfgCancel').onclick = () => ($('cfg').hidden = true);
$('cfgForm').onsubmit = (e) => {
  e.preventDefault();
  store.set('ondas_apple', { dev: $('ap-dev').value.trim(), user: $('ap-user').value.trim(), storefront: $('ap-sf').value.trim() || 'us' });
  $('cfg').hidden = true; toast('Tokens guardados');
  if (S.queue[S.i]) loadLyrics(S.queue[S.i]);
};
