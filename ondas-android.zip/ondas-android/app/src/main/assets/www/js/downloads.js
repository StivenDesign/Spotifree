'use strict';
/* ===== Descargas: solo fuentes con licencia libre (Internet Archive, Jamendo) ===== */
const DL_BASE = 'https://appassets.androidplatform.net/dl/';
let DLS = store.get('sf_dl', []);
const DLP = {};                       // descargas en curso, por id
let dlCounter = 0, dlSrc = 'ia', dlBusy = 0;
const saveDLS = () => store.set('sf_dl', DLS);
const dlTracks = () => DLS.map((d) => ({ local: true, dl: true, kind: 'download', did: d.did, title: d.title, artist: d.artist, album: d.album || '', duration: d.duration || 0, cover: d.cover || '', url: DL_BASE + encodeURIComponent(d.file) }));

function dlSizeText() {
  const total = DLS.reduce((n, d) => n + (d.size || 0), 0);
  const el = $('dlSize'); if (el) el.textContent = DLS.length ? `${DLS.length} ${DLS.length === 1 ? 'canción' : 'canciones'} · ${(total / 1048576).toFixed(0)} MB` : 'No hay música descargada';
}

function openDownloads(prefill) {
  openSheet('dl'); syncDlUI();
  if (prefill != null) { $('dlQ').value = prefill; if (prefill) dlSearch(prefill); }
}
function syncDlUI() {
  $('dlSrc').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.src === dlSrc));
  $('dlFreeRow').hidden = dlSrc !== 'ia'; $('dlKeyRow').hidden = dlSrc !== 'jamendo';
  $('dlKey').value = store.get('sf_jkey', ''); $('dlFree').checked = store.get('sf_free', false);
}
$('dlSrc').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; dlSrc = b.dataset.src; syncDlUI(); haptic(5); if ($('dlQ').value.trim()) dlSearch($('dlQ').value.trim()); });
$('dlFree').onchange = (e) => { store.set('sf_free', e.target.checked); if ($('dlQ').value.trim()) dlSearch($('dlQ').value.trim()); };
$('dlKey').onchange = (e) => store.set('sf_jkey', e.target.value.trim());
$('dlForm').addEventListener('submit', (e) => { e.preventDefault(); $('dlQ').blur(); dlSearch($('dlQ').value.trim()); });

async function dlSearch(q) {
  if (!q) return;
  const box = $('dlRes');
  if (!window.ClientAPI) { box.innerHTML = '<p class="empty-t">Las descargas funcionan en la app de Android.</p>'; return; }
  box.innerHTML = skel(4);
  try {
    if (dlSrc === 'ia') {
      const d = await apiGet('ia', { q, free: store.get('sf_free', false) ? '1' : '0' });
      paintIaAlbums(d.results, q);
    } else {
      const key = store.get('sf_jkey', '');
      if (!key) { box.innerHTML = '<p class="empty-t">Pega arriba tu Client ID de Jamendo (es gratis) y vuelve a buscar.</p>'; return; }
      const d = await apiGet('jamendo', { q, key });
      paintDlTracks(d.results, null);
    }
  } catch (e) { box.innerHTML = `<p class="empty-t">No pude buscar: ${esc(e.message)}</p>`; }
}
function paintIaAlbums(list, q) {
  const box = $('dlRes'); box.innerHTML = '';
  if (!list.length) { box.innerHTML = '<p class="empty-t">Nada con licencia libre para esa búsqueda. Prueba otro nombre o desactiva «Solo licencias libres».</p>'; return; }
  list.forEach((a, i) => {
    const r = document.createElement('div'); r.className = 'dl-row'; r.style.cursor = 'pointer'; r.style.setProperty('--i', i);
    r.innerHTML = `<img class="cv" style="width:46px;height:46px;border-radius:6px;object-fit:cover;background:#262626" src="${esc(a.cover)}" alt=""><div class="tx"><b>${esc(a.title)}</b><small>${esc(a.artist)}</small></div><svg class="ic s"><use href="#i-chev"/></svg>`;
    r.onclick = async () => {
      haptic(6); box.innerHTML = skel(4);
      try { const d = await apiGet('iafiles', { id: a.id }); paintDlTracks(d.tracks, () => paintIaAlbums(list, q), a.title); }
      catch (e) { box.innerHTML = `<p class="empty-t">No pude abrir este álbum: ${esc(e.message)}</p>`; }
    };
    box.append(r);
  });
}
function paintDlTracks(list, back, title) {
  const box = $('dlRes'); box.innerHTML = '';
  if (back) { const b = document.createElement('button'); b.className = 'lnk'; b.style.cssText = 'float:none;padding:6px 2px 10px;display:block'; b.textContent = '‹ Resultados'; b.onclick = back; box.append(b); }
  if (title) box.insertAdjacentHTML('beforeend', `<div class="sec-h" style="padding:0 0 6px">${esc(title)}</div>`);
  if (!list.length) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">No encontré archivos MP3 aquí.</p>'); return; }
  list.forEach((t) => {
    const done = DLS.some((d) => d.url === t.url);
    const r = document.createElement('div'); r.className = 'dl-row';
    r.innerHTML = `<div class="tx"><b>${esc(t.title)}</b><small>${esc(t.artist)}${t.duration ? ' · ' + fmt(t.duration) : ''} · ${esc(t.src)}</small></div><button class="pill glass${done ? ' done' : ''}">${done ? 'Descargada' : 'Descargar'}<i class="bar"></i></button>`;
    const btn = r.querySelector('.pill');
    btn.onclick = () => { if (!btn.classList.contains('done') && !btn.disabled) startDownload(t, btn); };
    box.append(r);
  });
}

const slug = (s) => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'cancion';
function startDownload(t, btn) {
  haptic(10);
  if (!window.Native || !Native.download) { toast('Abro el archivo en el navegador'); const a = document.createElement('a'); a.href = t.url; a.download = ''; a.target = '_blank'; a.rel = 'noopener'; document.body.append(a); a.click(); a.remove(); return; }
  const id = ++dlCounter, file = Date.now().toString(36) + '_' + slug(t.title) + '.mp3';
  DLP[id] = { t, btn, file }; btn.disabled = true; btn.firstChild.textContent = '0 %'; dlBusy++;
  try { Native.download(id, t.url, file); } catch (e) { delete DLP[id]; btn.disabled = false; btn.firstChild.textContent = 'Descargar'; toast('No pude empezar la descarga'); }
}
window.__dlProgress = (id, pct) => { const p = DLP[id]; if (!p) return; p.btn.firstChild.textContent = pct + ' %'; p.btn.style.setProperty('--pg', pct + '%'); p.btn.querySelector('.bar').style.width = pct + '%'; };
window.__dlDone = (id, ok, size) => {
  const p = DLP[id]; if (!p) return; delete DLP[id]; dlBusy = Math.max(0, dlBusy - 1);
  const { t, btn, file } = p;
  if (!ok) { btn.disabled = false; btn.firstChild.textContent = 'Reintentar'; btn.querySelector('.bar').style.width = '0'; return toast('Falló la descarga: ' + (size || 'sin conexión')); }
  DLS.unshift({ did: file.replace(/\.[^.]+$/, ''), file, title: t.title, artist: t.artist, album: t.album || '', duration: t.duration || 0, cover: t.cover || '', url: t.url, src: t.src, license: t.license || '', size: +size || 0, added: Date.now() });
  saveDLS(); dlSizeText(); btn.disabled = false; btn.classList.add('done'); btn.firstChild.textContent = 'Descargada'; btn.querySelector('.bar').style.width = '0';
  haptic(14); toast('Descargada: ' + t.title); refreshLibViews();
};
function deleteDownload(t) {
  const d = DLS.find((x) => x.did === t.did); if (!d) return;
  DLS = DLS.filter((x) => x !== d); saveDLS(); try { window.Native && Native.dlDelete && Native.dlDelete(d.file); } catch {}
  LIKES = LIKES.filter((x) => tid(x) !== tid(t)); saveLikes();
  dlSizeText(); refreshLibViews(); toast('Descarga eliminada');
}
function clearDownloads() {
  DLS.forEach((d) => { try { window.Native && Native.dlDelete && Native.dlDelete(d.file); } catch {} });
  DLS = []; saveDLS(); dlSizeText(); refreshLibViews(); toast('Descargas borradas');
}

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  if (b.dataset.act === 'open-dl') { closeSheet('set'); openDownloads(); }
  else if (b.dataset.act === 'close-dl') closeSheet('dl');
  else if (b.dataset.act === 'dl-current') {
    const t = S.queue[S.i]; if (!t) return toast('Primero elige una canción');
    if (t.dl) return toast('Esta canción ya está descargada');
    if (t.local) return toast('Esta canción ya está en tu teléfono');
    closeNP(); openDownloads(`${t.artist} ${t.title}`.trim());
  }
});
dlSizeText();
