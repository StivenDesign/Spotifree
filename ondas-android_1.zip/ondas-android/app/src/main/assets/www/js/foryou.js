/* Playlists para ti: mezclas armadas con los artistas que más escuchas (tarjetas grandes como Apple Music, con la marca Spotifree) */
const BRAND = '♫︎ 𝑆𝑝𝑜𝑡𝑖𝑓𝑟𝑒𝑒';
const fyMain = (a) => String(a || '').split(/,|&| x | feat\.?| ft\.?|\//i)[0].trim();
function listenArtists() {
  const c = {}, add = (a, n) => { a = fyMain(a); if (a && !/^desconocido$/i.test(a)) c[a] = (c[a] || 0) + n; };
  try { statData().all.forEach((p) => add(p.track && p.track.artist, p.n)); } catch {}
  try { (LIKES || []).forEach((t) => add(t.artist, 2)); (recents() || []).forEach((t) => add(t.artist, 1)); } catch {}
  const l = Object.entries(c).sort((a, b) => b[1] - a[1]).map((x) => x[0]);
  for (const a of ARTISTS) if (l.length < 6 && !l.includes(a)) l.push(a);   // si aún no hay historial, un variado de artistas populares
  return l.slice(0, 10);
}
function fyDefs() {
  const A = listenArtists(), odd = A.filter((_, i) => i % 2 === 1), list = [];
  list.push({ title: 'Para ti', artists: A.slice(0, 6) });
  list.push({ title: 'Tus favoritos', artists: A.slice(0, 3) });
  if (odd.length >= 2) list.push({ title: 'Variado', artists: [...odd, ...A.filter((_, i) => i % 2 === 0)].slice(0, 6) });
  if (A.length > 4) list.push({ title: 'Descubre', artists: A.slice(3, 9) });
  A.slice(0, 3).forEach((a, i) => list.push({ title: a, mix: true, artists: [a, ...A.filter((x) => x !== a).slice(i, i + 2)] }));
  return list;
}
function fyBg(title) {
  const h = hue(title), h2 = (h + 55) % 360, h3 = (h + 300) % 360;
  return `radial-gradient(circle at 18% 88%,hsl(${h2} 85% 55%) 0,transparent 58%),radial-gradient(circle at 85% 12%,hsl(${h3} 90% 62%) 0,transparent 52%),hsl(${h} 70% 38%)`;
}
function fyCard(d) {
  const b = document.createElement('button'); b.className = 'fy-card'; b.style.background = fyBg(d.title);
  const len = d.title.length, fs = len > 14 ? 30 : len > 9 ? 38 : 46;
  b.innerHTML = `<span class="fy-logo">${BRAND}</span><span class="fy-t" style="font-size:${fs}px">${esc(d.title)}</span><span class="fy-a">${esc(d.artists.join(', '))}${d.mix ? '' : ' y más'}</span>`;
  b.onclick = () => openFy(d); return b;
}
async function fyTracks(artists) {
  const per = await Promise.all(artists.slice(0, 8).map((a) => apiGet('search', { q: a, type: 'songs' }).then((d) => (d.results || []).filter((t) => t.videoId).slice(0, 8)).catch(() => [])));
  const out = [], seen = new Set();
  for (let i = 0; i < 8; i++) per.forEach((l) => { const t = l[i]; if (t && !seen.has(t.videoId)) { seen.add(t.videoId); out.push(t); } });   // uno de cada artista, en rotación
  return out;
}
async function openFy(d) {
  haptic(8); const c = { title: d.title === d.artists[0] ? 'Mix de ' + d.title : d.title, sub: 'Playlist · ' + BRAND, cover: '', tracks: [], loading: true, key: null };
  openColl(c);
  try { const tr = await fyTracks(d.artists); if (COLL.cur !== c) return; c.loading = false; c.tracks = tr.map(slim); c.cover = (tr[0] && tr[0].cover) || ''; c.sub = tr.length + ' canciones · ' + BRAND; paintColl(c); }
  catch { c.loading = false; toast('No pude armar la playlist'); }
}
let fyDone = '';
function paintForYou() {
  const host = $('ytShelves'); if (!host) return;
  let sec = $('forYou'); if (!sec) { sec = document.createElement('section'); sec.className = 'shelf'; sec.id = 'forYou'; sec.dataset.chip = 'all'; sec.innerHTML = '<h2>Playlists para ti</h2><div class="hscroll"></div>'; host.before(sec); }
  const defs = fyDefs(), key = defs.map((d) => d.title + d.artists.join()).join('|'); if (key === fyDone) return; fyDone = key;
  const rail = sec.querySelector('.hscroll'); rail.innerHTML = ''; defs.forEach((d) => rail.append(fyCard(d)));
}
setTimeout(paintForYou, 600);
{ const old = window.refreshHome; if (typeof old === 'function') window.refreshHome = function () { const r = old.apply(this, arguments); try { paintForYou(); } catch {} return r; }; }
