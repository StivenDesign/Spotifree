/* Ajustes extra: personalizar inicio y opciones del reproductor */
(function () {
  const HIDE = { hRecent: 'shRecent', hFy: 'forYou', hMyArt: 'shMyArt', hTop: 'shTop', hMine: 'shMine', hArtists: 'artists' };
  function apply() {
    Object.keys(HIDE).forEach((k) => document.body.classList.toggle('hide-' + k, CFG[k] === true));
  }
  apply();
  document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('[data-cfg]')) apply(); });

  // abrir la letra automáticamente al abrir el reproductor
  const oNP = window.openNP;
  if (typeof oNP === 'function') window.openNP = function () {
    const r = oNP.apply(this, arguments);
    if (CFG.autoLyr === true) setTimeout(() => { try { if (S.npOpen && !S.lyrOpen && typeof openLyr === 'function') openLyr(); } catch {} }, 450);
    return r;
  };

  // doble toque en la portada = me gusta
  let last = 0;
  const ab = document.getElementById('artbox');
  if (ab) ab.addEventListener('click', (e) => {
    if (CFG.dblLike === false) return;
    const now = Date.now();
    if (now - last < 320) {
      last = 0; e.stopPropagation();
      try {
        const t = S.queue[S.i]; if (t && typeof toggleLike === 'function') { toggleLike(t); haptic(12); }
      } catch {}
    } else last = now;
  });
})();
