'use strict';
/* ===== Música del teléfono: escaneo con MediaStore (solo Android) ===== */
const DEV_MEDIA = 'https://appassets.androidplatform.net/media/', DEV_ART = 'https://appassets.androidplatform.net/art/';
let DEV = store.get('sf_dev', []), devScanning = false, devAt = store.get('sf_devat', 0);
const devTrack = (r) => ({ local: true, dev: true, kind: 'device', did: String(r.id), title: r.title, artist: r.artist || '', album: r.album || '', duration: r.duration || 0, cover: DEV_ART + r.id + '?a=' + (r.albumId || 0), url: DEV_MEDIA + r.id });
const devTracks = () => DEV.map(devTrack);
const devCanScan = () => !!(window.Native && Native.scanMusic);
function devSizeText() { const el = $('devSub'); if (el) el.textContent = DEV.length ? `${DEV.length} canciones encontradas` : 'Busca toda la música guardada en el teléfono'; }
function devApply(list, quiet) {
  DEV = list.map((r) => ({ id: r.id, title: r.title, artist: r.artist, album: r.album, duration: r.duration, albumId: r.albumId }));
  devAt = Date.now(); try { store.set('sf_dev', DEV); store.set('sf_devat', devAt); } catch {}
  devSizeText(); if (typeof refreshLibViews === 'function') refreshLibViews();
  if (!quiet) toast(DEV.length ? `Encontré ${DEV.length} ${DEV.length === 1 ? 'canción' : 'canciones'} en tu teléfono` : 'No encontré música en el teléfono');
}
// ask=true pide el permiso si falta; quiet=true no avisa
async function scanDevice(ask = true, quiet = false) {
  if (!devCanScan()) { if (!quiet) toast('El escaneo funciona en la app de Android'); return; }
  if (devScanning) return; devScanning = true;
  const btn = $('devScanBtn'); if (btn) { btn.disabled = true; btn.textContent = 'Escaneando…'; }
  try {
    await new Promise((r) => setTimeout(r, 30));                    // deja pintar el estado antes de leer
    const out = Native.scanMusic(!!ask);
    if (out === 'perm') { if (ask) { window.__scanWait = true; if (!quiet) toast('Dame permiso para ver tu música'); } return; }
    devApply(JSON.parse(out || '[]'), quiet);
  } catch (e) { if (!quiet) toast('No pude escanear: ' + (e.message || 'error')); }
  finally { devScanning = false; if (btn) { btn.disabled = false; btn.textContent = DEV.length ? 'Escanear de nuevo' : 'Escanear ahora'; } }
}
window.__scanPerm = (ok) => { if (ok && window.__scanWait) { window.__scanWait = false; devScanning = false; scanDevice(false); } else if (!ok) { devScanning = false; toast('Sin permiso no puedo ver tu música'); const b = $('devScanBtn'); if (b) { b.disabled = false; b.textContent = 'Escanear ahora'; } } };
// canciones del teléfono que coinciden con una búsqueda
function devMatches(q, max = 5) {
  const n = (typeof normTxt === 'function' ? normTxt : (s) => String(s || '').toLowerCase())(q); if (!n || !DEV.length) return [];
  const f = (typeof normTxt === 'function' ? normTxt : (s) => String(s || '').toLowerCase());
  return DEV.filter((r) => f(r.title + ' ' + r.artist + ' ' + r.album).includes(n)).slice(0, max).map(devTrack);
}
// al abrir la app, si ya hay permiso, se actualiza la lista sin molestar
setTimeout(() => { if (devCanScan() && CFG.autoScan !== false && (DEV.length || store.get('sf_devask', false))) scanDevice(false, true); }, 4500);
document.addEventListener('click', (e) => { const b = e.target.closest('[data-act=scan-device]'); if (b) { store.set('sf_devask', true); scanDevice(true); } });
devSizeText();
