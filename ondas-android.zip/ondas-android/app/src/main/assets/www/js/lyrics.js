'use strict';
/* ===== Letras: varias fuentes, tira cerca de los botones y hoja completa ===== */
function renderSeg() {
  $('seg').innerHTML = '';
  PROVIDERS.forEach(([id, name]) => {
    const b = document.createElement('button'); b.textContent = name; b.className = CFG.prov === id ? 'on' : '';
    b.onclick = () => { CFG.prov = id; saveCfg(); renderSeg(); if (typeof syncSettingsUI === 'function') syncSettingsUI(); if (S.queue[S.i]) loadLyrics(S.queue[S.i]); };
    $('seg').append(b);
  });
}
function setStrip(cur, nxt, animate) {
  const c = $('stripCur'); c.textContent = cur; $('stripNxt').textContent = nxt || '';
  if (animate) { c.classList.remove('sw'); void c.offsetWidth; c.classList.add('sw'); }
  if (typeof paintNowLyr === 'function') paintNowLyr(cur);
}
/* doble toque en «Reproduciendo»: la línea actual aparece ahí, letra por letra con brillo */
let nlLast = null, nlLine = null;
function paintNowLyr(txt) {
  const box = $('nlLyr'); if (!box || !document.body.classList.contains('nl-on')) return;
  const ln = nlLine && nlLine.text === txt ? nlLine : null;
  if (txt === nlLast && !(ln && !ln._m)) return; nlLast = txt;
  box.innerHTML = ''; let k = 0;
  if (ln && ln._w && ln._w.length) {                       // palabra por palabra, siguiendo al cantante
    ln._m = ln._w.map((w, i) => { const sp = document.createElement('span'); sp.className = 'mw'; sp.textContent = w.text; sp.style.animationDelay = (i * 60) + 'ms'; if (w.p >= 0) sp.style.setProperty('--p', w.p); box.append(sp); if (i < ln._w.length - 1) box.append(' '); return sp; });
    return;
  }
  String(txt || '♪').split(' ').forEach((w, wi, arr) => {
    const word = document.createElement('span'); word.className = 'nw';
    [...w].forEach((ch) => { const c = document.createElement('i'); c.textContent = ch; c.style.animationDelay = (k++ * 32) + 'ms'; word.append(c); });
    box.append(word); if (wi < arr.length - 1) box.append(' ');
  });
}
(function nowLyrToggle() {
  const el = $('nowLbl'); if (!el) return; let last = 0;
  el.addEventListener('click', () => {
    const n = Date.now(); if (n - last > 380) { last = n; return; } last = 0;
    const on = document.body.classList.toggle('nl-on'); haptic(8); nlLast = null;
    if (on) { const L = S.lyrics, a = S.active; nlLine = L && a >= 0 ? L.lines[a] : null; if (nlLine) nlLine._m = null; paintNowLyr(L && L.synced && a >= 0 && L.lines[a] && L.lines[a].text ? L.lines[a].text : (L && L.lines && L.lines.length ? '♪' : 'Sin letra por ahora')); }
  });
})();
const fetchProvider = (p, t) => apiGet('lyrics', { provider: p, title: t.title, artist: t.artist, duration: t.duration || 0, appleId: t.appleId || '', videoId: t.videoId || '' });

// caché de letras de lo que ya escuchaste (se guarda en el teléfono; el límite se elige en Ajustes)
let LYC = store.get('sf_lyc', {});
function lycTrim() { const n = CFG.cacheN ?? 60, k = Object.keys(LYC); if (!n) { LYC = {}; } else if (k.length > n) k.sort((a, b) => (LYC[a].at || 0) - (LYC[b].at || 0)).slice(0, k.length - n).forEach((x) => delete LYC[x]); store.set('sf_lyc', LYC); }
async function loadLyrics(t) {
  const my = ++S.token;
  S.lyrics = null; S.active = -2; $('lbody').innerHTML = ''; $('lsrc').textContent = '';
  $('lstate').textContent = 'Buscando letra…'; setStrip('Sincronizando la letra…', '');
  const ck = tid(t) + '|' + CFG.prov;
  if (CFG.cacheN && LYC[ck] && LYC[ck].d) { S.lyrics = LYC[ck].d; LYC[ck].at = Date.now(); renderLyrics(); return; }
  const order = CFG.prov === 'auto' ? AUTO_ORDER : [CFG.prov];
  const errors = [];
  for (const p of order) {
    if (my !== S.token) return;
    try {
      const d = await fetchProvider(p, t);
      if (my !== S.token) return;
      S.lyrics = d; renderLyrics(); if (CFG.cacheN) { try { LYC[ck] = { d, at: Date.now() }; lycTrim(); } catch {} } return;
    } catch (e) { errors.push(PROVIDERS.find((x) => x[0] === p)[1] + ': ' + e.message); }
  }
  if (my === S.token) {
    $('lstate').textContent = 'No encontré letra para esta canción.'; $('lsrc').textContent = errors.join(' · ');
    setStrip('Sin letra para esta canción', 'Prueba otra fuente desde Letra');
  }
}
// Interludios: puntos de espera al inicio, entre estrofas con silencio largo y en las líneas vacías de la letra
function addInterludes(L) {
  if (!L.synced || L._dots) return; L._dots = true;
  const src = L.lines, out = [], est = (l) => Math.min(8, 1.2 + l.text.length * 0.075);
  const nextReal = (i) => { for (let k = i + 1; k < src.length; k++) if (src[k].text) return src[k]; return null; };
  const first = src.find((l) => l.text);
  if (first && first.time >= 4) out.push({ time: 0, end: first.time, text: '', dots: true });
  src.forEach((l, i) => {
    if (l.text === '') {
      const nx = nextReal(i);
      if (nx && nx.time - l.time >= 3) out.push({ time: l.time, end: nx.time, text: '', dots: true }); else out.push(l);
      return;
    }
    out.push(l);
    const nx = src[i + 1]; if (!nx || !nx.text) return;
    const e = l.end > l.time ? l.end : l.time + est(l);
    if (nx.time - e >= 5) out.push({ time: e + 0.4, end: nx.time, text: '', dots: true });
  });
  L.lines = out;
}
// Palabras con su tiempo: las de la fuente si las trae, o repartidas según el largo de cada una
function wordList(l, nextTime) {
  const end = l.end > l.time ? l.end : Math.min(nextTime || l.time + 4, l.time + Math.min(8, 1.2 + l.text.length * 0.075));
  let ws = [];
  if (l.words && l.words.length > 1) {
    let pos = 0;
    l.words.forEach((w, i) => {
      const tx = w.text.trim(), at = l.text.indexOf(tx, pos), stop = at < 0 ? pos : at + tx.length;
      ws.push({ t: w.t, text: tx + (l.text[stop] === ' ' ? ' ' : ''), e: l.words[i + 1] ? l.words[i + 1].t : end }); pos = stop;
    });
  } else {
    const parts = l.text.split(/(?<=\s)/).filter((x) => x), tot = parts.reduce((m, x) => m + x.trim().length + 1, 0) || 1;
    let t = l.time; const span = Math.max(0.6, end - l.time) * 0.92;
    parts.forEach((x) => { const d = span * (x.trim().length + 1) / tot; ws.push({ t, e: t + d, text: x }); t += d; });
  }
  return ws;
}
/* dúos sin datos de cantante: si la letra pone «Nombre:» o «[Nombre]» al inicio de la línea, cada nombre queda de un lado */
function inferAgents(L) {
  if (!L.synced || L.lines.some((l) => l.agent)) return;
  const sec = /^(verse|verso|chorus|coro|estribillo|intro|outro|bridge|puente|hook|pre|pre-?chorus|refr[aá]n|instrumental|solo|interlude|letra|lyrics)\b/i, found = [];
  L.lines.forEach((l) => {
    const m = /^\s*(?:\[([^\]]{2,26})\]|([A-Za-zÁÉÍÓÚÑáéíóúñ0-9 .&'-]{2,26}):)\s*(.*)$/.exec(l.text || ''); if (!m) return;
    const nm = (m[1] || m[2]).trim(); if (sec.test(nm)) return;
    found.push([l, nm, m[3]]);
  });
  const names = [...new Set(found.map((f) => f[1].toLowerCase()))];
  if (names.length < 2 || found.length < 3) return;
  let cur = null; const key = (n) => 'a' + names.indexOf(n.toLowerCase());
  const map = new Map(found.map((f) => [f[0], f]));
  L.lines.forEach((l) => { const f = map.get(l); if (f) { cur = f[1]; l.text = f[2]; if (l.words) l.words = null; } if (cur && l.text) l.agent = key(cur); });
}
function renderLyrics() {
  const L = S.lyrics, box = $('lbody'); box.innerHTML = ''; $('lstate').textContent = '';
  const name = PROVIDERS.find((x) => x[0] === L.provider)[1];
  $('lsrc').textContent = 'Letra de ' + name + (L.synced ? '' : ' · sin sincronizar');
  $('npFrom').textContent = 'Reproduciendo desde ' + (S.queue[S.i] && S.queue[S.i].local ? 'Tu música' : 'YouTube Music');
  inferAgents(L);
  addInterludes(L);
  // dúos: cada cantante en su lado (el primero a la izquierda, el segundo a la derecha, los coros al centro)
  const ags = [...new Set(L.lines.map((l) => l.agent).filter((a) => a && a !== 'v1000'))], duet = ags.length >= 2;
  L.lines.forEach((l, idx) => {
    const d = document.createElement('div');
    d.className = 'ln' + (!L.synced ? ' plain' : '') + (l.dots ? ' dots' : l.text === '' ? ' gap' : '') + (duet && l.agent ? (l.agent === 'v1000' ? ' sd-c' : ags.indexOf(l.agent) % 2 ? ' sd-r' : ' sd-l') : '');
    if (l.dots) { d.innerHTML = '<i></i><i></i><i></i>'; l._d = [...d.children]; }
    else if (L.synced && l.text) {
      const nx = L.lines.slice(idx + 1).find((x) => x.time > l.time);
      const wl = wordList(l, nx && nx.time); let depth = 0, bgN = 0, bgBox = null;
      wl.forEach((w) => { if (w.text.includes('(')) depth++; w.bg = depth > 0; if (w.bg) bgN++; if (w.text.includes(')')) depth = Math.max(0, depth - 1); w.text = w.text.replace(/[()]/g, ''); });
      const nz = (x) => (x || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim(), pv = L.lines[idx - 1];
      const echo = /^\s*[(\[].*[)\]]\s*$/.test(l.text);   // entre paréntesis o corchetes = eco / voz de fondo
      wl.forEach((w) => { w.text = w.text.replace(/[\[\]]/g, ''); });
      if (bgN === wl.length || echo) { d.classList.add('bgonly'); l._echo = true; }           // línea entera de coros: más pequeña
      l._w = wl.map((w) => {                                       // voces de fondo (entre paréntesis): letra pequeña que también brilla al cantarse
        const sp = document.createElement('span'); sp.className = 'w'; sp.textContent = w.text;
        if (w.bg && bgN !== wl.length) { if (!bgBox) { bgBox = document.createElement('span'); bgBox.className = 'bgv'; d.append(bgBox); } bgBox.append(sp); } else d.append(sp);
        w.el = sp; w.p = -1; return w; });
    } else d.textContent = l.text;
    if (L.synced && !l.dots) d.onclick = () => E.seek(Math.max(0, l.time - S.offset));
    l._el = d; box.append(d);
  });
  if (L.synced) lyrDist(L, -1);
  if (!L.synced) setStrip('Letra sin sincronizar', 'Toca para leerla completa'); else { S.active = -2; setStrip('♪', ''); }
}
function paintWords(l, now) {
  const ws = l._w; if (!ws) return;
  for (const w of ws) {
    const p = now <= w.t ? 0 : now >= w.e ? 100 : Math.round((now - w.t) / Math.max(0.05, w.e - w.t) * 50) * 2;
    const hold = now >= w.t && now < w.e && w.e - w.t >= 1.1;      // palabra larga: brilla y sus letras se mueven
    if (hold !== !!w.h) {
      w.h = hold;
      if (hold && !w.el.dataset.sp) {
        const tx = w.el.textContent, core = tx.replace(/\s+$/, ''); w.el.dataset.sp = 1; w.el.textContent = '';
        [...core].forEach((c, k) => { const i = document.createElement('i'); i.className = 'lt'; i.textContent = c; i.style.setProperty('--k', k); w.el.append(i); });
        if (tx.length > core.length) w.el.append(tx.slice(core.length));
      }
      w.el.classList.toggle('hold', hold);
    }
    if (p !== w.p) { w.p = p; w.el.style.setProperty('--p', p); if (l._m && l._m[ws.indexOf(w)]) l._m[ws.indexOf(w)].style.setProperty('--p', p); }
  }
}
function paintDots(l, now) {
  const pr = Math.max(0, Math.min(1, (now - l.time) / Math.max(0.5, l.end - l.time)));
  l._d.forEach((d, k) => { const f = Math.max(0, Math.min(1, pr * 3.2 - k * 0.9)); d.style.setProperty('--f', f.toFixed(2)); d.classList.toggle('f', f > 0.02); });
  l._el.classList.toggle('all', pr >= 0.82);
  l._el.classList.toggle('out', l.end - now < 0.6);
}
/* como Apple Music: la línea activa en blanco, las demás se apagan y se desenfocan según su distancia; el eco pequeño solo se abre bajo la línea que suena */
function lyrDist(L, a) {
  const calm = (typeof LITE !== 'undefined' && LITE) || CFG.perf || document.body.classList.contains('lite') || CFG.noBlurLn;
  L.lines.forEach((l, i) => {
    const e = l._el; if (!e || l.dots) return;
    const d = i - a, ad = Math.abs(d);
    const show = i === a || (i === a + 1 && l._echo && !(L.lines[a] && L.lines[a]._echo));   // el eco aparece cuando suena su línea
    if (l._echo) e.classList.toggle('show', show);
    let op, bl, sc;
    if (i === a) { op = 1; bl = 0; sc = 1; }
    else if (d > 0) { op = Math.max(.16, .5 - (d - 1) * .12); bl = Math.min(2.2, .5 + (d - 1) * .5); sc = .97; }
    else { op = ad === 1 ? .34 : .18; bl = Math.min(2, .7 + ad * .4); sc = .95; }
    if (l._echo) op = i === a ? .95 : .55;
    e.style.setProperty('--op', op); e.style.setProperty('--bl', (calm ? 0 : bl) + 'px'); e.style.setProperty('--sc', sc);
  });
}
function syncLyrics(cur) {
  const L = S.lyrics; if (!L || !L.synced) return;
  const now = cur + S.offset + (CFG.lyrOff || 0) / 1000, n = L.lines.length, k = S.active;
  if (k >= 0 && k < n && L.lines[k].time <= now && (k + 1 >= n || L.lines[k + 1].time > now)) {   // sigue la misma línea: solo el brillo de las palabras
    const l = L.lines[k]; if (l.dots) paintDots(l, now); else paintWords(l, now); return;
  }
  let a = -1;
  for (let i = 0; i < n; i++) { if (L.lines[i].time <= now) a = i; else break; }
  if (a === S.active) return;
  S.active = a;
  L.lines.forEach((l, i) => { l._el.classList.toggle('on', i === a); l._el.classList.toggle('past', i < a); if (l._w && i !== a) l._w.forEach((w) => { w.p = -1; w.el.style.removeProperty('--p'); }); });
  if (a >= 0) { const l = L.lines[a]; if (l.dots) paintDots(l, now); else paintWords(l, now); }
  lyrDist(L, a);
  nlLine = a >= 0 ? L.lines[a] : null; if (nlLine) nlLine._m = null;
  let nxt = ''; for (let k2 = a + 1; k2 < L.lines.length; k2++) if (L.lines[k2].text) { nxt = L.lines[k2].text; break; }
  setStrip(a >= 0 && L.lines[a].text ? L.lines[a].text : '♪', nxt, true);
  const go = () => { if (a >= 0 && (S.lyrOpen || S.land) && S.active === a) { const el = L.lines[a]._el, box = $('lbody'); box.scrollTo({ top: el.offsetTop - box.clientHeight * (document.body.classList.contains('land') || document.body.classList.contains('karaoke') ? 0.34 : 0.17), behavior: 'smooth' }); } };
  go(); if (a >= 0 && L.lines[a].dots) setTimeout(go, 480); else setTimeout(go, 560);   // el eco se abre/cierra: se reajusta   // los puntos crecen: se recentra al terminar
}
renderSeg();
