'use strict';
/* ===== Navegación: pestañas inferiores, hojas, atrás y gesto para cerrar el reproductor ===== */
const NAV = { tab: 'home', order: ['home', 'news', 'radio', 'lib', 'search'], scroll: {}, inited: {} };
const SH = [];                                   // pila de hojas abiertas

/* la burbuja se estira y se despega al cambiar de pestaña, y se puede arrastrar con el dedo */
function stretchInd(dist) {
  const ind = $('tabInd'); if (!ind.animate || CFG.perf || matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  const sx = 1 + Math.min(.55, .22 + dist * .12);
  ind.animate([{ scale: '1 1' }, { scale: `${sx} 1.16`, offset: .4 }, { scale: '1 1' }], { duration: 620, easing: 'cubic-bezier(.34,1.3,.5,1)' });
}
(function tabDrag() {
  const bar = $('tabbar'); let on = false, moved = false, x0 = 0, i0 = 0, pid = -1;
  const cols = () => NAV.order.length - 1;                               // la búsqueda va aparte
  const idxAt = (x) => { const r = bar.getBoundingClientRect(), pad = 5, w = (r.width - pad * 2) / cols(); return Math.max(0, Math.min(cols() - 1, (x - r.left - pad) / w - .5)); };
  bar.addEventListener('pointerdown', (e) => { on = true; moved = false; x0 = e.clientX; pid = e.pointerId; i0 = Math.min(cols() - 1, NAV.order.indexOf(NAV.tab)); });
  bar.addEventListener('pointermove', (e) => {
    if (!on) return;
    if (!moved && Math.abs(e.clientX - x0) < 8) return;
    if (!moved) { moved = true; bar.classList.add('drag', 'lift'); bar.classList.remove('no-ind'); try { bar.setPointerCapture(pid); } catch {} haptic(6); }
    bar.style.setProperty('--i', idxAt(e.clientX).toFixed(3));
  });
  const end = (e) => {
    if (!on) return; on = false;
    if (!moved) return;
    const to = Math.round(idxAt(e.clientX)); bar.classList.remove('drag', 'lift');
    bar.style.setProperty('--i', to); bar.dataset.dragged = '1'; setTimeout(() => delete bar.dataset.dragged, 60);
    if (NAV.order[to] === NAV.tab) { bar.classList.toggle('no-ind', NAV.tab === 'search'); bar.style.setProperty('--i', NAV.order.indexOf(NAV.tab)); } else goTab(NAV.order[to]);
  };
  bar.addEventListener('pointerup', end); bar.addEventListener('pointercancel', end);
  bar.addEventListener('click', (e) => { if (bar.dataset.dragged) { e.stopPropagation(); e.preventDefault(); } }, true);
})();
function goTab(name, opts = {}) {
  if (!NAV.order.includes(name)) return;
  const prev = NAV.tab, cur = $('v-' + name);
  if (name === prev && !opts.force) {                       // tocar la pestaña activa sube al inicio
    const sc = cur.querySelector('.vscroll'); if (sc) sc.scrollTo({ top: 0, behavior: 'smooth' });
    if (name === 'search') { const q = $('q'); if (q) q.focus(); }
    return;
  }
  const dir = NAV.order.indexOf(name) > NAV.order.indexOf(prev) ? 1 : -1;
  $('v-' + prev).style.setProperty('--dir', dir); cur.style.setProperty('--dir', dir);
  const old = $('v-' + prev), oldSc = old.querySelector('.vscroll');
  NAV.scroll[prev] = oldSc ? oldSc.scrollTop : 0;
  old.classList.remove('on'); old.classList.add('out');
  setTimeout(() => old.classList.remove('out'), 230);
  cur.hidden = false; cur.classList.add('on');
  const sc = cur.querySelector('.vscroll'); if (sc) sc.scrollTop = NAV.scroll[name] || 0;
  NAV.tab = name;
  document.querySelectorAll('.tab').forEach((b) => { const on = b.dataset.tab === name; b.classList.toggle('on', on); on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current'); });
  $('tabbar').style.setProperty('--i', NAV.order.indexOf(name)); $('tabbar').classList.toggle('no-ind', name === 'search');
  stretchInd(Math.abs(NAV.order.indexOf(name) - NAV.order.indexOf(prev)));
  $('tint').style.opacity = name === 'home' ? '.9' : name === 'search' ? '.35' : '.6';
  if (!opts.silent) haptic(6);
  if (typeof onTabShow === 'function') onTabShow(name);
}
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-tab]'); if (t && t.classList.contains('tab')) return goTab(t.dataset.tab);
  const g = e.target.closest('[data-go]'); if (g) goTab(g.dataset.go);
});

/* ---------- hojas ---------- */
function openSheet(id) {
  const s = $(id); if (!s || s.classList.contains('open')) return;
  s.hidden = false; void s.offsetWidth; s.classList.add('open'); SH.push(id);
  document.body.classList.add('set-open'); haptic(6);
}
function closeSheet(id) {
  const s = $(id); if (!s || !s.classList.contains('open')) return;
  if (id === 'mixs' && typeof mixLeave === 'function') mixLeave();
  s.classList.remove('open');
  const i = SH.lastIndexOf(id); if (i >= 0) SH.splice(i, 1);
  if (!SH.length) document.body.classList.remove('set-open');
  setTimeout(() => { if (!s.classList.contains('open')) s.hidden = true; }, 640);
}
// tocar el fondo oscuro cierra la hoja
document.addEventListener('click', (e) => {
  const s = e.target.classList && e.target.classList.contains('sheet') ? e.target : null;
  if (s && s.id !== 'coll') closeSheet(s.id);
});

/* ---------- menú contextual ---------- */
function openMenu(head, items) {
  const wrap = $('menu');
  $('menuHead').innerHTML = head ? `${head.cover ? `<img src="${esc(head.cover)}" alt="">` : ''}<div><b>${esc(head.title || '')}</b><small class="mh-a">${esc(head.sub || '')}</small>${head.album ? `<small class="mh-b">${esc(head.album)}</small>` : ''}</div>` : '';
  const box = $('menuItems'); box.innerHTML = '';
  items.filter(Boolean).forEach((it) => {
    const b = document.createElement('button'); b.setAttribute('role', 'menuitem');
    b.innerHTML = `<svg class="ic s"><use href="#i-${it.icon || 'note'}"/></svg><span>${esc(it.label)}</span>`;
    b.onclick = () => { if (!it.keep) closeMenu(); it.run(); };
    box.append(b);
  });
  wrap.hidden = false;
}
function closeMenu() { $('menu').hidden = true; }

/* ---------- botón atrás de Android ---------- */
window.__back = () => {
  if (!$('cfg').hidden) { $('cfg').hidden = true; return true; }
  if (!$('menu').hidden) { closeMenu(); return true; }
  if (SH.length) { const id = SH[SH.length - 1]; if (id === 'coll') closeColl(); else closeSheet(id); return true; }
  if (S.lyrOpen) { closeLyr(); return true; }
  if (S.npOpen) { closeNP(); return true; }
  if (NAV.tab !== 'home') { goTab('home'); return true; }
  return false;
};

/* ---------- teclado: oculta la barra inferior mientras se escribe ---------- */
if (window.visualViewport) {
  const base = window.innerHeight;
  visualViewport.addEventListener('resize', () => document.body.classList.toggle('kb', visualViewport.height < base * 0.75));
}

/* ---------- gesto: arrastrar hacia abajo para cerrar el reproductor ---------- */
(function dragToClose() {
  const np = $('np'); let y0 = 0, dy = 0, on = false, drag = false, t0 = 0, pid = 0;
  /* se puede arrastrar desde casi cualquier parte (también desde la rayita de arriba), menos botones y barras */
  const zone = (el) => !el.closest('input,.lyr,#queV,#lopts,.kpanel') && (!el.closest('button') || !!el.closest('.grab'));
  np.addEventListener('pointerdown', (e) => {
    if (S.lyrOpen || S.queOpen || !zone(e.target)) return;
    on = true; drag = false; y0 = e.clientY; dy = 0; t0 = performance.now(); pid = e.pointerId;
  });
  np.addEventListener('pointermove', (e) => {
    if (!on) return;
    dy = Math.max(0, e.clientY - y0);
    if (!drag) { if (dy < 8) return; drag = true; np.classList.add('drag'); try { np.setPointerCapture(pid); } catch {} }   // solo es arrastre si se mueve: un toque sigue siendo un toque
    np.style.setProperty('--dy', dy * 0.9 + 'px');
    np.style.transform = `translateY(${dy * 0.9}px) scale(${1 - Math.min(dy, 600) / 6000})`;
  });
  const end = () => {
    if (!on) return; on = false;
    if (!drag) return;
    drag = false; np.classList.remove('drag');
    const v = dy / Math.max(1, performance.now() - t0);        // velocidad
    np.style.transform = ''; np.style.removeProperty('--dy');
    if (dy > 140 || v > 0.6 && dy > 40) closeNP();
  };
  np.addEventListener('pointerup', end); np.addEventListener('pointercancel', end);
})();
