'use strict';
/* ===== Extras: aleatorio y repetir, temporizador, velocidad, ecualizador, resumen, acento y gestos ===== */

/* ---------- aleatorio y repetir ---------- */
function paintModes() {
  $('btnShuffle').classList.toggle('on', !!CFG.shuffle);
  const r = $('btnRepeat'); r.classList.toggle('on', CFG.repeat > 0); r.dataset.r = CFG.repeat;
}
function toggleShuffle() {
  CFG.shuffle = !CFG.shuffle; saveCfg();
  if (S.queue.length > 1 && S.i >= 0) {
    const cur = S.queue[S.i];
    if (CFG.shuffle) {
      const rest = S.queue.filter((_, k) => k !== S.i);
      for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
      S.orig = S.queue.slice(); S.queue = [cur, ...rest]; S.i = 0;
    } else if (S.orig) { S.queue = S.orig; S.i = Math.max(0, S.queue.indexOf(cur)); S.orig = null; }
    renderQueue();
  }
  paintModes(); haptic(8); toast(CFG.shuffle ? 'Aleatorio activado' : 'Aleatorio desactivado');
}
function cycleRepeat() {
  CFG.repeat = (CFG.repeat + 1) % 3; saveCfg(); paintModes(); haptic(8);
  toast(['Repetir: apagado', 'Repetir toda la lista', 'Repetir esta canción'][CFG.repeat]);
}

/* ---------- temporizador de sueño ---------- */
function sleepLabel() { return S.sleepEnd ? 'Al terminar la canción' : S.sleepAt ? `Quedan ${Math.max(1, Math.ceil((S.sleepAt - Date.now()) / 60000))} min` : 'Apagado'; }
function paintSleep() { document.body.classList.toggle('sleep-on', !!(S.sleepAt || S.sleepEnd)); const el = $('sleepSub'); if (el) el.textContent = sleepLabel(); }
function clearSleep(quiet) { clearTimeout(S.sleepTimer); S.sleepAt = 0; S.sleepEnd = false; paintSleep(); if (!quiet) toast('Temporizador desactivado'); }
function setSleep(min) {
  clearSleep(true);
  if (min < 0) { S.sleepEnd = true; toast('Se pausará al terminar la canción'); }
  else { S.sleepAt = Date.now() + min * 60000; S.sleepTimer = setTimeout(sleepFire, min * 60000); toast(`Se pausará en ${min} minutos`); }
  paintSleep();
}
function sleepFire() {
  clearSleep(true);
  if (!S.playing) return;
  const v = outVol();
  fade(v, 0, 3000, () => { E.toggle(); E.vol(v); toast('Temporizador: música pausada'); });
}
function sleepMenu() {
  openMenu({ title: 'Temporizador de sueño', sub: sleepLabel() }, [
    ...[15, 30, 45, 60, 90].map((m) => ({ icon: 'moon', label: `${m} minutos`, run: () => setSleep(m) })),
    { icon: 'note', label: 'Al terminar la canción', run: () => setSleep(-1) },
    S.sleepAt || S.sleepEnd ? { icon: 'x', label: 'Desactivar', run: () => clearSleep() } : null,
  ]);
}

/* ---------- velocidad ---------- */
function paintSpeed() { const el = $('speedSub'); if (el) el.textContent = (CFG.rate || 1) + '×'; }
function speedMenu() {
  openMenu({ title: 'Velocidad de reproducción', sub: (CFG.rate || 1) + '×' }, [0.75, 0.9, 1, 1.15, 1.25, 1.5, 2].map((v) => ({
    icon: (CFG.rate || 1) === v ? 'check' : 'chart', label: v === 1 ? 'Normal (1×)' : v + '×', run: () => { CFG.rate = v; saveCfg(); applyRate(); paintSpeed(); toast('Velocidad ' + v + '×'); },
  })));
}

/* ---------- ecualizador de audio (música local y descargas) ---------- */
const EQ_FREQS = ['60 Hz', '230 Hz', '910 Hz', '3,6 kHz', '14 kHz'];
const EQ_PRESETS = { Plano: [0, 0, 0, 0, 0], Graves: [7, 4, 0, -1, -1], Agudos: [-2, -1, 0, 4, 7], Vocal: [-3, 0, 4, 3, -1], Rock: [5, 2, -2, 3, 5], Pop: [-1, 3, 4, 2, -1], Electrónica: [6, 3, 0, 2, 5], Acústico: [3, 2, 1, 2, 2] };
function setEqGains(arr) {
  CFG.eqg = arr.slice(); saveCfg();
  if (AN.filters) AN.filters.forEach((f, i) => { try { f.gain.value = arr[i]; } catch {} });
  paintEq();
}
function paintEq() {
  const g = CFG.eqg || [0, 0, 0, 0, 0];
  $('eqBands').querySelectorAll('input').forEach((inp, i) => { inp.value = g[i]; inp.style.setProperty('--p', ((g[i] + 12) / 24 * 100) + '%'); inp.parentElement.querySelector('output').textContent = (g[i] > 0 ? '+' : '') + g[i] + ' dB'; });
  const key = Object.keys(EQ_PRESETS).find((k) => EQ_PRESETS[k].every((v, i) => v === g[i]));
  $('eqPresets').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.p === key));
}
function initEq() {
  Object.keys(EQ_PRESETS).forEach((k) => { const b = document.createElement('button'); b.dataset.p = k; b.textContent = k; b.onclick = () => { haptic(6); setEqGains(EQ_PRESETS[k]); }; $('eqPresets').append(b); });
  EQ_FREQS.forEach((f, i) => {
    const row = document.createElement('label'); row.className = 'item eqrow';
    row.innerHTML = `<span>${f}</span><input type="range" min="-12" max="12" step="1" value="0" aria-label="${f}"><output>0 dB</output>`;
    row.querySelector('input').addEventListener('input', (e) => { const g = (CFG.eqg || [0, 0, 0, 0, 0]).slice(); g[i] = +e.target.value; setEqGains(g); });
    $('eqBands').append(row);
  });
  paintEq();
}

/* ---------- resumen: lo que más escuchas ---------- */
const STATS = Object.assign({ plays: {}, secs: 0 }, store.get('sf_stats', {}));
const saveStats = () => store.set('sf_stats', STATS);
function recordPlay(t) {
  const id = tid(t), p = STATS.plays[id] || (STATS.plays[id] = { n: 0 });
  p.n++; p.track = slim(t); saveStats();
  if (typeof refreshHome === 'function') refreshHome();
}
setInterval(() => { if (S.playing) { STATS.secs++; if (STATS.secs % 20 === 0) saveStats(); } }, 1000);
function topTracks(n) { return Object.values(STATS.plays).sort((a, b) => b.n - a.n).slice(0, n); }
function renderStats() {
  const all = Object.values(STATS.plays), total = all.reduce((s, p) => s + p.n, 0), h = Math.floor(STATS.secs / 3600), m = Math.floor(STATS.secs % 3600 / 60);
  const art = {}; all.forEach((p) => { const a = p.track.artist || 'Desconocido'; art[a] = (art[a] || 0) + p.n; });
  const topA = Object.entries(art).sort((a, b) => b[1] - a[1]).slice(0, 5), top = topTracks(8).map((p) => p.track);
  const box = $('statsBody');
  box.innerHTML = `<div class="stat-grid"><div class="glass"><b>${h ? h + ' h ' : ''}${m} min</b><small>escuchados</small></div><div class="glass"><b>${total}</b><small>reproducciones</small></div><div class="glass"><b>${all.length}</b><small>canciones distintas</small></div></div>`;
  if (!total) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">Todavía no hay datos. Escucha música y aquí verás tu resumen.</p>'); return; }
  box.insertAdjacentHTML('beforeend', '<h3>Canciones favoritas</h3><div class="list" id="statTop" style="padding:0"></div>');
  fillList($('statTop'), top, {});
  box.insertAdjacentHTML('beforeend', '<h3>Artistas favoritos</h3><div class="group glass" id="statArt"></div>');
  topA.forEach(([a, n], i) => $('statArt').insertAdjacentHTML('beforeend', `<div class="item"><div><b>${i + 1}. ${esc(a)}</b></div><small>${n} ${n === 1 ? 'vez' : 'veces'}</small></div>`));
  box.insertAdjacentHTML('beforeend', '<button class="pill glass" id="statReset" style="margin-top:18px">Borrar mi resumen</button>');
  $('statReset').onclick = () => { STATS.plays = {}; STATS.secs = 0; saveStats(); renderStats(); refreshHome(); toast('Resumen borrado'); };
}

/* ---------- color de acento ---------- */
const ACCENTS = { Rosado: '#fa2d55', Verde: '#1ed760', Violeta: '#a78bfa', Rosa: '#ff5c8a', Azul: '#4dabff', Naranja: '#ff9f43', Auto: 'auto' };
function applyAccent() {
  const v = ACCENTS[CFG.accent] || ACCENTS.Rosado;
  document.documentElement.style.setProperty('--accfg', ['Verde', 'Naranja', 'Auto'].includes(CFG.accent) ? '#000' : '#fff');
  document.documentElement.style.setProperty('--acc', v === 'auto' ? 'var(--c1)' : v);
  document.querySelectorAll('#accSw button').forEach((b) => b.classList.toggle('on', b.dataset.a === CFG.accent));
}
function initAccent() {
  Object.keys(ACCENTS).forEach((k) => {
    const b = document.createElement('button'); b.dataset.a = k; b.setAttribute('aria-label', k); b.title = k;
    b.style.background = ACCENTS[k] === 'auto' ? 'conic-gradient(#fa2d55,#1ed760,#4dabff,#a78bfa,#ff9f43,#fa2d55)' : ACCENTS[k];
    b.onclick = () => { CFG.accent = k; saveCfg(); applyAccent(); haptic(8); }; $('accSw').append(b);
  });
  applyAccent();
}

/* ---------- gestos ---------- */
// doble toque en la portada = me gusta
(function dblLike() {
  let last = 0; const w = $('np');
  w.addEventListener('pointerup', (e) => {
    const r = $('artbox').getBoundingClientRect();                       // el gesto de cerrar captura el puntero, así que se mide por posición
    if (S.lyrOpen || e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return;
    const now = Date.now();
    if (now - last < 320) {
      last = 0; const t = S.queue[S.i]; if (!t) return;
      const h = document.createElement('div'); h.className = 'burst-heart'; h.innerHTML = '<svg class="ic"><use href="#i-heart"/></svg>';
      $('artbox').append(h); setTimeout(() => h.remove(), 900);
      if (!isLiked(t)) toggleLike(t); else haptic(10);
    } else last = now;
  });
})();
// deslizar el mini reproductor a los lados cambia de canción
(function miniSwipe() {
  const m = $('mini'), main = m.querySelector('.main'); let sx = 0, sy = 0, dx = 0, drag = false, down = false;
  main.addEventListener('pointerdown', (e) => { down = true; drag = false; sx = e.clientX; sy = e.clientY; dx = 0; });
  main.addEventListener('pointermove', (e) => {
    if (!down) return; dx = e.clientX - sx;
    if (!drag && Math.abs(dx) > 14 && Math.abs(e.clientY - sy) < 30) { drag = true; m.style.transition = 'none'; }
    if (drag) { m.style.transform = `translateX(${dx * 0.6}px)`; m.style.opacity = 1 - Math.min(0.5, Math.abs(dx) / 400); }
  });
  const end = () => {
    if (!down) return; down = false;
    if (drag) {
      m.style.transition = 'transform .45s cubic-bezier(.34,1.56,.64,1),opacity .3s';
      if (Math.abs(dx) > 70) { haptic(10); dx < 0 ? next() : prev(); }
      m.style.transform = ''; m.style.opacity = ''; setTimeout(() => (m.style.transition = ''), 480);
      main._sw = true; setTimeout(() => (main._sw = false), 60);
    }
  };
  main.addEventListener('pointerup', end); main.addEventListener('pointercancel', end);
  main.addEventListener('click', (e) => { if (main._sw) { e.stopImmediatePropagation(); e.preventDefault(); } }, true);
})();
// tirar hacia abajo para actualizar Inicio y Novedades
function pullToRefresh(viewId, fn) {
  const sc = document.querySelector(`#${viewId} .vscroll`); let y0 = null, d = 0;
  const ind = document.createElement('div'); ind.className = 'ptr'; ind.innerHTML = '<svg class="ic s"><use href="#i-refresh"/></svg>'; sc.parentElement.append(ind);
  sc.addEventListener('touchstart', (e) => { y0 = sc.scrollTop <= 0 ? e.touches[0].clientY : null; d = 0; }, { passive: true });
  sc.addEventListener('touchmove', (e) => {
    if (y0 == null) return; d = Math.max(0, e.touches[0].clientY - y0);
    if (d > 0) { ind.style.transition = 'none'; ind.style.opacity = Math.min(1, d / 80); ind.style.transform = `translate(-50%,${Math.min(d, 120) * 0.6}px) rotate(${d * 3}deg)`; }
  }, { passive: true });
  sc.addEventListener('touchend', () => {
    ind.style.transition = '';
    if (y0 != null && d > 85) { ind.classList.add('spin'); ind.style.opacity = 1; ind.style.transform = 'translate(-50%,56px)'; haptic(12); Promise.resolve(fn()).finally(() => setTimeout(() => { ind.classList.remove('spin'); ind.style.opacity = 0; ind.style.transform = 'translate(-50%,0)'; }, 400)); }
    else { ind.style.opacity = 0; ind.style.transform = 'translate(-50%,0)'; }
    y0 = null;
  });
}

/* ---------- acciones ---------- */
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act;
  if (a === 'shuffle') toggleShuffle(); else if (a === 'repeat') cycleRepeat();
  else if (a === 'sleep') { closeSheet('set'); sleepMenu(); } else if (a === 'speed') { closeSheet('set'); speedMenu(); }
  else if (a === 'open-eqs') { closeSheet('set'); openSheet('eqs'); paintEq(); } else if (a === 'close-eqs') closeSheet('eqs');
  else if (a === 'open-stats') { closeSheet('set'); renderStats(); openSheet('stats'); } else if (a === 'close-stats') closeSheet('stats');
});
setInterval(paintSleep, 20000);

initEq(); initAccent(); paintModes(); paintSleep(); paintSpeed();
pullToRefresh('v-home', () => loadHome(true));
pullToRefresh('v-news', () => loadNews(true));
