/* Compartir una tarjeta con la letra: eliges de 1 a 5 líneas en una lista con scroll y se genera una imagen */
const LSH_MAX = 5;
function lyrShareLines() { const L = S.lyrics; if (!L || !L.lines) return []; return L.lines.filter((l) => !l.dots && l.text && l.text.trim()).map((l) => l.text.replace(/\s+/g, ' ').replace(/[()]/g, '').trim()).filter(Boolean); }
async function lyrCard(t, lines, im) {
  const { cv, x } = cardBase(im ? avgColor(im) : [120, 30, 50]);
  x.save(); rrect(x, 90, 100, 150, 150, 26); x.fillStyle = '#222'; x.fill(); x.clip(); if (im) x.drawImage(im, 90, 100, 150, 150); x.restore();
  x.textAlign = 'left'; x.fillStyle = '#fff'; x.font = '800 46px Inter, system-ui, sans-serif'; x.fillText((t.title || '').slice(0, 26), 270, 160);
  x.font = '600 36px Inter, system-ui, sans-serif'; x.fillStyle = 'rgba(255,255,255,.72)'; x.fillText((t.artist || '').slice(0, 32), 270, 215);
  let size = 78, blocks = [];
  for (; size >= 40; size -= 4) { x.font = `800 ${size}px Inter, system-ui, sans-serif`; blocks = lines.map((l) => wrapLines(x, l, 900, 4)); const n = blocks.reduce((s, b) => s + b.length, 0); if (n * size * 1.2 + (lines.length - 1) * 26 <= 800) break; }
  x.fillStyle = '#fff'; x.font = `800 ${size}px Inter, system-ui, sans-serif`;
  let y = 400 + size; blocks.forEach((b) => { b.forEach((l) => { x.fillText(l, 90, y); y += size * 1.2; }); y += 26; });
  x.textAlign = 'left'; x.fillStyle = 'rgba(255,255,255,.75)'; x.font = '700 38px Inter, system-ui, sans-serif'; x.fillText('Spotifree', 90, 1270);
  return cv;
}
async function openLyrShare() {
  const t = curT(), all = lyrShareLines(); if (!t) return toast('Primero pon una canción'); if (!all.length) return toast('Esta canción no tiene letra');
  document.getElementById('lsh')?.remove();
  const im = await loadImg(t.hdCover || t.cover), sel = new Set(), L = S.lyrics, cur = S.active >= 0 && L.lines[S.active] ? L.lines[S.active].text.replace(/\s+/g, ' ').replace(/[()]/g, '').trim() : '';
  let st = Math.max(0, all.indexOf(cur)); for (let i = st; i < Math.min(all.length, st + 4); i++) sel.add(i);
  const el = document.createElement('div'); el.id = 'lsh'; el.innerHTML = '<div class="lsh-top"><button class="lsh-x" aria-label="Cerrar"><svg class="ic s"><use href="#i-x"/></svg></button><b>Compartir letra</b><span class="lsh-n"></span></div><div class="lsh-prev"></div><div class="lsh-hint">Toca las líneas que quieres (de 1 a 5)</div><div class="lsh-list"></div><button class="lsh-go">Compartir</button>';
  document.body.append(el); requestAnimationFrame(() => el.classList.add('on'));
  const list = el.querySelector('.lsh-list'), prev = el.querySelector('.lsh-prev'), go = el.querySelector('.lsh-go'), nn = el.querySelector('.lsh-n');
  all.forEach((l, i) => { const b = document.createElement('button'); b.className = 'lsh-row' + (sel.has(i) ? ' on' : ''); b.innerHTML = `<i></i><span>${esc(l)}</span>`; b.onclick = () => { if (sel.has(i)) sel.delete(i); else { if (sel.size >= LSH_MAX) return toast('Máximo ' + LSH_MAX + ' líneas'); sel.add(i); } b.classList.toggle('on', sel.has(i)); haptic(5); draw(); }; list.append(b); });
  let busy = 0; async function draw() { nn.textContent = sel.size + '/' + LSH_MAX; go.disabled = !sel.size; const ls = [...sel].sort((a, b) => a - b).map((i) => all[i]); const k = ++busy; const cv = await lyrCard(t, ls.length ? ls : ['…'], im); if (k !== busy) return; prev.innerHTML = ''; prev.append(cv); }
  draw(); const first = list.querySelector('.on'); if (first) setTimeout(() => list.scrollTo({ top: Math.max(0, first.offsetTop - 60), behavior: 'smooth' }), 300);
  const close = () => { el.classList.remove('on'); setTimeout(() => el.remove(), 350); };
  el.querySelector('.lsh-x').onclick = close;
  go.onclick = async () => {
    const ls = [...sel].sort((a, b) => a - b).map((i) => all[i]); if (!ls.length) return; go.disabled = true;
    try {
      const cv = await lyrCard(t, ls, im), name = 'spotifree-letra-' + Date.now() + '.png', b64 = cv.toDataURL('image/png').split(',')[1];
      if (window.Native && Native.shareImage && Native.shareImage(name, b64) === 'ok') { close(); return; }
      const blob = await new Promise((r) => cv.toBlob(r, 'image/png')), f = new File([blob], name, { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f] }); close(); return; }
      saveCard(cv, name); close();
    } catch { toast('No pude crear la tarjeta'); go.disabled = false; }
  };
}

/* ---------- carátulas: si tardan en cargar se ve el indicador de carga ---------- */
(function () {
  const chk = (im) => { if (im.complete || !im.src || /^data:/.test(im.src)) return; clearTimeout(im._ld); im._ld = setTimeout(() => { if (!im.complete) im.classList.add('ld'); }, 250); };
  const done = (e) => { const t = e.target; if (t && t.tagName === 'IMG') { clearTimeout(t._ld); t.classList.remove('ld'); } };
  document.addEventListener('load', done, true); document.addEventListener('error', done, true);
  new MutationObserver((ms) => ms.forEach((m) => {
    if (m.type === 'attributes') { if (m.target.tagName === 'IMG') chk(m.target); return; }
    m.addedNodes.forEach((n) => { if (n.nodeType !== 1) return; if (n.tagName === 'IMG') chk(n); else if (n.querySelectorAll) n.querySelectorAll('img').forEach(chk); });
  })).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
  document.querySelectorAll('img').forEach(chk);
})();
