# Spotifree para Android

Reproductor con YouTube Music, interfaz estilo Apple Music con vidrio líquido, letras sincronizadas
(Better Lyrics, KuGou, Apple Music, LRCLIB), música local, modo video y portadas en movimiento.
Todo corre dentro de la app, sin servidor. Creada por Claude para Steven Pantoja.

## Cómo generar el APK (GitHub, sin Android Studio)

1. Entra a tu repositorio y sube este zip con el mismo nombre (`ondas-android.zip`). Reemplaza al anterior.
2. Abre la pestaña Actions y espera la palomita verde (unos 5 minutos).
3. En Releases baja el nuevo `app-debug.apk` e instálalo.

Spotifree se instala como una app nueva (no reemplaza a Ondas). Después de comprobar que funciona
puedes desinstalar Ondas.

## Qué trae

- **Mi música**: toca Añadir y elige archivos de audio del teléfono. Se leen título, artista, álbum y portada.
- **Modo video**: botón Video en el reproductor, para ver el video de canciones de YouTube.
- **Videos**: en los resultados cambia entre Canciones y Videos.
- **Canvas**: botón Canvas para poner un video corto o GIF como portada de una canción.
- **Portada en movimiento**: busca el video animado que Apple Music publica del álbum. Si no hay, anima la imagen.
- **Ajustes**: fuente de letras, ecualizador, portada en movimiento, fondo animado y borrado de datos.
- **Acerca de**: créditos y agradecimientos.

## Notas

- El ecualizador de archivos locales usa el espectro real del audio. En canciones de YouTube es una animación
  que sigue el ritmo, porque YouTube no deja leer su audio.
- Las letras de Apple Music necesitan tus tokens (Ajustes > Apple Music).
- Las APIs de YouTube Music, Better Lyrics, KuGou y Apple no son oficiales y pueden cambiar.
- Spotifree no descarga música de YouTube.
