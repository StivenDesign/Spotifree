# Ondas para Android

App Android (WebView + Kotlin) con YouTube Music, interfaz estilo Apple Music, letras sincronizadas
(Better Lyrics, KuGou, Apple Music, LRCLIB) y portada animada. Todo corre dentro de la app, sin servidor.

## Opción A: compilar con GitHub (sin Android Studio)

1. Crea una cuenta en github.com y un repositorio nuevo (privado está bien).
2. Sube el contenido de esta carpeta, incluida la carpeta oculta `.github`.
   - En computadora: descomprime el zip y arrastra todo a la página del repositorio ("uploading an existing file").
   - Si la carpeta `.github` no se sube, crea el archivo a mano: "Add file" > "Create new file", nombre
     `.github/workflows/build.yml`, y pega el contenido de ese archivo.
3. Ve a la pestaña **Actions**. La compilación empieza sola al subir los archivos (tarda unos 5 minutos).
   Si no empieza: Actions > "Compilar APK" > "Run workflow".
4. Al terminar, abre la ejecución y descarga **Ondas-apk** (un zip con `app-debug.apk`).
5. Instala el APK en el teléfono. Android pedirá permitir "instalar apps desconocidas" para tu navegador o gestor de archivos.

## Opción B: Android Studio

Abre esta carpeta con Android Studio, espera la sincronización y pulsa Run, o usa Build > Build APK(s).

## Letras de Apple Music

Necesitan tus propios tokens. En la pantalla de reproducción toca **Apple Music…** y pega el Developer token
y el Music User token. Se guardan solo en el teléfono. Sin ellos, "Auto" se salta Apple Music.

## Notas

- Si se apaga la pantalla, la música sigue gracias a un servicio con notificación. Algunos fabricantes
  (Xiaomi, Huawei, Samsung) cierran apps en segundo plano: desactiva el ahorro de batería para Ondas.
- Las APIs de YouTube Music, Better Lyrics y KuGou no son oficiales y pueden cambiar.
- Esta es una versión de depuración, firmada con la clave de debug. Sirve para uso personal.
