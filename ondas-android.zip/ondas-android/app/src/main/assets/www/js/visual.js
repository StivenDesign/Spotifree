'use strict';
/* ===== Visuales: colores, portada animada (WebGL), video de portada, modo video, ecualizador ===== */

/* ---------- colores de la portada ---------- */
function paletteFrom(img) {
  const c = document.createElement('canvas'); c.width = c.height = 24;
  const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, 24, 24);
  const d = x.getImageData(0, 0, 24, 24).data;
  const bins = Array.from({ length: 12 }, () => ({ w: 0, r: 0, g: 0, b: 0 }));
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b);
    const s = mx ? (mx - mn) / mx : 0, v = mx / 255; if (v < 0.18) continue;
    const df = mx - mn || 1; let h;
    if (mx === r) h = ((g - b) / df + 6) % 6; else if (mx === g) h = (b - r) / df + 2; else h = (r - g) / df + 4;
    const B = bins[Math.floor(h / 6 * 12) % 12], w = s * s * v + 0.02;
    B.w += w; B.r += r * w; B.g += g * w; B.b += b * w;
  }
  const top = bins.filter((b) => b.w > 0).sort((a, b) => b.w - a.w).slice(0, 3).map((b) => [b.r / b.w, b.g / b.w, b.b / b.w]);
  if (!top.length) top.push([250, 45, 72]);
  while (top.length < 3) top.push(top[0]);
  return top.map(([r, g, b]) => { const m = Math.max(r, g, b, 1), k = m < 190 ? 190 / m : 1; return `rgb(${Math.min(255, r * k) | 0},${Math.min(255, g * k) | 0},${Math.min(255, b * k) | 0})`; });
}

/* ---------- portada animada con WebGL (cuando no hay video de portada) ---------- */
const GL = { ok: false, tex: null, aspect: 1, loaded: false };
(function initGL() {
  return;   // la distorsión de la portada está desactivada: ahora se usan canvas de video
  const gl = $('gl').getContext('webgl', { alpha: false, antialias: false, premultipliedAlpha: false });
  if (!gl) return;
  const vs = 'attribute vec2 p;varying vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
  const fs = `precision mediump float;varying vec2 uv;uniform sampler2D tex;uniform float t,bass,en,asp;
    void main(){
      vec2 q=uv;
      if(asp>1.)q.x=(uv.x-.5)/asp+.5; else q.y=(uv.y-.5)*asp+.5;
      float w=.004+.02*en;
      q.x+=sin(q.y*7.+t*1.3)*w+sin(q.y*17.-t*.9)*w*.45;
      q.y+=cos(q.x*6.+t*1.1)*w+cos(q.x*13.+t*1.7)*w*.45;
      vec2 c=q-.5; q=.5+c*(.93-.05*bass);
      float ca=.002+.014*bass;
      vec3 col=vec3(texture2D(tex,q+c*ca).r,texture2D(tex,q).g,texture2D(tex,q-c*ca).b);
      col*=1.+.22*bass;
      float v=smoothstep(.95,.35,length(uv-.5));
      col*=.86+.14*v;
      gl_FragColor=vec4(col,1.);
    }`;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null; };
  const v = sh(gl.VERTEX_SHADER, vs), f = sh(gl.FRAGMENT_SHADER, fs); if (!v || !f) return;
  const pr = gl.createProgram(); gl.attachShader(pr, v); gl.attachShader(pr, f); gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return;
  gl.useProgram(pr);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
  [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]].forEach(([k, val]) => gl.texParameteri(gl.TEXTURE_2D, k, val));
  Object.assign(GL, { ok: true, gl, tex, u: { t: gl.getUniformLocation(pr, 't'), bass: gl.getUniformLocation(pr, 'bass'), en: gl.getUniformLocation(pr, 'en'), asp: gl.getUniformLocation(pr, 'asp') } });
})();
async function setTexture(url, track, setColors) {
  try {
    const im = await safeImage(url);
    if (S.queue[S.i] !== track) return;
    if (setColors) { const p = paletteFrom(im); ['--c1', '--c2', '--c3'].forEach((k, n) => document.documentElement.style.setProperty(k, p[n])); if (typeof syncBars === 'function') syncBars(); }
    if (!GL.ok) return;
    const { gl } = GL;
    gl.bindTexture(gl.TEXTURE_2D, GL.tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, im);
    GL.aspect = im.naturalWidth / im.naturalHeight; GL.loaded = true; S.glDirty = true;
    if (CFG.motion) $('gl').classList.add('ready');
  } catch {}
}
function fitCanvas(cv) {
  const dpr = Math.min(window.devicePixelRatio || 1, document.body.classList.contains('perf') ? 1 : 2), w = Math.round(cv.clientWidth * dpr), h = Math.round(cv.clientHeight * dpr);
  if (w && (cv.width !== w || cv.height !== h)) { cv.width = w; cv.height = h; return true; }
  return false;
}
function drawGL(t) {
  if (!GL.ok || !GL.loaded || !CFG.motion || !(S.playing || S.glDirty)) return;
  const { gl } = GL, cv = $('gl');
  fitCanvas(cv); gl.viewport(0, 0, cv.width, cv.height);
  gl.bindTexture(gl.TEXTURE_2D, GL.tex);
  gl.uniform1f(GL.u.t, t); gl.uniform1f(GL.u.bass, S.bass); gl.uniform1f(GL.u.en, S.energy); gl.uniform1f(GL.u.asp, GL.aspect);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  S.glDirty = false;
}

/* ---------- portada en alta resolución + video de portada ---------- */
async function fetchCoverHD(t) {
  if (qualNow() !== 'high') return null;   // calidad media/baja/patata: sin portadas HD
  try {
    const d = await apiGet('cover', { title: t.title, artist: t.artist, duration: t.duration || 0, album: t.album || '' });
    if (S.queue[S.i] !== t) return d;
    t.appleId = d.appleId; t.albumId = d.albumId || ''; if (d.cover) { t.hdCover = d.cover; if (typeof syncNative === 'function') syncNative(true); }
    if (d.cover) { $('artImg').src = d.cover; setTexture(d.cover, t, false); }
    return d;
  } catch { return null; }
}
function loadScript(src) { return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('script')); document.head.append(s); }); }
async function attachHls(v, url) {
  if (v.canPlayType('application/vnd.apple.mpegurl')) { v.src = url; v.load(); return; }
  if (!window.Hls) await loadScript('https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js');
  if (!window.Hls || !Hls.isSupported()) throw new Error('hls');
  const h = new Hls({ maxBufferLength: 8, capLevelToPlayerSize: true }); v._hls = h;
  h.on(Hls.Events.ERROR, (e, d) => { if (d.fatal) clearMotion(); });
  h.loadSource(url); h.attachMedia(v);
}
function clearMotion() {
  const v = $('motion'); v.onloadeddata = v.onerror = null;
  v.classList.remove('on', 'sq'); $('artbox').classList.remove('has-motion'); document.body.classList.remove('canvas-on', 'sq-on');
  if (v._hls) { v._hls.destroy(); v._hls = null; }
  v.pause(); v.removeAttribute('src'); v.load();
  if (v._obj) { URL.revokeObjectURL(v._obj); v._obj = null; }
}
function setMotionSrc(url, isHls, objUrl) {
  const v = $('motion'); clearMotion(); v._obj = objUrl || null;
  v.onloadeddata = () => { v.classList.add('on'); document.body.classList.add('canvas-on'); if (isHls) { v.classList.add('sq'); document.body.classList.add('sq-on'); } syncMotion(); };
  v.onerror = () => clearMotion();
  if (isHls) attachHls(v, url).catch(() => clearMotion()); else { v.src = url; v.load(); }
}
// el video solo corre con la pantalla de reproducción abierta y sonando (ahorra batería)
function syncMotion() {
  const v = $('motion'); if (!v.classList.contains('on')) return;
  if (S.playing && S.npOpen) v.play().catch(() => {}); else v.pause();
}
function showUserCanvas(blob, t) {
  if (blob.type.startsWith('video')) { const u = URL.createObjectURL(blob); setMotionSrc(u, false, u); }
  else { clearMotion(); $('artImg').src = URL.createObjectURL(blob); $('artbox').classList.add('has-motion'); }
}
async function fetchMotion(t, albumId) {
  if (CFG.dataSaver) return false;
  if (qualNow() === 'low' || qualNow() === 'potato') return false;
  try {
    const d = await apiGet('motion', { albumId });
    if (S.queue[S.i] !== t || t._hasCanvas || !CFG.animArt) return false;
    if (d.video) { setMotionSrc(d.video, true); return true; }
  } catch {}
  return false;
}
// género de la canción (de iTunes) → búsqueda de un fondo animado libre
const GENRE_BG = [[/rap|hip/i, 'city night lights'], [/rock|metal|punk/i, 'concert stage lights'], [/electr|dance|house|techno/i, 'abstract neon particles'], [/lat|reggaet|salsa|bachata|cumbia|urban/i, 'tropical sunset'], [/jazz|blues|soul/i, 'smoke dark'], [/class/i, 'orchestra'], [/country|folk/i, 'golden field'], [/r&b|pop/i, 'colorful lights bokeh']];
async function fetchGenreBg(t, genre) {
  if (!CFG.pixKey) return false;
  try {
    const q = (GENRE_BG.find(([re]) => re.test(genre || '')) || [0, 'abstract colorful'])[1];
    const d = await apiGet('pixvideo', { q, key: CFG.pixKey });
    if (S.queue[S.i] !== t || t._hasCanvas || !d.url) return false;
    setMotionSrc(d.url, false); return true;
  } catch {}
  return false;
}
// canvas automático: solo la ilustración animada (carátula en movimiento) del álbum, si existe
async function autoCanvas(t, hd) {
  if (hd && hd.albumId && CFG.animArt && await fetchMotion(t, hd.albumId)) return;
  if (S.queue[S.i] !== t || t._hasCanvas) return;
  // sin ilustración animada la canción queda con su carátula normal: ya no se pone el video ni un fondo ajeno
}
// la carátula anterior se quema y deja ver la nueva debajo
let burnPrev = '';
function burnCover() {
  const prev = burnPrev; { const t = S.queue[S.i]; burnPrev = (t && t.cover) || ''; }
  if (CFG.burn === false || !S.npOpen) return;
  const box = $('artbox'); if (!prev) return;
  box.querySelectorAll('.burn,.burn-e').forEach((n) => n.remove());
  const o = document.createElement('div'); o.className = 'burn'; o.style.backgroundImage = `url("${prev}")`;
  const x = 15 + Math.random() * 70, y = 70 + Math.random() * 30; o.style.setProperty('--x', x + '%'); o.style.setProperty('--y', y + '%');
  const e = document.createElement('div'); e.className = 'burn-e'; e.style.setProperty('--x', x + '%'); e.style.setProperty('--y', y + '%');
  box.append(o, e); setTimeout(() => { o.remove(); e.remove(); }, 1700);
}
async function onTrackLoad(t) {
  setTimeout(applyQuality, 1200);
  burnCover();
  if (S.autoVid) { S.autoVid = false; setVideoMode(false); }
  clearMotion(); GL.loaded = false; $('gl').classList.remove('ready'); t._hasCanvas = false; updateCanvasBtn(); updateVideoBtn();
  setTexture(t.cover, t, true);
  const [blob, hd] = await Promise.all([canvasGet(tid(t)), t.local ? null : fetchCoverHD(t)]);
  if (S.queue[S.i] !== t) return;
  t._hasCanvas = false; updateCanvasBtn();   // función de canvas propio retirada: solo la ilustración animada de Apple
  autoCanvas(t, hd);   // ilustración animada del álbum (si existe)
}
function updateCanvasBtn() {
  const t = S.queue[S.i], has = !!(t && t._hasCanvas);
  $('canvasLbl').textContent = has ? 'Quitar canvas' : 'Canvas'; $('btnCanvas').classList.toggle('on', has);
}
function canvasAction() {
  const t = S.queue[S.i]; if (!t) return toast('Primero pon una canción');
  if (!t._hasCanvas) return $('fileCanvas').click();
  canvasDel(tid(t)); $('artImg').src = t.cover; toast('Canvas quitado'); onTrackLoad(t);
}
async function onCanvasFile(file) {
  const t = S.queue[S.i]; if (!file || !t) return;
  if (!/^(video|image)\//.test(file.type)) return toast('Elige un video o un GIF');
  try { await canvasPut(tid(t), file); } catch { return toast('No pude guardar el canvas'); }
  t._hasCanvas = true; showUserCanvas(file, t); updateCanvasBtn(); toast('Canvas puesto en esta canción');
}

/* ---------- modo video: el reproductor de YouTube se muestra sobre la portada ---------- */
function updateVideoBtn() { const t = S.queue[S.i]; $('btnVideo').classList.toggle('off', !!(t && t.local)); $('btnVideo').hidden = !(t && t.vid); }
function setVideoMode(on) {
  const t = S.queue[S.i];
  if (on && t && t.local) { toast('El video solo está disponible para canciones de YouTube'); return; }
  S.video = on; document.body.classList.toggle('video-on', on); $('btnVideo').classList.toggle('on', on);
  if (on && !S.npOpen) openNP();
  positionVideo();
}
function positionVideo() {
  const y = $('yt'); if (!y) return;
  if (S.video && S.npOpen && !S.lyrOpen) {
    const r = $('artbox').getBoundingClientRect(), h = Math.min(r.height, r.width * 9 / 16), top = r.top + (r.height - h) / 2;   // el video 16:9 va centrado sobre la portada
    y.style.cssText = `left:${r.left}px;top:${top}px;right:auto;bottom:auto;width:${r.width}px;height:${h}px;opacity:1;pointer-events:auto;z-index:35;border-radius:12px`;
  } else if (y.getAttribute('style')) y.removeAttribute('style');
}

/* ---------- ecualizador ---------- */
// Archivos locales: espectro real con Web Audio. YouTube (iframe de otro origen): se simula siguiendo el ritmo estimado.
const AN = { ctx: null, an: null, data: null, tried: false };
// motor de audio: auto elige según el teléfono; «ahorro» no monta la cadena Web Audio si no hace falta (menos CPU y menos cortes)
const engineMode = () => (CFG.engine && CFG.engine !== 'auto') ? CFG.engine : (lowEnd ? 'eco' : 'stable');
const needDsp = () => (CFG.eqg || []).some((v) => v) || CFG.fx8d || CFG.bassBoost || (CFG.vocal ?? 100) !== 100 || (CFG.mixOn && (CFG.mixCfg || {}).rev !== false);
function applyNorm() {
  const c = AN.comp, t = AN.ctx && AN.ctx.currentTime; if (!c) return;
  const on = !!CFG.norm; try { c.threshold.setValueAtTime(on ? -28 : 0, t); c.ratio.setValueAtTime(on ? 6 : 1, t); c.knee.setValueAtTime(on ? 24 : 0, t); c.attack.setValueAtTime(.01, t); c.release.setValueAtTime(.25, t); } catch {}
}
async function ensureAnalyser() {
  if (AN.ctx || AN.tried) return; if (engineMode() === 'eco' && !needDsp()) return; AN.tried = true;
  try {
    const AC = window.AudioContext || window.webkitAudioContext, ctx = new AC({ latencyHint: engineMode() === 'low' ? 'interactive' : 'playback' });   // búfer grande: audio estable, usa la frecuencia nativa del teléfono
    await ctx.resume();
    if (ctx.state !== 'running') { ctx.close(); AN.tried = false; return; }   // sin permiso de audio: se queda la simulación y el sonido directo
    const src = ctx.createMediaElementSource(E.audio), an = ctx.createAnalyser();
    an.fftSize = 256; an.smoothingTimeConstant = 0.55;
    const gains = CFG.eqg || [0, 0, 0, 0, 0];
    const filters = [60, 230, 910, 3600, 14000].map((f, i) => { const b = ctx.createBiquadFilter(); b.type = i === 0 ? 'lowshelf' : i === 4 ? 'highshelf' : 'peaking'; b.frequency.value = f; b.Q.value = 1; b.gain.value = gains[i] || 0; return b; });
    // quitar la voz: la voz suele ir al centro; restando izquierdo-derecho desaparece. Los graves (también al centro) se devuelven con un filtro
    const dry = ctx.createGain(), wet = ctx.createGain(), bass = ctx.createGain(), mix = ctx.createGain();
    const sp = ctx.createChannelSplitter(2), mg = ctx.createChannelMerger(2), lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 120;
    const gL = ctx.createGain(), gR = ctx.createGain(); gR.gain.value = -1;   // lado = izquierdo − derecho, igual en los dos oídos
    src.connect(dry); dry.connect(mix);
    src.connect(sp); sp.connect(gL, 0); sp.connect(gR, 1);
    gL.connect(mg, 0, 0); gR.connect(mg, 0, 0); gL.connect(mg, 0, 1); gR.connect(mg, 0, 1); mg.connect(wet); wet.connect(mix);
    src.connect(lp); lp.connect(bass); bass.connect(mix);
    // reverberación para la mezcla: sala sintética (ruido que decae) estéreo; se alimenta del centro y se abre a los lados
    const cv = ctx.createConvolver(), rv = ctx.createGain(), len = Math.floor(ctx.sampleRate * 2.4), ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    cv.buffer = ir; rv.gain.value = 0; mix.connect(cv); cv.connect(rv); rv.connect(filters[0]);
    const comp = ctx.createDynamicsCompressor(); AN.comp = comp;   // normalizar volumen: neutro si está apagado
    let node = mix; filters.forEach((f) => { node.connect(f); node = f; }); const pan = ctx.createStereoPanner(); AN.pan = pan; node.connect(pan); pan.connect(comp); comp.connect(an); an.connect(ctx.destination);
    Object.assign(AN, { ctx, an, rv, filters, dry, wet, bass, data: new Uint8Array(an.frequencyBinCount) });
    setVocal(CFG.vocal ?? 100); applyNorm(); if (typeof applyFx === 'function') applyFx();
  } catch { AN.tried = false; }
}
const resumeAudioCtx = async () => { try { if (AN.ctx && AN.ctx.state === 'suspended') await AN.ctx.resume(); } catch {} };
function readFFT() {
  if (!AN.an || E.kind !== 'local' || !S.playing) return;
  AN.an.getByteFrequencyData(AN.data);
  const n = AN.data.length, out = new Float32Array(NB);
  for (let i = 0; i < NB; i++) {
    const lo = Math.floor(Math.pow(i / NB, 1.6) * n * 0.85) + 1, hi = Math.max(lo + 1, Math.floor(Math.pow((i + 1) / NB, 1.6) * n * 0.85) + 2);
    let s = 0; for (let k = lo; k < hi && k < n; k++) s += AN.data[k];
    out[i] = Math.min(1, s / (hi - lo) / 255 * (1 + i / NB * 0.9));
  }
  S.fft = out; S.fftAt = performance.now();
}
function updateBands(t, cur) {
  const real = S.playing && S.fft && performance.now() - S.fftAt < 400;
  if (real) {
    for (let i = 0; i < NB; i++) target[i] = Math.min(1, Math.pow(S.fft[i] || 0, 0.8) * 1.15);
  } else if (S.playing) {
    const beat = cur * S.bpm / 60, ph = beat % 1, kick = Math.pow(Math.max(0, 1 - ph * 2.2), 2);
    for (let i = 0; i < NB; i++) {
      const f = i / (NB - 1), base = (1 - f) * 0.55 + 0.18;
      const n = (Math.sin(t * (1.3 + i * 0.37) + i * 1.9) + Math.sin(t * (2.1 + i * 0.21) + i * 0.7)) * 0.25 + 0.5;
      let v = base * (0.45 + 0.55 * n);
      if (i < 5) v += kick * 0.55 * (1 - i / 6);
      if (i >= 14 && ph > 0.5 && ph < 0.62) v += 0.25 * f;
      target[i] = Math.min(1, v);
    }
  } else target.fill(0.03);
  let b = 0, e = 0;
  for (let i = 0; i < NB; i++) { bands[i] += (target[i] - bands[i]) * (target[i] > bands[i] ? 0.55 : 0.13); e += bands[i]; if (i < 4) b += bands[i]; }
  S.bass += (b / 4 - S.bass) * 0.35; S.energy += (e / NB - S.energy) * 0.2;
}
function drawEQ() {
  return;   // las barras del ecualizador sobre la portada se quitaron

  const cv = $('eq'), x = cv.getContext('2d');
  fitCanvas(cv); x.clearRect(0, 0, cv.width, cv.height);
  if (CFG.eq === 2 || S.video) return;
  const W = cv.width, H = cv.height, g = x.createLinearGradient(0, H, 0, 0);
  g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(1, 'rgba(255,255,255,.35)'); x.fillStyle = g;
  if (CFG.eq === 0) {
    const gap = W / NB * 0.28, bw = W / NB - gap;
    for (let i = 0; i < NB; i++) {
      const h = Math.max(bw * 0.8, bands[i] * H * 0.95), px = i * (bw + gap) + gap / 2;
      x.beginPath(); if (x.roundRect) x.roundRect(px, H - h, bw, h, bw / 2); else x.rect(px, H - h, bw, h); x.fill();
    }
  } else {
    x.beginPath(); x.moveTo(0, H);
    for (let i = 0; i < NB; i++) x.lineTo(i / (NB - 1) * W, H - Math.max(4, bands[i] * H * 0.95));
    x.lineTo(W, H); x.closePath(); x.globalAlpha = 0.85; x.fill(); x.globalAlpha = 1;
  }
}

/* barra de estado y de navegación del sistema con el color de la canción */
const _bc = document.createElement('canvas'); _bc.width = _bc.height = 1; const _bx = _bc.getContext('2d', { willReadFrequently: true });
function cssRgb(c) { try { _bx.clearRect(0, 0, 1, 1); _bx.fillStyle = '#000'; _bx.fillStyle = c; _bx.fillRect(0, 0, 1, 1); const d = _bx.getImageData(0, 0, 1, 1).data; return [d[0], d[1], d[2]]; } catch { return [10, 10, 12]; } }
let _barLast = '', _barT = 0;
function syncBars() {
  clearTimeout(_barT);
  _barT = setTimeout(() => {
    try {
      const cs = getComputedStyle(document.documentElement), np = document.body.classList.contains('np-open');
      const c = cssRgb(cs.getPropertyValue(np ? '--c2' : '--c1').trim() || '#08080a'), k = np ? .85 : .24, base = [8, 8, 10];
      const hex = '#' + c.map((v, i) => Math.round(base[i] + (v - base[i]) * k).toString(16).padStart(2, '0')).join('');
      if (hex === _barLast) return; _barLast = hex;
      document.querySelector('meta[name=theme-color]')?.setAttribute('content', hex);
      if (window.Native && Native.setBars) Native.setBars(hex);
    } catch {}
  }, 120);
}
new MutationObserver(syncBars).observe(document.body, { attributes: true, attributeFilter: ['class'] });
setTimeout(syncBars, 1500);

/* ---------- pantalla completa: márgenes reales de la barra de estado y la de navegación ---------- */
window.__insets = (t, b) => { const st = document.documentElement.style; st.setProperty('--sat', (+t || 0) + 'px'); st.setProperty('--sab', (+b || 0) + 'px'); };
(function () {
  const ask = () => { try { if (window.Native && Native.insets) { const [t, b] = String(Native.insets()).split(','); window.__insets(t, b); } } catch {} };
  ask(); setTimeout(ask, 400); setTimeout(ask, 1500); window.addEventListener('resize', ask);
})();

/* 100 = voz normal, 0 = sin voz (solo música). Solo funciona con audio local o descargado */
function setVocal(v) {
  CFG.vocal = v; const k = 1 - Math.max(0, Math.min(100, v)) / 100;
  if (AN.dry) { AN.dry.gain.value = 1 - k; AN.wet.gain.value = k; AN.bass.gain.value = k * 0.9; }
}
const vocalOk = () => E.kind === 'local' && !!AN.dry;
