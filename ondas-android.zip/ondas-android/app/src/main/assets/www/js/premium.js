/* ===== Reproductor premium: estilos (disco, minimalista), aleatorio inteligente y guardar la cola ===== */
(function () {
  /* ---- estilo del reproductor ---- */
  function style() {
    const s = CFG.playerStyle || 'classic', b = document.body;
    b.classList.toggle('ps-disc', s === 'disc'); b.classList.toggle('ps-min', s === 'min');
  }
  style();
  document.addEventListener('change', (e) => { const t = e.target; if (t && t.dataset && t.dataset.cfg === 'playerStyle') { style(); haptic(6); } });

  /* ---- aleatorio inteligente: favorece lo que más escuchas y tus favoritas, y evita que el mismo artista suene seguido ---- */
  const plays = (t) => { try { const p = STATS.plays[tid(t)]; return p ? p.n : 0; } catch { return 0; } };
  const artistOf = (t) => (typeof mainArtist === 'function' ? mainArtist(t.artist || '') : String(t.artist || '')).toLowerCase();
  function smartOrder(rest) {
    const keyed = rest.map((t) => { const w = 1 + Math.min(plays(t), 8) * .35 + (isLiked(t) ? 1.2 : 0); return { t, k: -Math.log(Math.random() || 1e-9) / w }; });
    keyed.sort((a, b) => a.k - b.k);
    const out = keyed.map((x) => x.t);
    for (let i = 1; i < out.length; i++) {                  // si dos seguidas son del mismo artista, la segunda se cambia por una posterior de otro artista
      if (artistOf(out[i]) && artistOf(out[i]) === artistOf(out[i - 1])) {
        const j = out.findIndex((x, k) => k > i && artistOf(x) !== artistOf(out[i - 1]));
        if (j > i) { const [x] = out.splice(j, 1); out.splice(i, 0, x); }
      }
    }
    return out;
  }
  const basePlay = window.play;
  if (typeof basePlay === 'function') window.play = function (list, idx, fromImg, opts) {
    if (CFG.smartShuffle !== false && CFG.shuffle && list && list.length > 2) {
      const cur = list[idx], ordered = [cur, ...smartOrder(list.filter((_, k) => k !== idx))], was = CFG.shuffle;
      CFG.shuffle = false;
      try { basePlay.call(this, ordered, 0, fromImg, opts); } finally { CFG.shuffle = was; }
      S.orig = list.slice();            // «quitar aleatorio» vuelve al orden original, igual que antes
      return;
    }
    return basePlay.apply(this, arguments);
  };

  /* ---- guardar la cola actual como lista ---- */
  function addSaveBtn() {
    const box = document.querySelector('.qv-pills'); if (!box || document.getElementById('qvSave')) return;
    const b = document.createElement('button'); b.id = 'qvSave'; b.setAttribute('aria-label', 'Guardar la cola como lista'); b.dataset.act = 'q-save';
    b.innerHTML = '<svg class="ic"><use href="#i-listadd"/></svg>'; box.append(b);
  }
  addSaveBtn();
  document.addEventListener('click', (e) => {
    const b = e.target.closest && e.target.closest('[data-act="q-save"]'); if (!b) return; e.stopPropagation();
    const tr = S.queue.filter((t) => t && !t.local);
    if (!tr.length) return toast('La cola está vacía');
    const d = new Date(), pad = (n) => String(n).padStart(2, '0');
    const name = 'Cola · ' + pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
    newList(name, tr); haptic(10); toast('Cola guardada en tu biblioteca: ' + name);
    try { if (typeof renderLib === 'function') renderLib(); } catch {}
  }, true);
})();
