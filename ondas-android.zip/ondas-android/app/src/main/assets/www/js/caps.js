'use strict';
/* ===== Disponibilidad de cada canción: búsqueda, reproducción y descarga son cosas distintas =====
   Aparecer en una búsqueda NO significa que se pueda reproducir ni descargar. Aquí se dice qué se puede de verdad. */
const DL_MSG = 'Esta canción está disponible para escuchar, pero su proveedor no permite descargarla desde esta aplicación';
function trackCaps(t) {
  const found = t.dl ? 'Descargas' : t.local ? 'Tu teléfono' : (SRC_LABEL[t.src] || (t.sp ? 'Spotify' : t.videoId ? 'YouTube Music' : 'Catálogo'));
  const play = t.dl ? { ok: true, via: 'Archivo descargado (sin conexión)' }
    : t.local ? { ok: true, via: 'Archivo de tu teléfono' }
    : (t.stream && t.url) ? { ok: true, via: (t.src || 'Fuente libre') + ' · audio directo' }
    : (t.sc && CFG.scId && t.scTr) ? { ok: true, via: 'SoundCloud · audio directo' }
    : t.videoId ? { ok: true, via: 'YouTube Music (reproductor oficial)' }
    : { ok: 'resolve', via: 'Se busca en YouTube Music al pulsar play' };
  const free = (t.free && t.url) ? t.url : t.dlUrl || '';
  const dl = t.dl ? { ok: 'have', why: 'Ya está descargada' } : t.local ? { ok: 'have', why: 'Ya está en tu teléfono' }
    : free ? { ok: true, why: 'Licencia libre: ' + (/creativecommons|publicdomain/i.test(t.license || '') ? 'Creative Commons / dominio público' : (t.license || 'indicada por ' + (t.src || t.dlSrc || 'el proveedor'))), url: free }
    : { ok: false, why: DL_MSG };
  return { found, play, dl };
}
const dlOk = (t) => trackCaps(t).dl.ok === true;
function downloadTrack(t) {
  if (CFG.dlWifi && typeof netKind === 'function' && netKind() === 'cell') return toast('Descargas solo con Wi-Fi (Ajustes)');
  const c = trackCaps(t).dl;
  if (c.ok === true) return startDownload(Object.assign({}, t, { url: c.url, src: t.src || t.dlSrc || '' }));
  if (c.ok === 'have') return toast(c.why);
  openMenu({ title: t.title, sub: DL_MSG, cover: t.cover }, [
    { icon: 'search', label: 'Buscar una versión libre (Jamendo)…', run: () => { closeNP && closeNP(); openDownloads(`${t.artist} ${t.title}`.trim()); } },
  ]);
}
function availMenu(t) {
  const c = trackCaps(t), mk = (icon, label) => ({ icon, label, run: () => {} });
  openMenu({ title: t.title, sub: 'Qué puedes hacer con esta canción', cover: t.cover }, [
    mk('search', 'Búsqueda: encontrada en ' + c.found),
    mk('radio', 'Reproducción: ' + c.play.via),
    mk('dl', 'Descarga: ' + (c.dl.ok === true ? 'permitida · ' + c.dl.why : c.dl.ok === 'have' ? c.dl.why : 'no permitida desde la app')),
  ]);
}
