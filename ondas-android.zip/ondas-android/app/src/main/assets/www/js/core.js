'use strict';
/* ===== Núcleo: utilidades, estado, motor de reproducción (YouTube + archivos locales) ===== */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const hue = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};
const lowEnd = (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 3;
const CFG = Object.assign({ prov: 'auto', eq: 0, motion: true, amb: true, kind: 'songs', perf: lowEnd, glass: 70, haptic: true, shuffle: false, repeat: 0, rate: 1, accent: 'Verde', artists: true, artists: true, eqg: [0, 0, 0, 0, 0] }, store.get('sf_cfg', {}));
const saveCfg = () => store.set('sf_cfg', CFG);

let toastTimer, toastHide;
function hideToast() { const t = $('toast'); t.classList.remove('show'); clearTimeout(toastHide); toastHide = setTimeout(() => { if (!t.classList.contains('show')) t.hidden = true; }, 450); }
function toast(msg, undo) {
  const t = $('toast'); clearTimeout(toastHide); t.hidden = false; void t.offsetWidth; t.classList.add('show');
  $('toastMsg').textContent = msg;
  const u = $('toastUndo'); u.hidden = !undo;
  u.onclick = () => { if (undo) undo(); hideToast(); };
  clearTimeout(toastTimer); toastTimer = setTimeout(hideToast, undo ? 5000 : 2800);
}

/* ---------- acceso a datos: servidor local o puente nativo (Android) ---------- */
async function apiGet(name, params) {
  if (window.ClientAPI) return window.ClientAPI.handle(name, params);
  const r = await fetch('/api/' + name + '?' + new URLSearchParams(params));
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
}
// Imagen servida desde un origen seguro para poder usarla en WebGL y leer sus colores.
async function safeImage(url) {
  let src = url;
  if (!/^(blob:|data:)/.test(url)) src = window.ClientAPI ? (await window.ClientAPI.handle('img', { u: url })).data : '/api/img?u=' + encodeURIComponent(url);
  return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('imagen')); im.src = src; });
}

const PROVIDERS = [['auto', 'Auto'], ['betterlyrics', 'Better Lyrics'], ['kugou', 'KuGou'], ['apple', 'Apple Music'], ['lrclib', 'LRCLIB']];
const AUTO_ORDER = ['betterlyrics', 'apple', 'kugou', 'lrclib'];
const NB = 24;

const S = {
  queue: [], i: -1, playing: false, player: null, ready: false, pending: null, loadTok: 0,
  results: [], lyrics: null, active: -2, offset: 0, token: 0, seeking: false,
  bpm: 100, fft: null, fftAt: 0, bass: 0, energy: 0, glDirty: true,
  npOpen: false, lyrOpen: false, video: false,
};
const bands = new Float32Array(NB), target = new Float32Array(NB);
const tid = (t) => (t.dl ? 'D' + t.did : t.local ? 'L' + t.lid : t.videoId || ('Q' + (t.title || '') + (t.artist || '')));
const haptic = (ms = 8) => { if (CFG.haptic && navigator.vibrate) { try { navigator.vibrate(ms); } catch {} } };

/* ---------- motor: una sola interfaz para YouTube y para archivos locales ---------- */
const E = {
  kind: 'yt',
  audio: Object.assign(new Audio(), { preload: 'auto' }),
  time() { return this.kind === 'yt' ? ((S.ready && S.player.getCurrentTime && S.player.getCurrentTime()) || 0) : (this.audio.currentTime || 0); },
  dur() { return this.kind === 'yt' ? ((S.ready && S.player.getDuration && S.player.getDuration()) || 0) : (isFinite(this.audio.duration) ? this.audio.duration : 0); },
  seek(t) { if (this.kind === 'yt') { if (S.ready) S.player.seekTo(t, true); } else this.audio.currentTime = t; },
  vol(v) { if (S.ready) S.player.setVolume(v); this.audio.volume = v / 100; },
  toggle() {
    S.userAt = Date.now();
    if (this.kind === 'yt') { if (isYtPlaying()) { S.want = false; try { S.player.pauseVideo(); } catch {} } else resumeYT(); }
    else { resumeAudioCtx(); if (this.audio.paused) { S.want = true; this.audio.play().catch(() => {}); } else { S.want = false; this.audio.pause(); } }
  },
};
['play', 'playing', 'pause'].forEach((ev) => E.audio.addEventListener(ev, () => { if (E.kind !== 'local') return; S.playing = !E.audio.paused; paintPlay(); }));
E.audio.addEventListener('ended', () => { if (E.kind === 'local') onEnded(); });
E.audio.addEventListener('error', () => { if (E.kind === 'local') { toast('No se pudo reproducir este archivo'); } });

/* ---- reproducción robusta: no se queda pausada ni trabada ---- */
S.want = false; S.userAt = 0; S.lastPos = 0;
const ytState = () => { try { return S.ready && S.player.getPlayerState ? S.player.getPlayerState() : -9; } catch { return -9; } };
const isYtPlaying = () => { const s = ytState(); return s === 1 || s === 3; };
function reloadYT(pos) {                              // vuelve a cargar el video en el segundo donde iba
  const t = S.queue[S.i]; if (!S.ready || !t || !t.videoId || E.kind !== 'yt') return;
  try { S.player.loadVideoById({ videoId: t.videoId, startSeconds: Math.max(0, pos || 0) }); } catch {}
}
function resumeYT() {
  S.want = true; if (!S.ready) return;
  try { S.player.playVideo(); } catch {}
  const t = S.queue[S.i], pos = S.lastPos || E.time();
  clearTimeout(S.rsTimer);
  S.rsTimer = setTimeout(() => { if (S.want && E.kind === 'yt' && S.queue[S.i] === t && !isYtPlaying()) reloadYT(pos); }, 1800);
}
const wd = { pos: -1, stuck: 0, buf: 0, retry: 0, fixes: 0, id: '' };
setInterval(() => {
  if (E.kind !== 'yt' || !S.ready || !S.want) return;
  const t = S.queue[S.i], id = t ? tid(t) : ''; if (id !== wd.id) { Object.assign(wd, { pos: -1, stuck: 0, buf: 0, retry: 0, fixes: 0, id }); }
  const st = ytState(), pos = E.time();
  if (st === 1) {
    if (pos > 0) S.lastPos = pos;
    wd.stuck = Math.abs(pos - wd.pos) < 0.05 ? wd.stuck + 1 : 0; wd.pos = pos; wd.buf = 0; wd.retry = 0;
    if (wd.stuck >= 4 && wd.fixes < 4) { wd.stuck = 0; wd.fixes++; reloadYT(pos); }          // imagen congelada: recarga en el mismo punto
  } else if (st === 3) {
    if (++wd.buf >= 5 && wd.fixes < 4) { wd.buf = 0; wd.fixes++; reloadYT(S.lastPos || pos); }  // cargando demasiado: reintenta
  } else if (st === 2 || st === -1 || st === 5) {
    if (Date.now() - S.userAt > 2500 && wd.retry < 4) { wd.retry++; if (st === 2) { try { S.player.playVideo(); } catch {} } else reloadYT(S.lastPos || pos); }   // se pausó sola
  }
}, 1500);
// al salir de la app o volver, si la música debía seguir, se reanuda
document.addEventListener('visibilitychange', () => {
  [300, 1500].forEach((ms) => setTimeout(() => { if (S.want && E.kind === 'yt' && S.ready && !isYtPlaying() && Date.now() - S.userAt > 2000) { try { S.player.playVideo(); } catch {} } }, ms));
});

window.onYouTubeIframeAPIReady = () => {
  S.player = new YT.Player('yt', {
    width: 200, height: 113, playerVars: { origin: location.origin, playsinline: 1, controls: 0, disablekb: 1, rel: 0, iv_load_policy: 3 },
    events: {
      onReady: () => { S.ready = true; S.player.setVolume(+$('vol').value); if (S.pending) { S.player.loadVideoById(S.pending); S.pending = null; } },
      onStateChange: (e) => {
        if (E.kind !== 'yt') return;
        S.playing = e.data === YT.PlayerState.PLAYING || e.data === YT.PlayerState.BUFFERING;
        if (e.data === YT.PlayerState.ENDED) onEnded();
        paintPlay();
      },
      onError: () => { if (wd.fixes < 1) { wd.fixes++; return reloadYT(S.lastPos); } toast('Esta canción no se puede reproducir aquí. Paso a la siguiente.'); setTimeout(next, 1500); },
    },
  });
};
// el reproductor de YouTube se carga solo cuando hace falta (o con el teléfono en reposo) para que la app abra rápido
let ytLoading = false;
function ensureYT() {
  if (ytLoading) return; ytLoading = true;
  const tag = document.createElement('script'); tag.src = 'https://www.youtube.com/iframe_api'; tag.onerror = () => { ytLoading = false; }; document.head.append(tag);
}
(window.requestIdleCallback || ((f) => setTimeout(f, 2500)))(ensureYT, { timeout: 4000 });

function paintPlay() {
  applyRate();
  document.body.classList.toggle('is-playing', S.playing);
  const t = S.queue[S.i];
  document.title = S.playing && t ? `${t.title} · Spotifree` : 'Spotifree';
  S.glDirty = true;
  if (typeof syncMotion === 'function') syncMotion();
  syncNative(true);
}
// notificación y controles del sistema (pantalla de bloqueo, auriculares) en Android
let nat = { id: '', playing: null, dur: 0 };
function syncNative(force) {
  if (!window.Native || !Native.media) return;
  const t = S.queue[S.i]; if (!t) return;
  const dur = E.dur(), id = tid(t);
  if (!force && nat.id === id && nat.playing === S.playing && (nat.dur || !dur)) return;
  nat = { id, playing: S.playing, dur };
  try { Native.media(t.title, t.artist || '', S.playing, Math.round(E.time() * 1000), Math.round(dur * 1000)); } catch {}
}

function play(list, idx, fromImg, opts) {
  S.radioSeed = (opts && opts.radio) || null; S.orig = null;
  if (CFG.shuffle && list.length > 1) {                    // aleatorio: la elegida suena primero y el resto se mezcla
    const cur = list[idx], rest = list.filter((_, k) => k !== idx);
    for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
    S.orig = list.slice(); S.queue = [cur, ...rest]; idx = 0;
  } else S.queue = list.slice();
  load(idx);
  if (fromImg && typeof flyCover === 'function') flyCover(fromImg, S.queue[idx].cover);
}
// de los resultados de YouTube Music, el que de verdad es esa canción (mismo título y artista, duración parecida)
function pickHit(list, t) {
  const n = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
  const wt = n(t.title), wa = n(String(t.artist || '').split(/,|&| y | feat| ft/)[0]);
  let best = null, bs = -99;
  list.forEach((g, k) => {
    const gt = n(g.title), ga = n(g.artist); let s = -k * .2;
    s += gt === wt ? 4 : (gt.includes(wt) || wt.includes(gt)) ? 1.5 : -3;
    s += wa && (ga.includes(wa) || wa.includes(ga)) ? 4 : -2;
    if (/\b(remix|live|en vivo|karaoke|instrumental|sped|slowed)\b/.test(gt) && !/\b(remix|live|en vivo|karaoke|instrumental|sped|slowed)\b/.test(wt)) s -= 4;
    if (t.duration && g.duration) s += Math.abs(t.duration - g.duration) <= 5 ? 2 : Math.abs(t.duration - g.duration) > 25 ? -3 : 0;
    if (s > bs) { bs = s; best = g; }
  });
  return best;
}
async function load(i) {
  if (i < 0 || i >= S.queue.length) return;
  S.i = i; const t = S.queue[i], my = ++S.loadTok; S.want = true; S.userAt = Date.now(); S.lastPos = 0;
  S.bpm = 82 + (hue(tid(t)) % 48);
  if (!t.local && !t.videoId) {
    paintTrack(t);
    try {
      const d = await apiGet('search', { q: (t.artist + ' ' + t.title).trim(), type: 'songs' });
      if (my !== S.loadTok) return;
      const hit = pickHit(d.results || [], t);
      if (!hit) { toast('No encontré «' + t.title + '» en YouTube Music'); return setTimeout(next, 1200); }
      t.videoId = hit.videoId; if (!t.cover) t.cover = hit.cover; if (!t.duration) t.duration = hit.duration;
    } catch (e) { return toast('No pude buscar la canción: ' + e.message); }
  }
  paintTrack(t);
  if (t.local) {
    E.kind = 'local';
    try { if (S.ready) S.player.pauseVideo(); } catch {}
    if (S.video) setVideoMode(false);
    const url = t.dl ? await downloadURL(t) : await libraryURL(t); if (my !== S.loadTok || !url) return;
    await ensureAnalyser(); if (my !== S.loadTok) return;
    E.audio.src = url; E.vol(+$('vol').value);
    try { await resumeAudioCtx(); await E.audio.play(); } catch {}
  } else {
    E.kind = 'yt'; E.audio.pause(); ensureYT();
    E.vol(+$('vol').value);
    if (S.ready) S.player.loadVideoById(t.videoId); else S.pending = t.videoId;
  }
  onTrackLoad(t); loadLyrics(t); if (typeof recordPlay === 'function') recordPlay(t);
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist, album: t.album || '', artwork: t.cover ? [{ src: t.cover, sizes: '512x512' }] : [] });
      navigator.mediaSession.setActionHandler('play', () => E.toggle()); navigator.mediaSession.setActionHandler('pause', () => E.toggle());
      navigator.mediaSession.setActionHandler('nexttrack', next); navigator.mediaSession.setActionHandler('previoustrack', prev);
    } catch {}
  }
}
/* pausar y reanudar con fundido suave */
let fadeTok = 0;
function fade(from, to, ms, done) {
  const tok = ++fadeTok, steps = Math.max(1, Math.round(ms / 30)); let i = 0;
  const iv = setInterval(() => {
    if (tok !== fadeTok) return clearInterval(iv);
    i++; E.vol(from + (to - from) * i / steps);
    if (i >= steps) { clearInterval(iv); if (done) done(); }
  }, 30);
}
const toggle = () => {
  const v = +$('vol').value, playing = E.kind === 'yt' ? isYtPlaying() : S.playing;
  if (playing) fade(v, 0, 220, () => { E.toggle(); E.vol(v); });
  else { E.vol(0); E.toggle(); fade(0, v, 280); }
};
function applyRate() {
  const r = CFG.rate || 1;
  try { if (E.kind === 'yt') { if (S.ready && S.player.setPlaybackRate) S.player.setPlaybackRate(r); } else E.audio.playbackRate = r; } catch {}
}
// al terminar una canción: repetir, parar o seguir
function onEnded() {
  if (S.sleepEnd) { clearSleep(true); toast('Temporizador: música pausada'); return; }
  if (CFG.repeat === 2) { E.seek(0); if (E.kind === 'yt') { try { S.player.playVideo(); } catch {} } else E.audio.play().catch(() => {}); return; }
  if (S.i >= S.queue.length - 1 && CFG.repeat === 0 && !S.radioSeed) return;      // fin de la lista
  next();
}
// comandos que llegan desde la notificación, la pantalla de bloqueo y los auriculares de Android
window.__media = (c, arg) => {
  if (c === 'next') next(); else if (c === 'prev') prev();
  else if (c === 'play') { if (!(E.kind === 'yt' ? isYtPlaying() : S.playing)) toggle(); } else if (c === 'pause') { if (E.kind === 'yt' ? isYtPlaying() : S.playing) toggle(); }
  else if (c === 'seek') E.seek(Math.max(0, (+arg || 0) / 1000));
};
const next = async () => {
  if (!S.queue.length) return;
  if (S.i >= S.queue.length - 1 && S.radioSeed && window.ClientAPI) {         // radio infinita: pide más canciones parecidas
    try {
      const d = await apiGet('radio', { videoId: S.radioSeed }); const have = new Set(S.queue.map(tid));
      const more = d.tracks.filter((x) => !have.has(tid(x))); if (more.length) { S.queue.push(...more); S.radioSeed = more[more.length - 1].videoId; if (typeof renderQueue === 'function') renderQueue(); }
    } catch {}
  }
  load((S.i + 1) % S.queue.length);
};
const prev = () => { if (!S.queue.length) return; if (E.time() > 4) E.seek(0); else load((S.i - 1 + S.queue.length) % S.queue.length); };

// Las descargas se cargan como blob: así se puede adelantar y retroceder sin depender del servidor interno.
let dlBlobURL = null;
async function downloadURL(t) {
  try {
    const r = await fetch(t.url); if (!r.ok) throw new Error('no existe');
    const u = URL.createObjectURL(await r.blob());
    if (dlBlobURL) URL.revokeObjectURL(dlBlobURL);
    return (dlBlobURL = u);
  } catch { toast('No encuentro el archivo descargado'); return ''; }
}
