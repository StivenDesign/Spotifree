'use strict';
/* ===== Núcleo: utilidades, estado, motor de reproducción (YouTube + archivos locales) ===== */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const hue = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};
/* gama baja: se decide con los datos reales del teléfono (memoria, Android, procesador); en Ajustes se puede forzar */
const DEVINFO = (() => { try { return JSON.parse(window.Native && Native.deviceInfo ? Native.deviceInfo() : '{}'); } catch { return {}; } })();
const LOWSOC = /(sm4\d{3}|sm6[01]\d{2}|sm62[0-9]{2}|sdm4|sdm6|msm89|mt67[0-9]{2}|mt6[0-5][0-9]{2}|helio|ums\d|sc9\d|unisoc|spreadtrum|exynos ?(850|1080|7|8)|bengal|holi|trinket|sm6225|sm6115|sm6125)/;
const autoLite = () => {
  const d = DEVINFO; if (d.ramMb) return d.ramMb < 7000 || d.sdk <= 29 || !!d.lowRam || LOWSOC.test(d.soc || '') || (d.cores || 8) <= 4;
  return (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 4;
};
const lowEnd = autoLite();
let LITE = lowEnd;
/* el volumen es el del teléfono (sonido multimedia); fuera de Android se usa el del reproductor */
const sysVol = () => !!(window.Native && Native.setVolume && Native.getVolume);
const outVol = () => (sysVol() ? 100 : +$('vol').value);
const CFG = Object.assign({ prov: 'auto', eq: 0, motion: true, amb: true, kind: 'songs', perf: lowEnd, glass: 70, haptic: true, shuffle: false, repeat: 0, rate: 1, accent: 'Rosado', anim: 'full', mixOn: false, xglass: true, liquid: false, scId: '', autoScan: true, src: 'both', official: true, gq: 'auto', blur: 100, shine: 100, batSaver: true, amoled: false, awake: false, remain: true, lyrSize: 100, lyrAlign: 'center', lyrBlur: true, artists: true, eqg: [0, 0, 0, 0, 0] }, store.get('sf_cfg', {}));
/* gama baja: portadas en movimiento y fondo animado apagados la primera vez (se pueden volver a encender en Ajustes) */
if (!CFG.liteMig) { if (lowEnd) { CFG.motion = false; CFG.amb = false; CFG.anim = 'soft'; } CFG.liteMig = true; try { store.set('sf_cfg', CFG); } catch {} }
/* modo gráfico: Light / Smooth / Full Glass (automático según el teléfono). Migración: los ajustes anteriores se conservan */
const RM = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
function autoGMode() {
  if (lowEnd) return 'light';
  const d = DEVINFO; if (d.ramMb) return d.ramMb < 9500 ? 'smooth' : 'full';
  return (navigator.deviceMemory || 8) >= 8 ? 'full' : 'smooth';
}
const resolveGMode = () => (CFG.gmode && CFG.gmode !== 'auto' ? CFG.gmode : autoGMode());
if (!CFG.gmMig) { CFG.gmode = CFG.gmode || 'auto'; CFG.gmMig = true; try { store.set('sf_cfg', CFG); } catch {} }
LITE = CFG.lite === 'on' ? true : CFG.lite === 'off' ? false : (resolveGMode() === 'light' || (resolveGMode() === 'solid' && lowEnd));
if (!CFG.lyrMig) { CFG.lyrAlign = 'center'; CFG.lyrMig = true; try { store.set('sf_cfg', CFG); } catch {} }   // letras centradas por defecto
if (!CFG.accMig) { CFG.accent = 'Rosado'; CFG.accMig = true; try { store.set('sf_cfg', CFG); } catch {} }   // nuevo color por defecto: rosado
const saveCfg = () => store.set('sf_cfg', CFG);

let toastTimer, toastHide;
function hideToast() { const t = $('toast'); t.classList.remove('show'); clearTimeout(toastHide); toastHide = setTimeout(() => { if (!t.classList.contains('show')) t.hidden = true; }, 450); }
function toast(msg, undo) {
  const t = $('toast'); clearTimeout(toastHide); t.hidden = false; void t.offsetWidth; t.classList.add('show');
  $('toastMsg').textContent = msg;
  const u = $('toastUndo'); u.hidden = !undo;
  u.onclick = () => { if (undo) undo(); hideToast(); };
  clearTimeout(toastTimer); toastTimer = setTimeout(hideToast, undo ? 5000 : 2800);
}

/* ---------- acceso a datos: servidor local o puente nativo (Android) ---------- */
/* caché corta de búsquedas (6 min, 80 entradas) y audio de fuentes libres servido por la app */
const API_CACHE = new Map(), CACHEABLE = new Set(['search', 'suggest', 'itunes', 'deezer', 'amapi', 'ytapi', 'jamendo', 'ia', 'iafiles', 'sc']);
const proxyURL = (u) => 'https://appassets.androidplatform.net/proxy/' + btoa(unescape(encodeURIComponent(u))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
async function apiGet(name, params) {
  if (CACHEABLE.has(name)) {
    const k = name + JSON.stringify(params), hit = API_CACHE.get(k);
    if (hit && Date.now() - hit.t < 360000) return hit.v;
    const v = await apiGet0(name, params);
    API_CACHE.set(k, { t: Date.now(), v }); if (API_CACHE.size > 80) API_CACHE.delete(API_CACHE.keys().next().value);
    return v;
  }
  return apiGet0(name, params);
}
async function apiGet0(name, params) {
  if (window.ClientAPI) return window.ClientAPI.handle(name, params);
  const r = await fetch('/api/' + name + '?' + new URLSearchParams(params));
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
}
// Imagen servida desde un origen seguro para poder usarla en WebGL y leer sus colores.
async function safeImage(url) {
  let src = url;
  if (!/^(blob:|data:)/.test(url)) src = window.ClientAPI ? (await window.ClientAPI.handle('img', { u: url })).data : '/api/img?u=' + encodeURIComponent(url);
  return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('imagen')); im.src = src; });
}

const PROVIDERS = [['auto', 'Auto'], ['betterlyrics', 'Better Lyrics'], ['kugou', 'KuGou'], ['netease', 'NetEase'], ['qq', 'QQ Música'], ['apple', 'Apple Music'], ['lrclib', 'LRCLIB'], ['ovh', 'Lyrics.ovh (texto)']];
const AUTO_ORDER = ['betterlyrics', 'apple', 'lrclib', 'kugou', 'netease', 'qq', 'ovh'];
const NB = 24;

const S = {
  queue: [], i: -1, playing: false, player: null, ready: false, pending: null, loadTok: 0,
  results: [], lyrics: null, active: -2, offset: 0, token: 0, seeking: false,
  bpm: 100, fft: null, fftAt: 0, bass: 0, energy: 0, glDirty: true,
  npOpen: false, lyrOpen: false, video: false,
};
const bands = new Float32Array(NB), target = new Float32Array(NB);
const tid = (t) => (t.sc ? 'S' + t.scId : t.dev ? 'V' + t.did : t.dl ? 'D' + t.did : t.local ? 'L' + t.lid : t.videoId || ('Q' + (t.title || '') + (t.artist || '')));
const haptic = (ms = 8) => { if (CFG.haptic && navigator.vibrate) { try { navigator.vibrate(ms); } catch {} } };

/* ---------- motor: una sola interfaz para YouTube y para archivos locales ---------- */
const E = {
  kind: 'yt',
  audio: Object.assign(new Audio(), { preload: 'auto' }),
  time() { return this.kind === 'yt' ? ((S.ready && S.player.getCurrentTime && S.player.getCurrentTime()) || 0) : (this.audio.currentTime || 0); },
  dur() { return this.kind === 'yt' ? ((S.ready && S.player.getDuration && S.player.getDuration()) || 0) : (isFinite(this.audio.duration) ? this.audio.duration : 0); },
  seek(t) { if (this.kind === 'yt') { if (S.ready) S.player.seekTo(t, true); } else this.audio.currentTime = t; },
  vol(v) { if (S.ready) S.player.setVolume(v); this.audio.volume = v / 100; },
  toggle() {
    S.userAt = Date.now();
    if (this.kind === 'yt') { if (isYtPlaying()) { S.want = false; try { S.player.pauseVideo(); } catch {} } else resumeYT(); }
    else { resumeAudioCtx(); if (this.audio.paused) { S.want = true; this.audio.play().catch(() => {}); } else { S.want = false; this.audio.pause(); } }
  },
};
['play', 'playing', 'pause'].forEach((ev) => E.audio.addEventListener(ev, () => { if (E.kind !== 'local') return; S.playing = !E.audio.paused; paintPlay(); }));
E.audio.addEventListener('ended', () => { if (E.kind === 'local') onEnded(); });
E.audio.addEventListener('error', () => { if (E.kind === 'local') { toast('No se pudo reproducir este archivo'); } });

/* ---- reproducción robusta: no se queda pausada ni trabada ---- */
S.want = false; S.userAt = 0; S.lastPos = 0;
const ytState = () => { try { return S.ready && S.player.getPlayerState ? S.player.getPlayerState() : -9; } catch { return -9; } };
const isYtPlaying = () => { const s = ytState(); return s === 1 || s === 3; };
function reloadYT(pos) {                              // vuelve a cargar el video en el segundo donde iba
  const t = S.queue[S.i]; if (!S.ready || !t || !t.videoId || E.kind !== 'yt') return;
  try { S.player.loadVideoById({ videoId: t.videoId, startSeconds: Math.max(0, pos || 0) }); } catch {}
}
function resumeYT() {
  S.want = true; if (!S.ready) return;
  try { S.player.playVideo(); } catch {}
  const t = S.queue[S.i], pos = S.lastPos || E.time();
  clearTimeout(S.rsTimer);
  S.rsTimer = setTimeout(() => { if (S.want && E.kind === 'yt' && S.queue[S.i] === t && !isYtPlaying()) reloadYT(pos); }, 1800);
}
const wd = { pos: -1, stuck: 0, buf: 0, retry: 0, fixes: 0, id: '' };
setInterval(() => {
  if (E.kind !== 'yt' || !S.ready || !S.want) return;
  const t = S.queue[S.i], id = t ? tid(t) : ''; if (id !== wd.id) { Object.assign(wd, { pos: -1, stuck: 0, buf: 0, retry: 0, fixes: 0, id }); }
  const st = ytState(), pos = E.time();
  if (st === 1) {
    if (pos > 0) S.lastPos = pos;
    wd.stuck = Math.abs(pos - wd.pos) < 0.05 ? wd.stuck + 1 : 0; wd.pos = pos; wd.buf = 0; wd.retry = 0;
    if (wd.stuck >= 4 && wd.fixes < 4) { wd.stuck = 0; wd.fixes++; reloadYT(pos); }          // imagen congelada: recarga en el mismo punto
  } else if (st === 3) {
    if (++wd.buf >= 5 && wd.fixes < 4) { wd.buf = 0; wd.fixes++; reloadYT(S.lastPos || pos); }  // cargando demasiado: reintenta
  } else if (st === 2 || st === -1 || st === 5) {
    if (Date.now() - S.userAt > 2500 && wd.retry < 4) { wd.retry++; if (st === 2) { try { S.player.playVideo(); } catch {} } else reloadYT(S.lastPos || pos); }   // se pausó sola
  }
}, 1500);
// al salir de la app o volver, si la música debía seguir, se reanuda
document.addEventListener('visibilitychange', () => {
  [0, 80, 250, 700, 1500].forEach((ms) => setTimeout(() => { if (S.want && E.kind === 'yt' && S.ready && !isYtPlaying() && Date.now() - S.userAt > 2000) { try { S.player.playVideo(); } catch {} } }, ms));
});

/* Android avisa cuando la app pasa a segundo plano: se deja de dibujar, pero la música sigue y se vigila que no se pause */
window.__kick = () => { if (S.want && E.kind === 'yt') [0, 60, 160, 400, 900, 1800].forEach((ms) => setTimeout(() => { if (S.want && !isYtPlaying() && Date.now() - S.userAt > 1200) { try { S.player.playVideo(); } catch {} } }, ms)); };
window.__bg = (v) => { S.bg = !!v; if (!v) { S.glDirty = true; return; } if (S.want && E.kind === 'yt') [0, 60, 160, 400, 900, 1800, 4000].forEach((ms) => setTimeout(() => { if (S.bg && S.want && !isYtPlaying()) { try { S.player.playVideo(); } catch {} } }, ms)); };
window.onYouTubeIframeAPIReady = () => {
  S.player = new YT.Player('yt', {
    width: 200, height: 113, playerVars: { origin: location.origin, playsinline: 1, controls: 0, disablekb: 1, rel: 0, iv_load_policy: 3 },
    events: {
      onReady: () => { S.ready = true; S.player.setVolume(outVol()); if (S.pending) { S.player.loadVideoById(S.pending); S.pending = null; } },
      onStateChange: (e) => {
        if (E.kind !== 'yt') return;
        S.playing = e.data === YT.PlayerState.PLAYING || e.data === YT.PlayerState.BUFFERING;
        if (e.data === YT.PlayerState.ENDED) onEnded();
        // pausa que no pidió el usuario (al salir de la app, otra app, etc.): se reanuda al instante, sin esperar al vigilante
        if (e.data === YT.PlayerState.PAUSED && S.want && Date.now() - S.userAt > 1200) {
          const n = Date.now(); if (n - (S.fastT || 0) > 4000) { S.fastT = n; S.fastN = 0; }
          if (++S.fastN <= 6) { try { S.player.playVideo(); } catch {} setTimeout(() => { if (S.want && !isYtPlaying()) { try { S.player.playVideo(); } catch {} } }, 120); S.playing = true; }
        }
        paintPlay();
      },
      onError: () => { if (wd.fixes < 1) { wd.fixes++; return reloadYT(S.lastPos); } toast('Esta canción no se puede reproducir aquí. Paso a la siguiente.'); setTimeout(next, 1500); },
    },
  });
};
// el reproductor de YouTube se carga solo cuando hace falta (o con el teléfono en reposo) para que la app abra rápido
let ytLoading = false;
function ensureYT() {
  if (ytLoading) return; ytLoading = true;
  const tag = document.createElement('script'); tag.src = 'https://www.youtube.com/iframe_api'; tag.onerror = () => { ytLoading = false; }; document.head.append(tag);
}
(window.requestIdleCallback || ((f) => setTimeout(f, 2500)))(ensureYT, { timeout: 4000 });

if (!window.__lqMig && !CFG.lqMig) { CFG.liquid = false; CFG.lqMig = true; try { store.set('sf_cfg', CFG); } catch {} }   // sin cristal líquido por defecto
function paintPlay() {
  applyRate();
  document.body.classList.toggle('is-playing', S.playing);
  const t = S.queue[S.i];
  document.title = S.playing && t ? `${t.title} · Spotifree` : 'Spotifree';
  S.glDirty = true;
  if (typeof syncMotion === 'function') syncMotion();
  syncNative(true);
}
// notificación y controles del sistema (pantalla de bloqueo, auriculares) en Android
let nat = { id: '', playing: null, dur: 0 };
// portada para la notificación y la pantalla de bloqueo: una dirección https, o una miniatura en base64 si es local
function nativeCover(t) {
  const hd = t.hdCover || '', c = t.cover || '';
  const remote = (u) => /^https?:/.test(u) && !u.includes('appassets.androidplatform.net');      // las portadas del teléfono se convierten a miniatura
  if (remote(hd)) return hd;
  if (remote(c)) return c;
  if (t._nc !== undefined) return t._nc;
  t._nc = '';
  const im = new Image();
  im.onload = () => { try { const cv = document.createElement('canvas'); cv.width = cv.height = 320; cv.getContext('2d').drawImage(im, 0, 0, 320, 320); t._nc = cv.toDataURL('image/jpeg', .82); syncNative(true); } catch {} };
  im.src = c || makeCover(t.title);
  return '';
}
function syncNative(force) {
  if (!window.Native || !Native.media) return;
  const t = S.queue[S.i]; if (!t) return;
  const dur = E.dur(), id = tid(t);
  if (!force && nat.id === id && nat.playing === S.playing && (nat.dur || !dur)) return;
  nat = { id, playing: S.playing, dur };
  try { Native.media(t.title, t.artist || '', S.playing, Math.round(E.time() * 1000), Math.round(dur * 1000), nativeCover(t)); } catch {}
}

function play(list, idx, fromImg, opts) {
  S.radioSeed = (opts && opts.radio) || null; S.orig = null;
  if (CFG.shuffle && list.length > 1) {                    // aleatorio: la elegida suena primero y el resto se mezcla
    const cur = list[idx], rest = list.filter((_, k) => k !== idx);
    for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
    S.orig = list.slice(); S.queue = [cur, ...rest]; idx = 0;
  } else S.queue = list.slice();
  load(idx);
  if (fromImg && typeof flyCover === 'function') flyCover(fromImg, S.queue[idx].cover);
}
// de los resultados de YouTube Music, el que de verdad es esa canción (mismo título y artista, duración parecida)
/* versiones que NO son la canción oficial: covers, karaoke, versiones aceleradas, etc. */
const NOT_OFFICIAL = /\b(cover|karaoke|instrumental|nightcore|sped ?up|slowed|reverb|8d|tribute|made famous|tutorial|reaction|piano version|type beat|lyric video|letra|remix|live|en vivo|acoustic|acustic[ao]|mashup)\b/i;
function officialPenalty(g) {
  const t = String(g.title || '');
  let p = NOT_OFFICIAL.test(t) ? 1 : 0;
  if (/(vevo|- topic|official)/i.test(String(g.artist || ''))) p -= 0.5;   // canales oficiales
  return p;
}
// ordena los resultados: lo oficial primero, sin quitar nada (conserva el orden dentro de cada grupo)
function rankOfficial(list) {
  if (CFG.official === false) return list;
  return list.map((g, i) => ({ g, i, p: officialPenalty(g) })).sort((a, b) => a.p - b.p || a.i - b.i).map((x) => x.g);
}
function pickHit(list, t) {
  const n = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
  const wt = n(t.title), wa = n(String(t.artist || '').split(/,|&| y | feat| ft/)[0]);
  let best = null, bs = -99;
  list.forEach((g, k) => {
    const gt = n(g.title), ga = n(g.artist); let s = -k * .2;
    s += gt === wt ? 4 : (gt.includes(wt) || wt.includes(gt)) ? 1.5 : -3;
    s += wa && (ga.includes(wa) || wa.includes(ga)) ? 4 : -2;
    if (NOT_OFFICIAL.test(gt) && !NOT_OFFICIAL.test(wt)) s -= (CFG.official === false ? 2 : 6);
    if (CFG.official !== false && /(vevo|- topic)/i.test(String(g.artist || ''))) s += 1;
    if (t.duration && g.duration) s += Math.abs(t.duration - g.duration) <= 5 ? 2 : Math.abs(t.duration - g.duration) > 25 ? -3 : 0;
    if (s > bs) { bs = s; best = g; }
  });
  return best;
}
// memoria de emparejamientos Spotify → YouTube Music (para no buscar dos veces la misma canción)
const VMAP = store.get('sf_vmap', {}); let vmapT = 0;
const vkey = (t) => String(t.title || '').toLowerCase().replace(/\W+/g, ' ').trim() + '|' + String(t.artist || '').split(/,|&/)[0].toLowerCase().replace(/\W+/g, ' ').trim();
function saveVmap() { clearTimeout(vmapT); vmapT = setTimeout(() => { const k = Object.keys(VMAP); if (k.length > 1500) k.slice(0, k.length - 1500).forEach((x) => delete VMAP[x]); store.set('sf_vmap', VMAP); }, 800); }
// deja listo el video de la siguiente canción para que el cambio sea inmediato
async function prefetchNext() {
  const n = S.queue[S.i + 1]; if (!n || n.local || n.videoId || !window.ClientAPI) return;
  if (VMAP[vkey(n)]) { n.videoId = VMAP[vkey(n)]; return; }
  try {
    const d = await apiGet('search', { q: (n.artist + ' ' + n.title).trim(), type: 'songs' }); const hit = pickHit(d.results || [], n);
    if (hit && !n.videoId) { n.videoId = hit.videoId; VMAP[vkey(n)] = hit.videoId; saveVmap(); if (!n.cover) n.cover = hit.cover; if (!n.duration) n.duration = hit.duration; }
  } catch {}
}
async function load(i) {
  if (i < 0 || i >= S.queue.length) return;
  S.i = i; const t = S.queue[i], my = ++S.loadTok; S.want = true; S.userAt = Date.now(); S.lastPos = 0;
  S.bpm = 82 + (hue(tid(t)) % 48);
  let scUrl = '';   // audio directo (SoundCloud, Internet Archive, Jamendo), servido por la app
  if (t.sc && !t.videoId && CFG.scId && t.scTr) { try { const u = (await apiGet('scstream', { tr: t.scTr, cid: CFG.scId })).url || ''; scUrl = u ? proxyURL(u) : ''; } catch {} if (my !== S.loadTok) return; }
  if (!scUrl && t.stream && t.url && window.Native) scUrl = proxyURL(t.url);
  if (!t.local && !scUrl && !t.videoId && VMAP[vkey(t)]) t.videoId = VMAP[vkey(t)];       // ya lo había emparejado antes
  if (!t.local && !scUrl && !t.videoId) {
    paintTrack(t);
    try {
      const d = await apiGet('search', { q: (t.artist + ' ' + t.title).trim(), type: 'songs' });
      if (my !== S.loadTok) return;
      const hit = pickHit(d.results || [], t);
      if (!hit) { toast('No encontré «' + t.title + '» en YouTube Music'); return setTimeout(next, 1200); }
      t.videoId = hit.videoId; VMAP[vkey(t)] = hit.videoId; saveVmap(); if (!t.cover) t.cover = hit.cover; if (!t.duration) t.duration = hit.duration;
    } catch (e) { return toast('No pude buscar la canción: ' + e.message); }
  }
  paintTrack(t);
  if (t.local || scUrl) {
    E.kind = 'local';
    try { if (S.ready) S.player.pauseVideo(); } catch {}
    if (S.video) setVideoMode(false);
    const url = scUrl || (t.dev ? t.url : t.dl ? await downloadURL(t) : await libraryURL(t)); if (my !== S.loadTok || !url) return;
    await ensureAnalyser(); if (my !== S.loadTok) return;
    E.audio.src = url; E.vol(outVol());
    try { await resumeAudioCtx(); await E.audio.play(); } catch {}
  } else {
    E.kind = 'yt'; E.audio.pause(); ensureYT();
    { const mg = CFG.mixOn && S.loadTok > 1 ? .15 : 1; mixGainLast = mg; E.vol(outVol() * mg); }
    if (S.ready) S.player.loadVideoById(t.videoId); else S.pending = t.videoId;
  }
  if (typeof suggestBg === 'function') setTimeout(suggestBg, 4000);
  onTrackLoad(t); loadLyrics(t); if (typeof recordPlay === 'function') recordPlay(t);
  setTimeout(prefetchNext, 1500);
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist, album: t.album || '', artwork: t.cover ? [{ src: t.cover, sizes: '512x512' }] : [] });
      navigator.mediaSession.setActionHandler('play', () => E.toggle()); navigator.mediaSession.setActionHandler('pause', () => E.toggle());
      navigator.mediaSession.setActionHandler('nexttrack', next); navigator.mediaSession.setActionHandler('previoustrack', prev);
    } catch {}
  }
}
/* pausar y reanudar con fundido suave */
let fadeTok = 0;
function fade(from, to, ms, done) {
  const tok = ++fadeTok, steps = Math.max(1, Math.round(ms / 30)); let i = 0;
  const iv = setInterval(() => {
    if (tok !== fadeTok) return clearInterval(iv);
    i++; E.vol(from + (to - from) * i / steps);
    if (i >= steps) { clearInterval(iv); if (done) done(); }
  }, 30);
}
const toggle = () => {
  const v = outVol(), playing = E.kind === 'yt' ? isYtPlaying() : S.playing;
  if (playing) fade(v, 0, 220, () => { E.toggle(); E.vol(v); });
  else { E.vol(0); E.toggle(); fade(0, v, 280); }
};
function applyRate() {
  const r = CFG.rate || 1;
  try { if (E.kind === 'yt') { if (S.ready && S.player.setPlaybackRate) S.player.setPlaybackRate(r); } else E.audio.playbackRate = r; } catch {}
}
// al terminar una canción: repetir, parar o seguir
function onEnded() {
  if (S.sleepEnd) { clearSleep(true); toast('Temporizador: música pausada'); return; }
  if (CFG.repeat === 2) { E.seek(0); if (E.kind === 'yt') { try { S.player.playVideo(); } catch {} } else E.audio.play().catch(() => {}); return; }
  if (S.i >= S.queue.length - 1 && CFG.repeat === 0 && !S.radioSeed) return;      // fin de la lista
  next();
}
// comandos que llegan desde la notificación, la pantalla de bloqueo y los auriculares de Android
window.__media = (c, arg) => {
  if (c === 'next') next(); else if (c === 'prev') prev();
  else if (c === 'play') { if (!(E.kind === 'yt' ? isYtPlaying() : S.playing)) toggle(); } else if (c === 'pause') { if (E.kind === 'yt' ? isYtPlaying() : S.playing) toggle(); }
  else if (c === 'seek') E.seek(Math.max(0, (+arg || 0) / 1000));
};
const next = async () => {
  if (!S.queue.length) return;
  if (S.i >= S.queue.length - 1 && S.radioSeed && window.ClientAPI) {         // radio infinita: pide más canciones parecidas
    try {
      const d = await apiGet('radio', { videoId: S.radioSeed }); const have = new Set(S.queue.map(tid));
      const more = d.tracks.filter((x) => !have.has(tid(x))); if (more.length) { S.queue.push(...more); S.radioSeed = more[more.length - 1].videoId; if (typeof renderQueue === 'function') renderQueue(); }
    } catch {}
  }
  load((S.i + 1) % S.queue.length);
};
const prev = () => { if (!S.queue.length) return; if (E.time() > 4) E.seek(0); else load((S.i - 1 + S.queue.length) % S.queue.length); };

// Las descargas se cargan como blob: así se puede adelantar y retroceder sin depender del servidor interno.
let dlBlobURL = null;
async function downloadURL(t) {
  try {
    const r = await fetch(t.url); if (!r.ok) throw new Error('no existe');
    const u = URL.createObjectURL(await r.blob());
    if (dlBlobURL) URL.revokeObjectURL(dlBlobURL);
    return (dlBlobURL = u);
  } catch { toast('No encuentro el archivo descargado'); return ''; }
}
