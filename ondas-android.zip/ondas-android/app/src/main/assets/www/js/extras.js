'use strict';
/* ===== Extras: aleatorio y repetir, temporizador, velocidad, ecualizador, resumen, acento y gestos ===== */

/* ---------- aleatorio y repetir ---------- */
function paintModes() {
  $('btnShuffle').classList.toggle('on', !!CFG.shuffle);
  const r = $('btnRepeat'); r.classList.toggle('on', CFG.repeat > 0); r.dataset.r = CFG.repeat;
}
function toggleShuffle() {
  CFG.shuffle = !CFG.shuffle; saveCfg();
  if (S.queue.length > 1 && S.i >= 0) {
    const cur = S.queue[S.i];
    if (CFG.shuffle) {
      const rest = S.queue.filter((_, k) => k !== S.i);
      for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
      S.orig = S.queue.slice(); S.queue = [cur, ...rest]; S.i = 0;
    } else if (S.orig) { S.queue = S.orig; S.i = Math.max(0, S.queue.indexOf(cur)); S.orig = null; }
    renderQueue();
  }
  paintModes(); haptic(8); toast(CFG.shuffle ? 'Aleatorio activado' : 'Aleatorio desactivado');
}
function cycleRepeat() {
  CFG.repeat = (CFG.repeat + 1) % 3; saveCfg(); paintModes(); haptic(8);
  toast(['Repetir: apagado', 'Repetir toda la lista', 'Repetir esta canción'][CFG.repeat]);
}

/* ---------- temporizador de sueño ---------- */
function sleepLabel() { return S.sleepEnd ? 'Al terminar la canción' : S.sleepAt ? `Quedan ${Math.max(1, Math.ceil((S.sleepAt - Date.now()) / 60000))} min` : 'Apagado'; }
function paintSleep() { document.body.classList.toggle('sleep-on', !!(S.sleepAt || S.sleepEnd)); const el = $('sleepSub'); if (el) el.textContent = sleepLabel(); }
function clearSleep(quiet) { clearTimeout(S.sleepTimer); S.sleepAt = 0; S.sleepEnd = false; paintSleep(); if (!quiet) toast('Temporizador desactivado'); }
function setSleep(min) {
  clearSleep(true);
  if (min < 0) { S.sleepEnd = true; toast('Se pausará al terminar la canción'); }
  else { S.sleepAt = Date.now() + min * 60000; S.sleepTimer = setTimeout(sleepFire, min * 60000); toast(`Se pausará en ${min} minutos`); }
  paintSleep();
}
function sleepFire() {
  clearSleep(true);
  if (!S.playing) return;
  const v = outVol();
  fade(v, 0, 3000, () => { E.toggle(); E.vol(v); toast('Temporizador: música pausada'); });
}
function sleepMenu() {
  openMenu({ title: 'Temporizador de sueño', sub: sleepLabel() }, [
    ...[15, 30, 45, 60, 90].map((m) => ({ icon: 'moon', label: `${m} minutos`, run: () => setSleep(m) })),
    { icon: 'note', label: 'Al terminar la canción', run: () => setSleep(-1) },
    S.sleepAt || S.sleepEnd ? { icon: 'x', label: 'Desactivar', run: () => clearSleep() } : null,
  ]);
}

/* ---------- velocidad ---------- */
function paintSpeed() { const el = $('speedSub'); if (el) el.textContent = (CFG.rate || 1) + '×'; }
function speedMenu() {
  openMenu({ title: 'Velocidad de reproducción', sub: (CFG.rate || 1) + '×' }, [0.75, 0.9, 1, 1.15, 1.25, 1.5, 2].map((v) => ({
    icon: (CFG.rate || 1) === v ? 'check' : 'chart', label: v === 1 ? 'Normal (1×)' : v + '×', run: () => { CFG.rate = v; saveCfg(); applyRate(); paintSpeed(); toast('Velocidad ' + v + '×'); },
  })));
}

/* ---------- ecualizador de audio (música local y descargas) ---------- */
const EQ_FREQS = ['60 Hz', '230 Hz', '910 Hz', '3,6 kHz', '14 kHz'];
const EQ_PRESETS = { Plano: [0, 0, 0, 0, 0], Graves: [7, 4, 0, -1, -1], Agudos: [-2, -1, 0, 4, 7], Vocal: [-3, 0, 4, 3, -1], Rock: [5, 2, -2, 3, 5], Pop: [-1, 3, 4, 2, -1], Electrónica: [6, 3, 0, 2, 5], Acústico: [3, 2, 1, 2, 2] };
function setEqGains(arr) {
  CFG.eqg = arr.slice(); saveCfg();
  if (AN.filters) AN.filters.forEach((f, i) => { try { f.gain.value = arr[i]; } catch {} });
  paintEq();
}
function paintEq() {
  const g = CFG.eqg || [0, 0, 0, 0, 0];
  $('eqBands').querySelectorAll('input').forEach((inp, i) => { inp.value = g[i]; inp.style.setProperty('--p', ((g[i] + 12) / 24 * 100) + '%'); inp.parentElement.querySelector('output').textContent = (g[i] > 0 ? '+' : '') + g[i] + ' dB'; });
  const key = Object.keys(EQ_PRESETS).find((k) => EQ_PRESETS[k].every((v, i) => v === g[i]));
  $('eqPresets').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.p === key));
}
function initEq() {
  Object.keys(EQ_PRESETS).forEach((k) => { const b = document.createElement('button'); b.dataset.p = k; b.textContent = k; b.onclick = () => { haptic(6); setEqGains(EQ_PRESETS[k]); }; $('eqPresets').append(b); });
  EQ_FREQS.forEach((f, i) => {
    const row = document.createElement('label'); row.className = 'item eqrow';
    row.innerHTML = `<span>${f}</span><input type="range" min="-12" max="12" step="1" value="0" aria-label="${f}"><output>0 dB</output>`;
    row.querySelector('input').addEventListener('input', (e) => { const g = (CFG.eqg || [0, 0, 0, 0, 0]).slice(); g[i] = +e.target.value; setEqGains(g); });
    $('eqBands').append(row);
  });
  paintEq();
}

/* ---------- resumen: lo que más escuchas ---------- */
const STATS = Object.assign({ plays: {}, secs: 0 }, store.get('sf_stats', {}));
const saveStats = () => store.set('sf_stats', STATS);
function recordPlay(t) {
  const id = tid(t), p = STATS.plays[id] || (STATS.plays[id] = { n: 0 });
  p.n++; p.track = slim(t); saveStats();
  if (typeof refreshHome === 'function') refreshHome();
}
setInterval(() => { if (S.playing) { STATS.secs++; if (STATS.secs % 20 === 0) saveStats(); } }, 1000);
function topTracks(n) { return Object.values(STATS.plays).sort((a, b) => b.n - a.n).slice(0, n); }
function renderStats() {
  const all = Object.values(STATS.plays), total = all.reduce((s, p) => s + p.n, 0), h = Math.floor(STATS.secs / 3600), m = Math.floor(STATS.secs % 3600 / 60);
  const art = {}; all.forEach((p) => { const a = p.track.artist || 'Desconocido'; art[a] = (art[a] || 0) + p.n; });
  const topA = Object.entries(art).sort((a, b) => b[1] - a[1]).slice(0, 5), top = topTracks(8).map((p) => p.track);
  const box = $('statsBody');
  box.innerHTML = `<div class="stat-grid"><div class="glass"><b>${h ? h + ' h ' : ''}${m} min</b><small>escuchados</small></div><div class="glass"><b>${total}</b><small>reproducciones</small></div><div class="glass"><b>${all.length}</b><small>canciones distintas</small></div></div>`;
  if (!total) { box.insertAdjacentHTML('beforeend', '<p class="empty-t">Todavía no hay datos. Escucha música y aquí verás tu resumen.</p>'); return; }
  box.insertAdjacentHTML('beforeend', '<h3>Canciones favoritas</h3><div class="list" id="statTop" style="padding:0"></div>');
  fillList($('statTop'), top, {});
  box.insertAdjacentHTML('beforeend', '<h3>Artistas favoritos</h3><div class="group glass" id="statArt"></div>');
  topA.forEach(([a, n], i) => $('statArt').insertAdjacentHTML('beforeend', `<div class="item"><div><b>${i + 1}. ${esc(a)}</b></div><small>${n} ${n === 1 ? 'vez' : 'veces'}</small></div>`));
  box.insertAdjacentHTML('beforeend', '<button class="pill glass" id="statReset" style="margin-top:18px">Borrar mi resumen</button>');
  $('statReset').onclick = () => { STATS.plays = {}; STATS.secs = 0; saveStats(); renderStats(); refreshHome(); toast('Resumen borrado'); };
}

/* ---------- color de acento ---------- */
const ACCENTS = { Rosado: '#fa2d55', Verde: '#1ed760', Violeta: '#a78bfa', Rosa: '#ff5c8a', Azul: '#4dabff', Cian: '#19e3ff', Naranja: '#ff9f43', Auto: 'auto' };
function applyAccent() {
  const v = ACCENTS[CFG.accent] || ACCENTS.Rosado;
  document.documentElement.style.setProperty('--accfg', ['Verde', 'Naranja', 'Auto'].includes(CFG.accent) ? '#000' : '#fff');
  document.documentElement.style.setProperty('--acc', v === 'auto' ? 'var(--c1)' : v);
  document.querySelectorAll('#accSw button').forEach((b) => b.classList.toggle('on', b.dataset.a === CFG.accent));
}
function initAccent() {
  Object.keys(ACCENTS).forEach((k) => {
    const b = document.createElement('button'); b.dataset.a = k; b.setAttribute('aria-label', k); b.title = k;
    b.style.background = ACCENTS[k] === 'auto' ? 'conic-gradient(#fa2d55,#1ed760,#4dabff,#a78bfa,#ff9f43,#fa2d55)' : ACCENTS[k];
    b.onclick = () => { CFG.accent = k; saveCfg(); applyAccent(); haptic(8); }; $('accSw').append(b);
  });
  applyAccent();
}

/* ---------- gestos ---------- */
// doble toque en la portada = me gusta
(function dblLike() {
  let last = 0; const w = $('np');
  w.addEventListener('pointerup', (e) => {
    const r = $('artbox').getBoundingClientRect();                       // el gesto de cerrar captura el puntero, así que se mide por posición
    if (S.lyrOpen || e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return;
    const now = Date.now();
    if (now - last < 320) {
      last = 0; const t = S.queue[S.i]; if (!t) return;
      const h = document.createElement('div'); h.className = 'burst-heart'; h.innerHTML = '<svg class="ic"><use href="#i-heart"/></svg>';
      $('artbox').append(h); setTimeout(() => h.remove(), 900);
      if (!isLiked(t)) toggleLike(t); else haptic(10);
    } else last = now;
  });
})();
// deslizar el mini reproductor a los lados cambia de canción
(function miniSwipe() {
  const m = $('mini'), main = m.querySelector('.main'); let sx = 0, sy = 0, dx = 0, drag = false, down = false;
  main.addEventListener('pointerdown', (e) => { down = true; drag = false; sx = e.clientX; sy = e.clientY; dx = 0; });
  main.addEventListener('pointermove', (e) => {
    if (!down) return; dx = e.clientX - sx;
    if (!drag && Math.abs(dx) > 14 && Math.abs(e.clientY - sy) < 30) { drag = true; m.style.transition = 'none'; }
    if (drag) { m.style.transform = `translateX(${dx * 0.6}px)`; m.style.opacity = 1 - Math.min(0.5, Math.abs(dx) / 400); }
  });
  const end = () => {
    if (!down) return; down = false;
    if (drag) {
      m.style.transition = 'transform .45s cubic-bezier(.34,1.56,.64,1),opacity .3s';
      if (Math.abs(dx) > 70) { haptic(10); dx < 0 ? next() : prev(); }
      m.style.transform = ''; m.style.opacity = ''; setTimeout(() => (m.style.transition = ''), 480);
      main._sw = true; setTimeout(() => (main._sw = false), 60);
    }
  };
  main.addEventListener('pointerup', end); main.addEventListener('pointercancel', end);
  main.addEventListener('click', (e) => { if (main._sw) { e.stopImmediatePropagation(); e.preventDefault(); } }, true);
})();
// tirar hacia abajo para actualizar Inicio y Novedades
function pullToRefresh(viewId, fn) {
  const sc = document.querySelector(`#${viewId} .vscroll`); let y0 = null, d = 0;
  const ind = document.createElement('div'); ind.className = 'ptr'; ind.innerHTML = '<svg class="ic s"><use href="#i-refresh"/></svg>'; sc.parentElement.append(ind);
  sc.addEventListener('touchstart', (e) => { y0 = sc.scrollTop <= 0 ? e.touches[0].clientY : null; d = 0; }, { passive: true });
  sc.addEventListener('touchmove', (e) => {
    if (y0 == null) return; d = Math.max(0, e.touches[0].clientY - y0);
    if (d > 0) { ind.style.transition = 'none'; ind.style.opacity = Math.min(1, d / 80); ind.style.transform = `translate(-50%,${Math.min(d, 120) * 0.6}px) rotate(${d * 3}deg)`; }
  }, { passive: true });
  sc.addEventListener('touchend', () => {
    ind.style.transition = '';
    if (y0 != null && d > 85) { ind.classList.add('spin'); ind.style.opacity = 1; ind.style.transform = 'translate(-50%,56px)'; haptic(12); Promise.resolve(fn()).finally(() => setTimeout(() => { ind.classList.remove('spin'); ind.style.opacity = 0; ind.style.transform = 'translate(-50%,0)'; }, 400)); }
    else { ind.style.opacity = 0; ind.style.transform = 'translate(-50%,0)'; }
    y0 = null;
  });
}

/* ---------- acciones ---------- */
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act;
  if (a === 'shuffle') toggleShuffle(); else if (a === 'repeat') cycleRepeat();
  else if (a === 'sleep') { closeSheet('set'); sleepMenu(); } else if (a === 'speed') { closeSheet('set'); speedMenu(); }
  else if (a === 'open-eqs') { closeSheet('set'); openSheet('eqs'); paintEq(); } else if (a === 'close-eqs') closeSheet('eqs');
  else if (a === 'open-stats') { closeSheet('set'); renderStats(); openSheet('stats'); } else if (a === 'close-stats') closeSheet('stats');
});
setInterval(paintSleep, 20000);

initEq(); initAccent(); paintModes(); paintSleep(); paintSpeed();
pullToRefresh('v-home', () => loadHome(true));
pullToRefresh('v-news', () => loadNews(true));

/* ---------- mezcla entre canciones ----------
   Ajustes de la mezcla: duración, curva de volumen y efecto. Un solo reproductor: la canción se apaga y la siguiente sube.
   Corre con un temporizador (no con los cuadros de pantalla), así sigue con la pantalla apagada. */
const MIX_PRESETS = {
  auto: { n: 'Automática', sec: 6, curve: 'eq', fx: 'none', i: true }, custom: { n: 'Personalizada' },
  fade: { n: 'Fundido', sec: 10, curve: 'lin', fx: 'none' }, quick: { n: 'Corte rápido', sec: 2, curve: 'lin', fx: 'none' },
  club: { n: 'Club', sec: 8, curve: 'late', fx: 'rise' }, vinyl: { n: 'Vinilo', sec: 4, curve: 'fast', fx: 'brake' },
};
const mc = () => Object.assign({ preset: 'auto', sec: 6, curve: 'eq', fx: 'none', bend: 1, end: 5 }, CFG.mixCfg || {});
const mixOut = (p, c, g = 1) => (c === 'eq' ? Math.cos((1 - p) * Math.PI / 2) : c === 'fast' ? p * p : c === 'custom' ? Math.pow(p, g) : p);
const mixIn2 = (q, c, g = 1) => (c === 'eq' ? Math.sin(q * Math.PI / 2) : c === 'late' ? q * q : c === 'custom' ? Math.pow(q, 1 / g) : q);
function paintMix() { document.querySelectorAll('.mixbtn').forEach((b) => b.classList.toggle('on', !!CFG.mixOn)); }
let MXD = null, MXPH = null, MXLIVE = false, MXPREV = false, MXREAL = null, MXORIG = null, mixSeeking = false;
const mixPt = () => Math.max(0, E.dur() - (MXD ? MXD.sec : 6) - 4);
const isPlay = () => (E.kind === 'yt' ? isYtPlaying() : S.playing);   // borrador mientras la hoja está abierta
const wave = (seed, n) => { let h = 0; for (const ch of String(seed)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Array.from({ length: n }, (_, i) => { h = (h * 1103515245 + 12345) | 0; return .25 + .75 * Math.abs(Math.sin(i * .37 + (h & 255) / 40)) * (.55 + .45 * ((h >> 8 & 255) / 255)); }); };
function drawMixViz() {
  const d = MXD, svg = $('mixViz'), W = 320, N = 64, A = S.queue[S.i], B = S.queue[S.i + 1] || S.queue[0];
  const hw = Math.max(20, d.sec / 12 * 120), x0 = 160 - hw, x1 = 160 + hw, wA = wave(A ? tid(A) : 'a', N), wB = wave(B ? tid(B) : 'b', N);
  let h = '', bars = (arr, cy, amp, col, from, to) => arr.map((v, i) => { const x = i * W / N; const dim = x < from || x > to ? .35 : 1; return `<rect x="${x.toFixed(1)}" y="${(cy - v * amp).toFixed(1)}" width="3" height="${(v * amp * 2).toFixed(1)}" rx="1.5" fill="${col}" opacity="${dim}"/>`; }).join('');
  h += `<rect class="mix-win${MXLIVE ? ' live' : ''}" x="${x0}" y="0" width="${x1 - x0}" height="210" rx="14" fill="rgba(255,255,255,.09)"/>`;
  h += bars(wA, 52, 34, '#d98a3a', x0, x1) + bars(wB, 158, 38, '#d98a3a', x0, x1);
  const pts = (f, y0, y1, k) => Array.from({ length: 31 }, (_, i) => { const t = i / 30; return `${(x0 + t * (x1 - x0)).toFixed(1)},${(y1 - (y1 - y0) * f(t)).toFixed(1)}`; }).join(' ');
  h += `<polyline fill="none" stroke="#3aa0e8" stroke-width="3" stroke-linejoin="round" points="${pts((t) => mixOut(1 - t, d.curve, d.bend), 20, 84)}"/>`;
  h += `<polyline fill="none" stroke="#3aa0e8" stroke-width="3" stroke-linejoin="round" points="${pts((t) => mixIn2(t, d.curve, d.bend), 120, 196)}"/>`;
  if (d.fx !== 'none') h += `<polyline fill="none" stroke="#f08af0" stroke-width="2.5" stroke-linejoin="round" points="${pts((t) => (d.fx === 'brake' ? 1 - .5 * t : .2 + .8 * t), 120, 196)}"/>`;
  const my = 84 - 64 * mixOut(.5, d.curve, d.bend);
  h += `<rect x="${x0 - 4}" y="70" width="8" height="70" rx="4" fill="#fff" data-h="l"/><rect x="${x1 - 4}" y="70" width="8" height="70" rx="4" fill="#fff" data-h="r"/>`;
  h += `<circle cx="160" cy="${my.toFixed(1)}" r="9" fill="#fff" stroke="#3aa0e8" stroke-width="3" data-h="c"/>`;
  if (MXPH) { const px = (v) => (x0 + v * (x1 - x0)).toFixed(1); if (MXPH.o != null) h += `<line x1="${px(MXPH.o)}" x2="${px(MXPH.o)}" y1="4" y2="100" stroke="#27d160" stroke-width="3"/>`; if (MXPH.i != null) h += `<line x1="${px(MXPH.i)}" x2="${px(MXPH.i)}" y1="112" y2="206" stroke="#27d160" stroke-width="3"/>`; }
  svg.innerHTML = h;
  $('mixInfo').textContent = d.sec + ' s · ' + (MIX_PRESETS[d.preset]?.n || 'Personalizada') + (d.end ? ' · final fundido ' + d.end + ' s' : '');
  const row = (t) => t ? `<img src="${esc(t.cover || makeCover(t.title))}" alt=""><div><b>${esc(t.title)}</b><small>${esc(t.artist || '')}</small></div><span>${t.duration ? fmt(t.duration) : ''}</span>` : '<div></div>';
  $('mixA').innerHTML = row(A); $('mixB').innerHTML = row(B);
  $('mixPresets').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.p === d.preset));
  if (![...$('mixSec').options].some((o) => +o.value === d.sec)) $('mixSec').add(new Option(d.sec + ' s', d.sec));
  $('mixSec').value = String(d.sec); $('mixCurve').value = d.curve; $('mixFx').value = d.fx; $('mixEnd').value = String(d.end || 0);
}
function openMix() {
  MXD = Object.assign({}, mc());
  $('mixOn').checked = !!CFG.mixOn;
  $('mixPresets').innerHTML = Object.entries(MIX_PRESETS).map(([k, v]) => `<button data-p="${k}">${v.i ? '✦ ' : ''}${v.n}</button>`).join('');
  drawMixViz(); openSheet('mixs');
  // vista previa: la canción salta al punto de la mezcla y suena ese fragmento en bucle
  MXORIG = { pos: E.time(), playing: !!(S.want && isPlay()) }; MXREAL = null;
  if (E.dur() && S.queue.length) { MXPREV = true; E.seek(mixPt()); if (!isPlay()) { S.want = true; S.userAt = Date.now(); E.toggle(); } mixIn = { tok: S.loadTok, at: 0 }; }
  else { MXPREV = false; toast('Pon una canción para oír la vista previa'); }
}
function mixLeave() {
  if (!MXPREV && !MXORIG) return; MXPREV = false; MXREAL = null; mixGainLast = 1; E.vol(outVol()); mixRate(1);
  if (MXORIG) { const o = MXORIG; MXORIG = null; if (E.dur()) E.seek(o.pos); if (!o.playing && isPlay()) E.toggle(); }
}
$('mixSeek').addEventListener('pointerdown', () => { mixSeeking = true; });
$('mixSeek').addEventListener('input', (e) => { const d = E.dur(); if (d) { E.seek(e.target.value / 1000 * d); $('mixCur').textContent = fmt(e.target.value / 1000 * d); mixIn = { tok: S.loadTok, at: 0 }; } });
['pointerup', 'pointercancel', 'change'].forEach((ev) => $('mixSeek').addEventListener(ev, () => setTimeout(() => (mixSeeking = false), 200)));
setInterval(() => {
  if ($('mixs').hidden) return; const d = E.dur(), c = E.time();
  if (!mixSeeking && d) { $('mixSeek').value = Math.round(c / d * 1000); $('mixSeek').style.setProperty('--p', (c / d * 100) + '%'); }
  $('mixCur').textContent = fmt(c); $('mixDur').textContent = fmt(d || 0);
  $('mixPP').innerHTML = `<svg class="ic s"><use href="#i-${isPlay() ? 'pause' : 'play'}"/></svg>`;
}, 250);
$('mixPresets').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b || !MXD) return; const p = MIX_PRESETS[b.dataset.p]; MXD.preset = b.dataset.p; if (p.sec) Object.assign(MXD, { sec: p.sec, curve: p.curve, fx: p.fx, bend: 1 }); haptic(5); drawMixViz(); });
[['mixSec', 'sec'], ['mixCurve', 'curve'], ['mixFx', 'fx'], ['mixEnd', 'end']].forEach(([id, k]) => $(id).addEventListener('change', (e) => { MXD[k] = (k === 'sec' || k === 'end') ? +e.target.value : e.target.value; MXD.preset = 'custom'; drawMixViz(); }));
/* arrastrar: los bordes cambian la duración, el punto de la curva le da forma */
(() => {
  const svg = $('mixViz'); let drag = null;
  const pos = (e) => { const r = svg.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * 320, y: (e.clientY - r.top) / r.height * 210 }; };
  svg.style.touchAction = 'none';
  svg.addEventListener('pointerdown', (e) => { const h = e.target.getAttribute && e.target.getAttribute('data-h'); if (!h || !MXD) return; drag = h; svg.setPointerCapture(e.pointerId); haptic(5); e.preventDefault(); });
  svg.addEventListener('pointermove', (e) => {
    if (!drag || !MXD) return; const p = pos(e);
    if (drag === 'l' || drag === 'r') { const s = Math.max(1, Math.min(12, Math.round(Math.abs(p.x - 160) / 120 * 12))); if (s !== MXD.sec) { MXD.sec = s; MXD.preset = 'custom'; haptic(3); } }
    else { const v = Math.max(.06, Math.min(.94, (84 - p.y) / 64)); MXD.bend = Math.max(.35, Math.min(3, Math.log(v) / Math.log(.5))); MXD.curve = 'custom'; MXD.preset = 'custom'; }
    drawMixViz();
  });
  const end = () => { drag = null; };
  svg.addEventListener('pointerup', end); svg.addEventListener('pointercancel', end);
})();
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  if (b.dataset.act === 'mix-close') { closeSheet('mixs'); mixLeave(); }
  else if (b.dataset.act === 'mix-pp') { S.userAt = Date.now(); if (isPlay()) { S.want = false; } else S.want = true; E.toggle(); }
  else if (b.dataset.act === 'mix-save') { CFG.mixCfg = { preset: MXD.preset, sec: MXD.sec, curve: MXD.curve, fx: MXD.fx, bend: MXD.bend, end: MXD.end }; CFG.mixOn = $('mixOn').checked; saveCfg(); paintMix(); closeSheet('mixs'); mixLeave(); toast(CFG.mixOn ? 'Mezcla guardada: ' + MXD.sec + ' s' : 'Mezcla guardada (apagada)'); }
  else if (b.dataset.act === 'mix-test') {                       // salta al final de la canción para oír cómo entra la siguiente
    const dur = E.dur(); if (!dur || !S.queue.length) return toast('Pon una canción para probar la mezcla');
    CFG.mixCfg = Object.assign({}, MXD); const was = CFG.mixOn; CFG.mixOn = true; mixTest = was; MXREAL = S.loadTok; E.seek(Math.max(0, dur - MXD.sec - 3)); toast('Probando la mezcla…');
  }
});
let mixTest = null, mixGainLast = 1, mixRateLast = 1, mixIn = { tok: -1, at: 0 }, mixAdv = -1;
function mixRate(r) { r *= CFG.rate || 1; if (Math.abs(r - mixRateLast) < .02) return; mixRateLast = r; try { if (E.kind === 'yt') { if (S.ready && S.player.setPlaybackRate) S.player.setPlaybackRate(r); } else E.audio.playbackRate = r; } catch {} }
setInterval(() => {
  if (MXREAL !== null && S.loadTok !== MXREAL && (Date.now() - mixIn.at) / 1000 > mc().sec + .5 && mixIn.tok === S.loadTok) { MXREAL = null; mixIn = { tok: S.loadTok, at: 0 }; if (MXPREV) E.seek(mixPt()); }   // la prueba real ya pasó: vuelve la vista previa
  const prev = MXPREV && MXREAL === null && !!MXD, c = prev ? MXD : mc(), m = prev ? c.sec : (CFG.mixOn ? c.sec : 0);
  if (!m || !S.want || !S.queue.length || CFG.repeat === 2 || S.seeking) { if (mixGainLast !== 1) { mixGainLast = 1; E.vol(outVol()); } if (mixRateLast !== (CFG.rate || 1)) { mixRateLast = CFG.rate || 1; applyRate(); } mixFlag(false); return; }
  const dur = E.dur(), cur = E.time(); if (!dur || dur < m * 2 + 2) return;
  const rem = dur - cur, hasNext = prev || S.i < S.queue.length - 1 || CFG.repeat === 1 || !!S.radioSeed;
  if (mixIn.tok !== S.loadTok) mixIn = { tok: S.loadTok, at: Date.now() };
  let g = 1, r = 1, ph = null;
  const inT = (Date.now() - mixIn.at) / 1000, bd = c.bend || 1;
  if (inT < m && (prev ? mixIn.at > 0 : (cur < m + 1 && S.loadTok > 1))) { const q = inT / m; g = Math.min(g, .12 + .88 * mixIn2(q, c.curve, bd)); if (c.fx === 'rise') r = .8 + .2 * q; ph = { i: q }; }
  if (hasNext && rem < m) { const p = Math.max(0, rem / m); g = Math.min(g, mixOut(p, c.curve, bd)); if (c.fx === 'brake') r = 1 - .5 * (1 - p); ph = { o: 1 - p }; }
  const ef = c.end | 0; if (!hasNext && ef && rem < ef) { const p = Math.max(0, rem / ef); g = Math.min(g, p); ph = { o: 1 - p }; }      // final fundido de la última canción
  if (prev && rem <= .45) { mixIn = { tok: S.loadTok, at: Date.now() }; E.seek(mixPt()); return; }      // vista previa: vuelve a empezar el fragmento
  if (hasNext && rem <= .45 && mixAdv !== S.loadTok) { mixAdv = S.loadTok; if (mixTest !== null) { CFG.mixOn = mixTest; mixTest = null; } next(); return; }
  if (Math.abs(g - mixGainLast) > .02) { mixGainLast = g; E.vol(outVol() * g); }
  mixRate(r); mixFlag(!!ph, ph);
}, 100);
let mixFlagOn = false;
function mixFlag(on, ph) {
  if (on !== mixFlagOn) { mixFlagOn = on; document.body.classList.toggle('mixing', on); MXLIVE = on; }
  if (!$('mixs').hidden && MXD && (on || MXPH)) { MXPH = on ? ph : null; drawMixViz(); }
}

/* ---------- sin conexión ---------- */
function paintOnline() { document.body.classList.toggle('offline', navigator.onLine === false); }
window.addEventListener('online', () => { paintOnline(); toast('Conexión recuperada'); });
window.addEventListener('offline', paintOnline); paintOnline();
