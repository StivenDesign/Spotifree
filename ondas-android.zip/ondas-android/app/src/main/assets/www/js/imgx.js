/* Imágenes optimizadas: las miniaturas piden solo el tamaño que se ve (y WebP) en vez de la portada de 800 px.
   Las portadas grandes (reproductor, álbum) no pasan por aquí. Si la dirección no es de Google, se deja igual. */
function smallImg(u, css) {
  try {
    if (!u || typeof u !== 'string' || CFG.imgOpt === false) return u;
    const m = u.match(/^(https:\/\/(?:lh\d|yt\d)\.(?:googleusercontent|ggpht)\.com\/[^=]+)=w\d+-h\d+(?:-[a-z0-9-]*)?$/i);
    if (!m) return u;
    const dpr = Math.min(window.devicePixelRatio || 2, 2.5), px = Math.max(120, Math.min(800, Math.ceil((css || 120) * dpr / 60) * 60));
    return m[1] + '=w' + px + '-h' + px + '-l85-rw';
  } catch { return u; }
}
