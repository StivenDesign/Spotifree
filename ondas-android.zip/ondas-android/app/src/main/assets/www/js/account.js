'use strict';
/* ===== Cuenta: perfil, servicio (Spotify o YouTube), importar listas ===== */
const ACC = Object.assign({ svc: '', name: '', sp: null }, store.get('sf_acc', {}));
const saveAcc = () => store.set('sf_acc', ACC);
const SVC = { spotify: 'Spotify', youtube: 'YouTube' };
const REDIRECT = 'spotifree://callback';

function paintAccount() {
  const letter = ACC.name ? ACC.name.trim()[0].toUpperCase() : '';
  ['hAvatarTxt', 'accAvatar', 'setAvatar'].forEach((id) => {
    const el = $(id); const span = id === 'hAvatarTxt' ? el : el.firstElementChild;
    span.innerHTML = letter ? esc(letter) : '<svg class="ic s"><use href="#i-user"/></svg>';
  });
  $('accName').textContent = ACC.name || 'Sin cuenta';
  $('accSvc').textContent = ACC.svc ? SVC[ACC.svc] + (ACC.svc === 'spotify' && ACC.sp && ACC.sp.access ? ' · conectada' : '') : 'Elige un servicio para empezar';
  $('setAccName').textContent = ACC.name || 'Añadir cuenta';
  $('setAccSvc').textContent = ACC.svc ? SVC[ACC.svc] : 'Spotify o YouTube';
  $('accSeg').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.svc === ACC.svc));
  $('accYT').hidden = ACC.svc !== 'youtube'; $('accSP').hidden = ACC.svc !== 'spotify';
  if (document.activeElement !== $('accNameIn')) $('accNameIn').value = ACC.name || '';
  $('spId').value = (ACC.sp && ACC.sp.id) || $('spId').value || '';
  const on = !!(ACC.sp && ACC.sp.access);
  $('spOut').hidden = !on; $('spConnect').textContent = on ? 'Reconectar' : 'Conectar';
  if (typeof refreshHome === 'function') $('hGreet').textContent = greeting();
}
$('accSeg').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  ACC.svc = ACC.svc === b.dataset.svc ? '' : b.dataset.svc; saveAcc(); paintAccount(); haptic(6);
  if (ACC.svc === 'spotify' && ACC.sp && ACC.sp.access) loadSpotifyLists();
});
$('accNameIn').addEventListener('input', (e) => { ACC.name = e.target.value.trim().slice(0, 24); saveAcc(); paintAccount(); });

/* ---------- YouTube: importar una lista por enlace (sin iniciar sesión) ---------- */
$('ytForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const raw = $('ytLink').value.trim(); if (!raw) return;
  let id = ''; try { id = new URL(raw).searchParams.get('list') || ''; } catch {}
  if (!id && /^(PL|OL|VL|UU|LL)[\w-]{8,}$/.test(raw)) id = raw;
  if (!id) return toast('Ese enlace no trae una lista de YouTube');
  if (!window.ClientAPI) return toast('Importar funciona en la app de Android');
  toast('Importando…');
  try {
    const d = await apiGet('collection', { id: id.startsWith('VL') ? id : 'VL' + id });
    if (!d.tracks.length) return toast('La lista está vacía o es privada');
    newList(d.title || 'Lista de YouTube', d.tracks); $('ytLink').value = '';
    toast(`Importadas ${d.tracks.length} ${d.tracks.length === 1 ? 'canción' : 'canciones'}`); closeSheet('acc'); goTab('lib'); libFilter = 'lists'; syncLibChips(); renderLib();
  } catch (err) { toast('No pude importarla: ' + err.message); }
});

/* ---------- Spotify (PKCE, sin servidor propio) ---------- */
const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
async function spConnect() {
  const id = $('spId').value.trim();
  if (!/^[0-9a-f]{32}$/i.test(id)) return toast('El Client ID tiene 32 letras y números');
  ACC.sp = Object.assign(ACC.sp || {}, { id }); saveAcc();
  const verifier = b64url(crypto.getRandomValues(new Uint8Array(48))), state = b64url(crypto.getRandomValues(new Uint8Array(12)));
  const challenge = b64url(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)));
  store.set('sf_pkce', { verifier, state });
  const u = 'https://accounts.spotify.com/authorize?' + new URLSearchParams({ client_id: id, response_type: 'code', redirect_uri: REDIRECT, scope: 'playlist-read-private playlist-read-collaborative user-library-read', code_challenge_method: 'S256', code_challenge: challenge, state });
  if (window.Native && Native.openUrl) Native.openUrl(u); else window.open(u, '_blank');
}
async function spToken(params) {
  const body = new URLSearchParams({ client_id: ACC.sp.id, ...params }).toString();
  return apiGet('http', { url: 'https://accounts.spotify.com/api/token', method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
}
function keepTokens(d) {
  ACC.sp = Object.assign(ACC.sp || {}, { access: d.access_token, exp: Date.now() + (d.expires_in || 3600) * 1000 - 60000 });
  if (d.refresh_token) ACC.sp.refresh = d.refresh_token; saveAcc();
}
async function spGet(path) {
  if (!ACC.sp || !ACC.sp.refresh) throw new Error('Spotify no está conectada');
  if (Date.now() > (ACC.sp.exp || 0)) keepTokens(await spToken({ grant_type: 'refresh_token', refresh_token: ACC.sp.refresh }));
  return apiGet('http', { url: path.startsWith('http') ? path : 'https://api.spotify.com/v1' + path, headers: { Authorization: 'Bearer ' + ACC.sp.access } });
}
async function handleOauth(url) {
  let u; try { u = new URL(url); } catch { return; }
  const code = u.searchParams.get('code'), state = u.searchParams.get('state'), saved = store.get('sf_pkce', null);
  if (u.searchParams.get('error')) return toast('Spotify canceló la conexión');
  if (!code || !saved || saved.state !== state) return toast('La respuesta de Spotify no es válida');
  store.set('sf_pkce', null);
  try {
    keepTokens(await spToken({ grant_type: 'authorization_code', code, redirect_uri: REDIRECT, code_verifier: saved.verifier }));
    ACC.svc = 'spotify';
    try { const me = await spGet('/me'); if (!ACC.name && me.display_name) ACC.name = me.display_name.slice(0, 24); } catch {}
    saveAcc(); paintAccount(); openSheet('acc'); toast('Spotify conectada'); loadSpotifyLists();
  } catch (e) { toast('No pude conectar: ' + e.message); }
}
window.__oauth = handleOauth;
function pollOauth() { try { if (window.Native && Native.takeOauth) { const u = Native.takeOauth(); if (u) handleOauth(u); } } catch {} }
document.addEventListener('visibilitychange', () => { if (!document.hidden) pollOauth(); });
window.addEventListener('focus', pollOauth);

async function loadSpotifyLists() {
  const box = $('spBody'); box.innerHTML = skel(3);
  try {
    const d = await spGet('/me/playlists?limit=50'); box.innerHTML = '<h3>Tus listas de Spotify</h3>';
    const saved = document.createElement('div'); saved.className = 'dl-row';
    saved.innerHTML = '<div class="tx"><b>Canciones guardadas</b><small>Tus «Me gusta» de Spotify</small></div><button class="pill glass">Importar</button>';
    saved.querySelector('button').onclick = (e) => importSpotify(e.currentTarget, '/me/tracks?limit=50', 'Canciones de Spotify'); box.append(saved);
    (d.items || []).filter(Boolean).forEach((p) => {
      const r = document.createElement('div'); r.className = 'dl-row';
      r.innerHTML = `<div class="tx"><b>${esc(p.name)}</b><small>${p.tracks && p.tracks.total != null ? p.tracks.total + ' canciones' : (p.items && p.items.total != null ? p.items.total + ' canciones' : 'Lista')}</small></div><button class="pill glass">Importar</button>`;
      r.querySelector('button').onclick = (e) => importSpotify(e.currentTarget, `/playlists/${p.id}/items?limit=50`, p.name, `/playlists/${p.id}/tracks?limit=50`);
      box.append(r);
    });
  } catch (e) { box.innerHTML = `<p class="note">No pude leer tus listas: ${esc(e.message)}</p>`; }
}
async function importSpotify(btn, path, name, alt) {
  btn.disabled = true; btn.textContent = 'Importando…';
  try {
    let tracks = [], url = path, tried = false;
    for (let page = 0; page < 6 && url; page++) {
      let d; try { d = await spGet(url); } catch (e) { if (page === 0 && alt && !tried) { tried = true; url = alt; d = await spGet(alt); } else throw e; }
      (d.items || []).forEach((x) => { const t = x && (x.item || x.track); if (t && t.name) tracks.push({ kind: 'song', title: t.name, artist: (t.artists && t.artists[0] && t.artists[0].name) || '', album: (t.album && t.album.name) || '', duration: Math.round((t.duration_ms || 0) / 1000), cover: (t.album && t.album.images && t.album.images[0] && t.album.images[0].url) || '' }); });
      url = d.next;
    }
    if (!tracks.length) throw new Error('la lista está vacía');
    newList(name, tracks); btn.textContent = 'Importada'; toast(`Importadas ${tracks.length} ${tracks.length === 1 ? 'canción' : 'canciones'}`);
  } catch (e) { btn.disabled = false; btn.textContent = 'Reintentar'; toast('No pude importar: ' + e.message); }
}

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  switch (b.dataset.act) {
    case 'open-acc': closeSheet('set'); openSheet('acc'); paintAccount(); if (ACC.svc === 'spotify' && ACC.sp && ACC.sp.access) loadSpotifyLists(); break;
    case 'close-acc': closeSheet('acc'); break;
    case 'sp-connect': spConnect(); break;
    case 'sp-out': ACC.sp = { id: ACC.sp && ACC.sp.id }; saveAcc(); $('spBody').innerHTML = ''; paintAccount(); toast('Spotify desconectada'); break;
    case 'copy-redirect': (navigator.clipboard ? navigator.clipboard.writeText(REDIRECT) : Promise.reject()).then(() => toast('Copiado'), () => toast(REDIRECT)); break;
  }
});
paintAccount(); pollOauth();
