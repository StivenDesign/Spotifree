'use strict';
/* ===== Ajustes e información ===== */
function applyGlass() {
  document.documentElement.style.setProperty('--g', String(CFG.glass / 100));
  $('glassOut').textContent = CFG.glass + '%';
  const r = $('setGlass'); r.value = CFG.glass; r.style.setProperty('--p', CFG.glass + '%');
}
function syncSettingsUI() {
  $('setProv').value = CFG.prov; $('setEq').value = String(CFG.eq);
  $('setAnim').checked = !!CFG.animArt; $('setMotion').checked = CFG.motion; $('setAmb').checked = CFG.amb; $('setHaptic').checked = !!CFG.haptic; $('setArtists').checked = !!CFG.artists;
  document.body.classList.toggle('no-amb', !CFG.amb);
  $('setPerf').checked = !!CFG.perf; document.body.classList.toggle('perf', !!CFG.perf);
  applyGlass(); $('glassNote').hidden = !CFG.perf; S.glDirty = true;
  $('setAutoScan').checked = CFG.autoScan !== false; $('setOfficial').checked = CFG.official !== false; $('setGq').value = CFG.gq || 'auto'; $('setBat').checked = CFG.batSaver !== false;
  $('setBlur').value = CFG.blur ?? 100; $('blurOut').textContent = (CFG.blur ?? 100) + '%'; $('setBlur').style.setProperty('--p', ((CFG.blur ?? 100) / 150 * 100) + '%');
  $('setShine').value = CFG.shine ?? 100; $('shineOut').textContent = (CFG.shine ?? 100) + '%'; $('setShine').style.setProperty('--p', ((CFG.shine ?? 100) / 150 * 100) + '%');
  paintMix();
  $('setGMode').value = CFG.gmode || 'auto'; $('gmodeNote').textContent = (CFG.gmode || 'auto') === 'auto' ? 'Ahora: ' + ({ light: 'Light Glass', smooth: 'Smooth Glass', full: 'Full Glass', solid: 'Sólido' })[resolveGMode()] + ' (según tu teléfono)' : '';
  $('setYtKey').value = CFG.ytKey || ''; $('setPixKey').value = CFG.pixKey || ''; $('setAutoCv').checked = !!CFG.autoCv;
  $('setLite').value = CFG.lite || 'auto'; $('setLiquid').checked = !!CFG.liquid; $('setScId').value = CFG.scId || ''; $('setXg').checked = CFG.xglass !== false; $('setAnim').value = CFG.anim; $('setAmoled').checked = !!CFG.amoled; $('setAwake').checked = !!CFG.awake; $('setRemain').checked = CFG.remain !== false;
  $('setLyrSize').value = CFG.lyrSize; $('lyrOut').textContent = CFG.lyrSize + '%'; $('setLyrSize').style.setProperty('--p', ((CFG.lyrSize - 70) / 70 * 100) + '%'); $('setLyrAlign').value = CFG.lyrAlign; $('setLyrBlur').checked = CFG.lyrBlur !== false;
  applyLook();
}
/* ajustes de aspecto que solo cambian clases y variables */
function applyLook() {
  const b = document.body;
  const gm = resolveGMode(); b.classList.toggle('flat', gm === 'solid'); b.classList.toggle('gl-light', gm === 'light'); b.classList.toggle('gl-smooth', gm === 'smooth'); b.classList.toggle('gl-full', gm === 'full');
  LITE = CFG.lite === 'on' ? true : CFG.lite === 'off' ? false : (gm === 'light' || (gm === 'solid' && lowEnd)); b.classList.toggle('lite', LITE);
  b.classList.toggle('rm', !!RM.matches);
  refreshXg();
  b.classList.toggle('anim-soft', CFG.anim === 'soft'); b.classList.toggle('anim-off', CFG.anim === 'off');
  b.classList.toggle('amoled', !!CFG.amoled); b.classList.toggle('lyr-center', CFG.lyrAlign === 'center'); b.classList.toggle('no-blur-ln', CFG.lyrBlur === false);
  document.documentElement.style.setProperty('--lyr', String(CFG.lyrSize / 100));
  document.documentElement.style.setProperty('--bl', String((CFG.blur ?? 100) / 100)); document.documentElement.style.setProperty('--sh', String((CFG.shine ?? 100) / 100));
}
/* cristal extremo: solo en nivel alto, sin modo ahorro y si el navegador acepta filtros SVG en el fondo */
const xgOk = (() => { try { return CSS.supports('backdrop-filter', 'url(#lg-lens) blur(2px)') || CSS.supports('-webkit-backdrop-filter', 'url(#lg-lens) blur(2px)'); } catch { return false; } })();
function refreshXg() { document.body.classList.toggle('xg', !!(CFG.liquid && CFG.xglass && xgOk && !CFG.perf && document.documentElement.dataset.tier === 'ultra')); }
/* pantalla encendida mientras el reproductor está abierto */
let wakeLock = null;
async function syncWake() {
  try {
    if (CFG.awake && S.npOpen && !document.hidden && navigator.wakeLock) { if (!wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => (wakeLock = null)); } }
    else if (wakeLock) { await wakeLock.release(); wakeLock = null; }
  } catch { wakeLock = null; }
}
document.addEventListener('visibilitychange', syncWake);
/* segundo plano: permiso para que Android no frene la app */
function bgState() { const el = $('bgSub'); if (!el) return; try { el.textContent = window.Native && Native.batteryOk ? (Native.batteryOk() ? 'Listo: la música sigue con la pantalla apagada' : 'Toca para permitirlo (recomendado)') : 'Solo en la app de Android'; } catch {} }
document.addEventListener('click', (e) => { if (e.target.closest('[data-act=bg-ok]')) { try { if (window.Native && Native.allowBackground) { Native.allowBackground(); setTimeout(bgState, 1500); } else toast('Esto funciona en la app de Android'); } catch {} } });
bgState(); document.addEventListener('visibilitychange', () => { if (!document.hidden) bgState(); });
// la primera vez que suena música, se sugiere permitir el segundo plano
let bgAsked = store.get('sf_bgask', false);
function suggestBg() { try { if (bgAsked || !window.Native || !Native.batteryOk || Native.batteryOk()) return; bgAsked = true; store.set('sf_bgask', true); toast('Para que suene con la pantalla apagada: Ajustes > Sonar con la pantalla apagada'); } catch {} }
(function initSettings() {
  let t0;
  PROVIDERS.forEach(([id, name]) => { const o = document.createElement('option'); o.value = id; o.textContent = name; $('setProv').append(o); });
  $('setProv').onchange = (e) => { CFG.prov = e.target.value; saveCfg(); renderSeg(); if (S.queue[S.i]) loadLyrics(S.queue[S.i]); };
  $('setEq').onchange = (e) => { CFG.eq = +e.target.value; saveCfg(); };
  $('setAnim').onchange = (e) => {
    CFG.animArt = e.target.checked; saveCfg();
    const t = S.queue[S.i]; if (!t) return;
    if (CFG.animArt) onTrackLoad(t); else if (!t._hasCanvas) clearMotion();
  };
  $('setMotion').onchange = (e) => {
    CFG.motion = e.target.checked; saveCfg();
    const t = S.queue[S.i]; if (!t) return;
    if (CFG.motion) onTrackLoad(t); else { clearMotion(); $('gl').classList.remove('ready'); }
  };
  $('setPerf').onchange = (e) => { CFG.perf = e.target.checked; CFG.noAuto = true; saveCfg(); if (!CFG.perf && typeof applyTier === 'function') applyTier(xgOk ? 'ultra' : 'high'); syncSettingsUI(); toast(CFG.perf ? 'Modo ahorro activado' : 'Modo ahorro desactivado'); };
  $('setAmb').onchange = (e) => { CFG.amb = e.target.checked; saveCfg(); syncSettingsUI(); };
  $('setArtists').onchange = (e) => { CFG.artists = e.target.checked; saveCfg(); toast(CFG.artists ? 'Fotos de artistas activadas' : 'Fotos de artistas apagadas'); if (CFG.artists) { initArtists(); initRadio(); refreshHome(); } };
  $('setAutoScan').onchange = (e) => { CFG.autoScan = e.target.checked; saveCfg(); };
  $('setOfficial').onchange = (e) => { CFG.official = e.target.checked; saveCfg(); toast(e.target.checked ? 'Se priorizan las versiones oficiales' : 'Se muestran todas las versiones'); };
  $('setGq').onchange = (e) => { CFG.gq = e.target.value; saveCfg(); applyGq(); };
  $('setBat').onchange = (e) => { CFG.batSaver = e.target.checked; saveCfg(); if (typeof checkBattery === 'function') checkBattery(); };
  $('setBlur').addEventListener('input', (e) => { CFG.blur = +e.target.value; $('blurOut').textContent = CFG.blur + '%'; e.target.style.setProperty('--p', (CFG.blur / 150 * 100) + '%'); applyLook(); clearTimeout(t0); t0 = setTimeout(saveCfg, 250); });
  $('setShine').addEventListener('input', (e) => { CFG.shine = +e.target.value; $('shineOut').textContent = CFG.shine + '%'; e.target.style.setProperty('--p', (CFG.shine / 150 * 100) + '%'); applyLook(); clearTimeout(t0); t0 = setTimeout(saveCfg, 250); });
  $('setGMode').onchange = (e) => { CFG.gmode = e.target.value; if (CFG.gmode !== 'auto') { CFG.lite = 'auto'; CFG.gq = 'auto'; } saveCfg(); applyLook(); if (typeof applyGModeTier === 'function') applyGModeTier(); syncSettingsUI(); toast('Modo gráfico: ' + e.target.selectedOptions[0].textContent); };
  $('setPixKey').onchange = (e) => { CFG.pixKey = e.target.value.trim(); saveCfg(); toast(CFG.pixKey ? 'Fondos por género activados' : 'Clave de Pixabay quitada'); };
  $('setAutoCv').onchange = (e) => {
    CFG.autoCv = e.target.checked; saveCfg(); const t = S.queue[S.i];
    if (!CFG.autoCv && S.autoVid) { S.autoVid = false; setVideoMode(false); }
    if (t && CFG.autoCv) onTrackLoad(t);
  };
  $('setYtKey').onchange = (e) => { CFG.ytKey = e.target.value.trim(); saveCfg(); if (typeof renderSrcs === 'function') renderSrcs(); toast(CFG.ytKey ? 'YouTube Data API activada en la búsqueda' : 'YouTube Data API desactivada'); };
  $('setLite').onchange = (e) => { CFG.lite = e.target.value; saveCfg(); applyLook(); toast(LITE ? 'Modo gama baja activado' : 'Modo gama baja apagado'); };
  $('setLiquid').onchange = (e) => { CFG.liquid = e.target.checked; saveCfg(); applyLook(); };
  $('setScId').onchange = (e) => { CFG.scId = e.target.value.trim(); saveCfg(); if (typeof renderSrcs === 'function') renderSrcs(); toast(CFG.scId ? 'SoundCloud activado en la búsqueda' : 'SoundCloud desactivado'); };
  $('setXg').onchange = (e) => { CFG.xglass = e.target.checked; saveCfg(); refreshXg(); toast(e.target.checked ? (xgOk ? 'Cristal extremo activado' : 'Este teléfono no admite el cristal extremo') : 'Cristal extremo apagado'); };
  $('setAnim').onchange = (e) => { CFG.anim = e.target.value; saveCfg(); applyLook(); };
  $('setAmoled').onchange = (e) => { CFG.amoled = e.target.checked; saveCfg(); applyLook(); };
  $('setAwake').onchange = (e) => { CFG.awake = e.target.checked; saveCfg(); syncWake(); if (CFG.awake && !navigator.wakeLock) toast('Este teléfono no permite mantener la pantalla encendida desde aquí'); };
  $('setRemain').onchange = (e) => { CFG.remain = e.target.checked; saveCfg(); lastSec = -1; };
  $('setLyrSize').addEventListener('input', (e) => { CFG.lyrSize = +e.target.value; $('lyrOut').textContent = CFG.lyrSize + '%'; e.target.style.setProperty('--p', ((CFG.lyrSize - 70) / 70 * 100) + '%'); applyLook(); clearTimeout(t0); t0 = setTimeout(saveCfg, 250); });
  $('setLyrAlign').onchange = (e) => { CFG.lyrAlign = e.target.value; saveCfg(); applyLook(); };
  $('setLyrBlur').onchange = (e) => { CFG.lyrBlur = e.target.checked; saveCfg(); applyLook(); };
  $('setHaptic').onchange = (e) => { CFG.haptic = e.target.checked; saveCfg(); if (CFG.haptic) haptic(15); };
  $('setGlass').addEventListener('input', (e) => { CFG.glass = +e.target.value; applyGlass(); clearTimeout(t0); t0 = setTimeout(saveCfg, 250); });
  $('appleGroup').hidden = !window.ClientAPI;
  syncSettingsUI();
})();

function openSet() { openSheet('set'); }
function closeSet() { closeSheet('set'); }

// acciones destructivas: se confirman tocando dos veces
const armed = new Map();
function confirmTap(btn, run) {
  const small = btn.querySelector('small'), old = small.textContent;
  if (armed.has(btn)) { clearTimeout(armed.get(btn)); armed.delete(btn); small.textContent = old; small.style.color = ''; run(); return; }
  small.textContent = 'Toca otra vez para confirmar'; small.style.color = '#ff8a8a';
  armed.set(btn, setTimeout(() => { armed.delete(btn); small.textContent = old; small.style.color = ''; }, 3500));
}
function settingsAction(act, btn) {
  if (act === 'clear-lib') confirmTap(btn, clearLibrary);
  else if (act === 'clear-dl') confirmTap(btn, clearDownloads);
  else if (act === 'clear-canvas') confirmTap(btn, async () => { await canvasClear(); const t = S.queue[S.i]; if (t) { t._hasCanvas = false; $('artImg').src = t.cover; onTrackLoad(t); } toast('Canvas borrados'); });
  else if (act === 'clear-recent') confirmTap(btn, () => { store.set('ondas_recent', []); recentQ = []; store.set('sf_qs', []); renderRecentQ(); refreshHome(); toast('Recientes borrados'); });
}

/* ---- tokens de Apple Music (solo Android) ---- */
function openCfg() {
  const v = store.get('ondas_apple', {});
  $('ap-dev').value = v.dev || ''; $('ap-user').value = v.user || ''; $('ap-sf').value = v.storefront || '';
  $('cfg').hidden = false;
}
$('cfgCancel').onclick = () => ($('cfg').hidden = true);
$('cfgForm').onsubmit = (e) => {
  e.preventDefault();
  store.set('ondas_apple', { dev: $('ap-dev').value.trim(), user: $('ap-user').value.trim(), storefront: $('ap-sf').value.trim() || 'us' });
  $('cfg').hidden = true; toast('Tokens guardados');
  if (S.queue[S.i]) loadLyrics(S.queue[S.i]);
};

/* ===== Ajustes por páginas (categorías, buscador) y opciones nuevas ===== */
(function setPages() {
  const body = $('setBody'), root = $('setRoot'), set = $('set'), title = $('setTitle');
  if (!body || !root) return;
  // cada título h3 y su bloque forman una sección
  const secs = [];
  body.querySelectorAll('h3').forEach((h) => {
    const wrap = h.parentElement === body ? h : h.parentElement;          // Apple Music vive dentro de #appleGroup
    const blocks = wrap === h ? [h, h.nextElementSibling] : [wrap];
    secs.push({ name: h.textContent.trim(), els: blocks, h });
  });
  const META = {
    'Apariencia': ['sliders', 'Cristal, color, animaciones y portada'],
    'Reproducción': ['play', 'Fuentes, ecualizador, sueño, ilustración animada'],
    'Letra': ['quote', 'Tamaño, alineación y enfoque'],
    'Música y descargas': ['dl', 'Descargas, música del teléfono y claves'],
    'Apple Music': ['album', 'Tokens para las letras'],
    'Copia de seguridad': ['refresh', 'Guardar y restaurar tus datos'],
    'Acerca de': ['note', 'Versión y agradecimientos'],
  };
  secs.forEach((s) => {
    const m = META[s.name] || ['sliders', ''], b = document.createElement('button');
    b.className = 'set-cat'; b.dataset.sec = s.name;
    b.innerHTML = `<span class="sc-ic"><svg class="ic s"><use href="#i-${m[0]}"/></svg></span><span class="sc-tx"><b>${s.name}</b><small>${m[1]}</small></span><svg class="ic s chev"><use href="#i-chev"/></svg>`;
    s.cat = b; root.append(b);
  });
  let page = null;
  const acc = body.querySelector('.acc-card');
  function show(name) {
    page = name;
    const q = $('setSearch').value.trim().toLowerCase();
    secs.forEach((s) => s.els.forEach((el) => { el.style.display = (!q && name === s.name) || (q && name === '*') ? '' : 'none'; }));
    root.style.display = !name ? '' : 'none';
    if (acc) acc.style.display = !name ? '' : 'none';
    $('setSearchBox').style.display = name && name !== '*' ? 'none' : '';
    title.textContent = name && name !== '*' ? name : 'Ajustes';
    body.scrollTop = 0; set.classList.toggle('in-page', !!name && name !== '*');
  }
  function search() {
    const q = $('setSearch').value.trim().toLowerCase();
    if (!q) return show(null);
    show('*');
    secs.forEach((s) => {
      let any = false;
      s.els.forEach((el) => {
        if (!el.classList.contains('group')) return;
        el.querySelectorAll('.item').forEach((it) => { const ok = it.textContent.toLowerCase().includes(q); it.style.display = ok ? '' : 'none'; if (ok) any = true; });
      });
      s.els.forEach((el) => { el.style.display = any ? '' : 'none'; });
    });
  }
  const reset = () => { secs.forEach((s) => s.els.forEach((el) => el.querySelectorAll && el.querySelectorAll('.item').forEach((it) => { it.style.display = ''; }))); };
  $('setSearch').addEventListener('input', () => { reset(); search(); });
  root.addEventListener('click', (e) => { const b = e.target.closest('.set-cat'); if (b) { haptic(6); show(b.dataset.sec); } });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-act=set-back]')) return;
    if (page) { $('setSearch').value = ''; reset(); show(null); } else closeSet();
  });
  new MutationObserver(() => { if (set.hidden) { $('setSearch').value = ''; reset(); show(null); } }).observe(set, { attributes: true, attributeFilter: ['hidden'] });
  show(null);
  // el cuadro de Apple Music solo existe si hay tokens: su categoría sigue a #appleGroup
  const ag = $('appleGroup'), apc = secs.find((s) => s.name === 'Apple Music');
  if (ag && apc) new MutationObserver(() => { apc.cat.hidden = ag.hidden; }).observe(ag, { attributes: true, attributeFilter: ['hidden'] }), apc.cat.hidden = ag.hidden;
})();
function applyExtras() {
  const b = document.body;
  b.classList.toggle('full-art', !!CFG.fullArt); b.classList.toggle('show-vol', !!CFG.showVol); b.classList.toggle('no-nowlbl', CFG.nowLbl === false);
  $('setFullArt').checked = !!CFG.fullArt; $('setShowVol').checked = !!CFG.showVol; $('setNowLbl').checked = CFG.nowLbl !== false;
}
[['setFullArt', 'fullArt'], ['setShowVol', 'showVol'], ['setNowLbl', 'nowLbl']].forEach(([id, k]) => { $(id).onchange = (e) => { CFG[k] = e.target.checked; saveCfg(); applyExtras(); haptic(6); }; });
applyExtras();
