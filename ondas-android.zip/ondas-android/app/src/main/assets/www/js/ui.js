'use strict';
/* ===== Interfaz: inicio, búsqueda, listas, reproductor, acciones y bucle principal ===== */
const SUGGEST = ['Bad Bunny', 'Karol G', 'Rosalía', 'The Weeknd', 'Dua Lipa', 'Taylor Swift', 'Peso Pluma', 'Shakira'];
SUGGEST.forEach((name) => {
  const b = document.createElement('button');
  b.className = 'tile'; b.style.setProperty('--h', hue(name));
  b.innerHTML = `<span>${esc(name)}</span><svg class="ic s"><use href="#i-chev"/></svg>`;
  b.onclick = () => { $('q').value = name; search(name); };
  $('tiles').append(b);
});

/* ---------- recientes ---------- */
function renderRecent() {
  const rec = store.get('ondas_recent', []);
  $('secRecent').hidden = !rec.length; $('recent').innerHTML = '';
  rec.forEach((t, idx) => {
    const b = document.createElement('button'); b.className = 'rcard';
    b.innerHTML = `<div class="im"><img src="${esc(t.cover)}" alt="" loading="lazy"></div><div class="t">${esc(t.title)}</div><div class="a">${esc(t.artist)}</div>`;
    b.onclick = () => play(rec, idx, b.querySelector('img'));
    $('recent').append(b);
  });
}
function addRecent(t) {
  if (t.local) return;
  const rec = store.get('ondas_recent', []).filter((x) => x.videoId !== t.videoId);
  rec.unshift({ videoId: t.videoId, title: t.title, artist: t.artist, album: t.album, duration: t.duration, cover: t.cover });
  store.set('ondas_recent', rec.slice(0, 12));
}

/* ---------- búsqueda ---------- */
function renderKinds() { $('kinds').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.kind === CFG.kind)); }
$('kinds').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  CFG.kind = b.dataset.kind; saveCfg(); renderKinds(); if (S.lastQ) search(S.lastQ);
});
$('searchForm').addEventListener('submit', (e) => { e.preventDefault(); $('q').blur(); search($('q').value.trim()); });
async function search(q) {
  if (!q) return;
  S.lastQ = q; $('secResults').hidden = false; $('resTitle').textContent = q; renderKinds();
  $('list').innerHTML = '<div class="skel"></div><div class="skel"></div><div class="skel"></div><div class="skel"></div>';
  { const h = $('home'); h.scrollTo({ top: h.scrollTop + $('secResults').getBoundingClientRect().top - h.getBoundingClientRect().top - 6, behavior: 'smooth' }); }
  try {
    const d = await apiGet('search', { q, type: CFG.kind });
    S.results = d.results; renderList();
  } catch (e) {
    $('list').innerHTML = '<p class="msg">No pude buscar: ' + esc(e.message) + '</p>';
  }
}
function renderList() {
  const cur = S.queue[S.i], cid = cur && tid(cur);
  $('list').innerHTML = '';
  if (!S.results.length) { $('list').innerHTML = '<p class="msg">Sin resultados. Prueba con otro nombre.</p>'; return; }
  S.results.forEach((t, idx) => {
    const b = document.createElement('button');
    b.className = 'row rip' + (tid(t) === cid ? ' now' : ''); b.style.animationDelay = Math.min(idx, 10) * 40 + 'ms';
    b.innerHTML = `<div class="im"><img src="${esc(t.cover)}" alt="" loading="lazy"></div>
      <div style="min-width:0"><div class="t">${esc(t.title)}</div><div class="a">${esc(t.artist)}${t.album ? ' · ' + esc(t.album) : ''}</div></div>
      <div class="d">${tid(t) === cid ? '<span class="bars"><b></b><b></b><b></b><b></b></span>' : (t.duration ? fmt(t.duration) : '')}</div>`;
    b.onclick = () => play(S.results, idx, b.querySelector('img'));
    $('list').append(b);
  });
}
// onda táctil
document.addEventListener('pointerdown', (e) => {
  const el = e.target.closest('.rip'); if (!el) return;
  const r = el.getBoundingClientRect(), size = Math.max(r.width, r.height) * 1.6;
  const s = document.createElement('span'); s.className = 'ripple';
  s.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
  el.append(s); setTimeout(() => s.remove(), 750);
});

/* ---------- canción actual ---------- */
function paintTrack(t) {
  addRecent(t); renderRecent();
  $('mini').classList.add('show');
  const mc = $('miniCover'); mc.src = t.cover; mc.classList.remove('bump'); void mc.offsetWidth; mc.classList.add('bump');
  $('miniT').textContent = t.title; $('miniA').textContent = t.artist;
  $('bigT').textContent = t.title; $('bigA').textContent = t.artist;
  $('lyrT').textContent = t.title; $('lyrA').textContent = t.artist;
  $('srcName').textContent = t.local ? 'Tu música' : 'YouTube Music';
  $('artImg').src = t.cover;
  const ab = $('artbox'); ab.classList.remove('swap'); void ab.offsetWidth; ab.classList.add('swap');
  S.offset = 0; $('offv').textContent = '0.0 s';
  if (S.results.length) renderList();
  renderLibrary();
}
// la portada vuela desde la lista hasta el mini reproductor
function flyCover(img, url) {
  const m = $('mini'), r = img.getBoundingClientRect();
  if (!r.width) return;
  const tx = m.offsetLeft + 8, ty = m.offsetTop + (m.offsetHeight - 48) / 2;
  const el = document.createElement('img'); el.src = url; el.className = 'fly';
  el.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
  document.body.append(el);
  requestAnimationFrame(() => requestAnimationFrame(() => {
    el.style.transform = `translate(${tx - r.left}px,${ty - r.top}px) scale(${48 / r.width})`; el.style.borderRadius = '13px';
  }));
  setTimeout(() => { el.style.opacity = '0'; }, 430); setTimeout(() => el.remove(), 1000);
}

/* ---------- pantallas ---------- */
function openNP() { if (S.i < 0) return; S.npOpen = true; document.body.classList.add('np-open'); $('np').classList.add('open'); S.glDirty = true; syncMotion(); }
function closeNP() { S.npOpen = false; document.body.classList.remove('np-open'); $('np').classList.remove('open'); closeLyr(); syncMotion(); positionVideo(); }
function openLyr() { S.lyrOpen = true; $('lyr').classList.add('open'); S.active = -2; positionVideo(); }
function closeLyr() { S.lyrOpen = false; $('lyr').classList.remove('open'); positionVideo(); }

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act;
  switch (a) {
    case 'play': toggle(); break; case 'next': next(); break; case 'prev': prev(); break;
    case 'open-np': openNP(); break; case 'close-np': closeNP(); break;
    case 'open-lyr': openLyr(); break; case 'close-lyr': closeLyr(); break;
    case 'open-set': openSet(); break; case 'close-set': closeSet(); break;
    case 'eq-mode': CFG.eq = (CFG.eq + 1) % 3; saveCfg(); syncSettingsUI(); toast('Ecualizador: ' + ['Barras', 'Ondas', 'Apagado'][CFG.eq]); break;
    case 'off-': S.offset -= 0.2; $('offv').textContent = S.offset.toFixed(1) + ' s'; break;
    case 'off+': S.offset += 0.2; $('offv').textContent = S.offset.toFixed(1) + ' s'; break;
    case 'video': setVideoMode(!S.video); break;
    case 'canvas': canvasAction(); break;
    case 'add-audio': $('fileAudio').click(); break;
    case 'apple': openCfg(); break;
    case 'clear-lib': case 'clear-canvas': case 'clear-recent': settingsAction(a, b); break;
  }
});
$('fileAudio').addEventListener('change', (e) => { const f = [...e.target.files]; e.target.value = ''; if (f.length) importFiles(f); });
$('fileCanvas').addEventListener('change', (e) => { const f = e.target.files[0]; e.target.value = ''; onCanvasFile(f); });

window.__back = () => {
  if (!$('cfg').hidden) { $('cfg').hidden = true; return true; }
  if ($('set').classList.contains('open')) { closeSet(); return true; }
  if (S.lyrOpen) { closeLyr(); return true; }
  if (S.npOpen) { closeNP(); return true; }
  return false;
};
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') window.__back();
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
  if (e.code === 'Space') { e.preventDefault(); toggle(); }
});

/* ---------- deslizadores ---------- */
const paintRange = (el) => el.style.setProperty('--p', (el.value / el.max * 100) + '%');
$('seek').addEventListener('pointerdown', () => (S.seeking = true));
$('seek').addEventListener('input', (e) => {
  paintRange(e.target); const d = E.dur();
  if (d) { E.seek((e.target.value / 1000) * d); $('cur').textContent = fmt((e.target.value / 1000) * d); }
});
['pointerup', 'pointercancel', 'change'].forEach((ev) => $('seek').addEventListener(ev, () => setTimeout(() => (S.seeking = false), 250)));
$('vol').value = store.get('ondas_vol', 80); paintRange($('vol'));
$('vol').addEventListener('input', (e) => { paintRange(e.target); store.set('ondas_vol', +e.target.value); E.vol(+e.target.value); });
E.audio.volume = $('vol').value / 100;

/* ---------- bucle principal ---------- */
let lastTick = -1, lastSec = -1, lastVis = 0;
function frame(ts) {
  requestAnimationFrame(frame);
  if (document.hidden) return;
  const t = ts / 1000, cur = E.time(), dur = E.dur();
  if (dur) {
    const tick = Math.round(cur / dur * 1000);            // solo se toca el DOM cuando algo cambia de verdad
    if (tick !== lastTick) {
      lastTick = tick; $('miniProg').style.width = (tick / 10) + '%';
      if (S.npOpen && !S.seeking) { const sk = $('seek'); sk.value = tick; paintRange(sk); }
    }
    const sec = Math.floor(cur);
    if (sec !== lastSec) {
      lastSec = sec; syncNative();                        // avisa a Android si cambió la canción o su duración
      if (S.npOpen && !S.seeking) { $('cur').textContent = fmt(cur); $('dur').textContent = fmt(dur); }
    }
  }
  syncLyrics(cur);
  if (S.npOpen) {
    readFFT(); updateBands(t, cur);
    if (!CFG.perf || ts - lastVis > 33) { lastVis = ts; drawGL(t); drawEQ(); }   // 30 cuadros por segundo en modo ahorro
  }
  if (S.video) positionVideo();
}
window.addEventListener('resize', () => { S.glDirty = true; positionVideo(); });

renderRecent(); renderKinds(); loadLibrary();
requestAnimationFrame(frame);
